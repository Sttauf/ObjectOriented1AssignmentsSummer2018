﻿namespace WindowsFormsApp8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.listBox = new System.Windows.Forms.ListBox();
            this.listBoxStudent = new System.Windows.Forms.ListBox();
            this.listBoxTeacher = new System.Windows.Forms.ListBox();
            this.comboBoxST = new System.Windows.Forms.ComboBox();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.textBoxFN = new System.Windows.Forms.TextBox();
            this.textBoxLN = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxDD = new System.Windows.Forms.TextBox();
            this.textBoxMM = new System.Windows.Forms.TextBox();
            this.textBoxYYYY = new System.Windows.Forms.TextBox();
            this.buttonADD = new System.Windows.Forms.Button();
            this.buttonRESET = new System.Windows.Forms.Button();
            this.buttonDISPLAY = new System.Windows.Forms.Button();
            this.buttonREMOVE = new System.Windows.Forms.Button();
            this.buttonSEARCH = new System.Windows.Forms.Button();
            this.buttonMODIFY = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.textBoxIDSearch = new System.Windows.Forms.TextBox();
            this.buttonEXIT = new System.Windows.Forms.Button();
            this.textBoxHPW = new System.Windows.Forms.TextBox();
            this.textBoxHBR = new System.Windows.Forms.TextBox();
            this.textBoxFF = new System.Windows.Forms.TextBox();
            this.textBoxFPS = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.buttonRB = new System.Windows.Forms.Button();
            this.buttonBU = new System.Windows.Forms.Button();
            this.buttonRT = new System.Windows.Forms.Button();
            this.buttonWT = new System.Windows.Forms.Button();
            this.buttonWU = new System.Windows.Forms.Button();
            this.buttonWB = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "First Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Last Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(336, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Type:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 256);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "List of Members:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 448);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "List of Students:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(305, 448);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(126, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "List of Teachers:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(143, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "La Salle Admission";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 20;
            this.listBox.Location = new System.Drawing.Point(19, 279);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(567, 164);
            this.listBox.TabIndex = 8;
            // 
            // listBoxStudent
            // 
            this.listBoxStudent.FormattingEnabled = true;
            this.listBoxStudent.ItemHeight = 20;
            this.listBoxStudent.Location = new System.Drawing.Point(19, 471);
            this.listBoxStudent.Name = "listBoxStudent";
            this.listBoxStudent.Size = new System.Drawing.Size(277, 104);
            this.listBoxStudent.TabIndex = 9;
            // 
            // listBoxTeacher
            // 
            this.listBoxTeacher.FormattingEnabled = true;
            this.listBoxTeacher.ItemHeight = 20;
            this.listBoxTeacher.Location = new System.Drawing.Point(309, 471);
            this.listBoxTeacher.Name = "listBoxTeacher";
            this.listBoxTeacher.Size = new System.Drawing.Size(277, 104);
            this.listBoxTeacher.TabIndex = 10;
            // 
            // comboBoxST
            // 
            this.comboBoxST.FormattingEnabled = true;
            this.comboBoxST.Location = new System.Drawing.Point(451, 28);
            this.comboBoxST.Name = "comboBoxST";
            this.comboBoxST.Size = new System.Drawing.Size(121, 28);
            this.comboBoxST.TabIndex = 11;
            this.comboBoxST.SelectedIndexChanged += new System.EventHandler(this.comboBoxST_SelectedIndexChanged);
            // 
            // textBoxID
            // 
            this.textBoxID.Location = new System.Drawing.Point(108, 38);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(100, 26);
            this.textBoxID.TabIndex = 12;
            this.textBoxID.TextChanged += new System.EventHandler(this.textBoxID_TextChanged);
            // 
            // textBoxFN
            // 
            this.textBoxFN.Location = new System.Drawing.Point(108, 70);
            this.textBoxFN.Name = "textBoxFN";
            this.textBoxFN.Size = new System.Drawing.Size(100, 26);
            this.textBoxFN.TabIndex = 13;
            // 
            // textBoxLN
            // 
            this.textBoxLN.Location = new System.Drawing.Point(108, 102);
            this.textBoxLN.Name = "textBoxLN";
            this.textBoxLN.Size = new System.Drawing.Size(100, 26);
            this.textBoxLN.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 134);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 20);
            this.label9.TabIndex = 15;
            this.label9.Text = "Date";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(189, 137);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(13, 20);
            this.label10.TabIndex = 16;
            this.label10.Text = "/";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(140, 137);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(13, 20);
            this.label11.TabIndex = 17;
            this.label11.Text = "/";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(104, 161);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(33, 20);
            this.label12.TabIndex = 18;
            this.label12.Text = "DD";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(153, 161);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 20);
            this.label13.TabIndex = 19;
            this.label13.Text = "MM";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(202, 161);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 20);
            this.label14.TabIndex = 20;
            this.label14.Text = "YYYY";
            // 
            // textBoxDD
            // 
            this.textBoxDD.Location = new System.Drawing.Point(108, 134);
            this.textBoxDD.Name = "textBoxDD";
            this.textBoxDD.Size = new System.Drawing.Size(28, 26);
            this.textBoxDD.TabIndex = 21;
            // 
            // textBoxMM
            // 
            this.textBoxMM.Location = new System.Drawing.Point(157, 134);
            this.textBoxMM.Name = "textBoxMM";
            this.textBoxMM.Size = new System.Drawing.Size(28, 26);
            this.textBoxMM.TabIndex = 22;
            // 
            // textBoxYYYY
            // 
            this.textBoxYYYY.Location = new System.Drawing.Point(206, 134);
            this.textBoxYYYY.Name = "textBoxYYYY";
            this.textBoxYYYY.Size = new System.Drawing.Size(58, 26);
            this.textBoxYYYY.TabIndex = 23;
            // 
            // buttonADD
            // 
            this.buttonADD.Location = new System.Drawing.Point(32, 198);
            this.buttonADD.Name = "buttonADD";
            this.buttonADD.Size = new System.Drawing.Size(75, 32);
            this.buttonADD.TabIndex = 24;
            this.buttonADD.Text = "Add";
            this.buttonADD.UseVisualStyleBackColor = true;
            this.buttonADD.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonRESET
            // 
            this.buttonRESET.Location = new System.Drawing.Point(113, 198);
            this.buttonRESET.Name = "buttonRESET";
            this.buttonRESET.Size = new System.Drawing.Size(75, 32);
            this.buttonRESET.TabIndex = 25;
            this.buttonRESET.Text = "Reset";
            this.buttonRESET.UseVisualStyleBackColor = true;
            this.buttonRESET.Click += new System.EventHandler(this.buttonRESET_Click);
            // 
            // buttonDISPLAY
            // 
            this.buttonDISPLAY.Location = new System.Drawing.Point(194, 198);
            this.buttonDISPLAY.Name = "buttonDISPLAY";
            this.buttonDISPLAY.Size = new System.Drawing.Size(75, 32);
            this.buttonDISPLAY.TabIndex = 26;
            this.buttonDISPLAY.Text = "Display";
            this.buttonDISPLAY.UseVisualStyleBackColor = true;
            this.buttonDISPLAY.Click += new System.EventHandler(this.buttonDISPLAY_Click);
            // 
            // buttonREMOVE
            // 
            this.buttonREMOVE.Location = new System.Drawing.Point(328, 635);
            this.buttonREMOVE.Name = "buttonREMOVE";
            this.buttonREMOVE.Size = new System.Drawing.Size(82, 32);
            this.buttonREMOVE.TabIndex = 27;
            this.buttonREMOVE.Text = "Remove";
            this.buttonREMOVE.UseVisualStyleBackColor = true;
            this.buttonREMOVE.Click += new System.EventHandler(this.buttonREMOVE_Click);
            // 
            // buttonSEARCH
            // 
            this.buttonSEARCH.Location = new System.Drawing.Point(159, 635);
            this.buttonSEARCH.Name = "buttonSEARCH";
            this.buttonSEARCH.Size = new System.Drawing.Size(75, 32);
            this.buttonSEARCH.TabIndex = 28;
            this.buttonSEARCH.Text = "Search";
            this.buttonSEARCH.UseVisualStyleBackColor = true;
            this.buttonSEARCH.Click += new System.EventHandler(this.buttonSEARCH_Click);
            // 
            // buttonMODIFY
            // 
            this.buttonMODIFY.Location = new System.Drawing.Point(240, 635);
            this.buttonMODIFY.Name = "buttonMODIFY";
            this.buttonMODIFY.Size = new System.Drawing.Size(82, 32);
            this.buttonMODIFY.TabIndex = 29;
            this.buttonMODIFY.Text = "Modify";
            this.buttonMODIFY.UseVisualStyleBackColor = true;
            this.buttonMODIFY.Click += new System.EventHandler(this.buttonMODIFY_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(17, 641);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(30, 20);
            this.label15.TabIndex = 30;
            this.label15.Text = "ID:";
            // 
            // textBoxIDSearch
            // 
            this.textBoxIDSearch.Location = new System.Drawing.Point(53, 638);
            this.textBoxIDSearch.Name = "textBoxIDSearch";
            this.textBoxIDSearch.Size = new System.Drawing.Size(100, 26);
            this.textBoxIDSearch.TabIndex = 31;
            // 
            // buttonEXIT
            // 
            this.buttonEXIT.Location = new System.Drawing.Point(511, 635);
            this.buttonEXIT.Name = "buttonEXIT";
            this.buttonEXIT.Size = new System.Drawing.Size(75, 32);
            this.buttonEXIT.TabIndex = 32;
            this.buttonEXIT.Text = "Exit";
            this.buttonEXIT.UseVisualStyleBackColor = true;
            this.buttonEXIT.Click += new System.EventHandler(this.buttonEXIT_Click);
            // 
            // textBoxHPW
            // 
            this.textBoxHPW.Location = new System.Drawing.Point(472, 195);
            this.textBoxHPW.Name = "textBoxHPW";
            this.textBoxHPW.Size = new System.Drawing.Size(100, 26);
            this.textBoxHPW.TabIndex = 33;
            // 
            // textBoxHBR
            // 
            this.textBoxHBR.Location = new System.Drawing.Point(472, 227);
            this.textBoxHBR.Name = "textBoxHBR";
            this.textBoxHBR.Size = new System.Drawing.Size(100, 26);
            this.textBoxHBR.TabIndex = 34;
            // 
            // textBoxFF
            // 
            this.textBoxFF.Location = new System.Drawing.Point(472, 96);
            this.textBoxFF.Name = "textBoxFF";
            this.textBoxFF.Size = new System.Drawing.Size(100, 26);
            this.textBoxFF.TabIndex = 35;
            // 
            // textBoxFPS
            // 
            this.textBoxFPS.Location = new System.Drawing.Point(472, 128);
            this.textBoxFPS.Name = "textBoxFPS";
            this.textBoxFPS.Size = new System.Drawing.Size(100, 26);
            this.textBoxFPS.TabIndex = 36;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(420, 168);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 20);
            this.label16.TabIndex = 37;
            this.label16.Text = "Teacher:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(420, 67);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 20);
            this.label17.TabIndex = 38;
            this.label17.Text = "Student:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(336, 198);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(128, 20);
            this.label18.TabIndex = 39;
            this.label18.Text = "Hours per Week:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(336, 230);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(115, 20);
            this.label19.TabIndex = 40;
            this.label19.Text = "Hours by Rate:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(336, 99);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(84, 20);
            this.label20.TabIndex = 41;
            this.label20.Text = "First Fees:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(336, 131);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(134, 20);
            this.label21.TabIndex = 42;
            this.label21.Text = "Fees per Section:";
            // 
            // buttonRB
            // 
            this.buttonRB.Location = new System.Drawing.Point(346, 597);
            this.buttonRB.Name = "buttonRB";
            this.buttonRB.Size = new System.Drawing.Size(76, 32);
            this.buttonRB.TabIndex = 43;
            this.buttonRB.Text = "Binary";
            this.buttonRB.UseVisualStyleBackColor = true;
            this.buttonRB.Click += new System.EventHandler(this.buttonRB_Click);
            // 
            // buttonBU
            // 
            this.buttonBU.Location = new System.Drawing.Point(428, 597);
            this.buttonBU.Name = "buttonBU";
            this.buttonBU.Size = new System.Drawing.Size(76, 32);
            this.buttonBU.TabIndex = 44;
            this.buttonBU.Text = "UML";
            this.buttonBU.UseVisualStyleBackColor = true;
            this.buttonBU.Click += new System.EventHandler(this.buttonBU_Click);
            // 
            // buttonRT
            // 
            this.buttonRT.Location = new System.Drawing.Point(511, 597);
            this.buttonRT.Name = "buttonRT";
            this.buttonRT.Size = new System.Drawing.Size(76, 32);
            this.buttonRT.TabIndex = 45;
            this.buttonRT.Text = "Text";
            this.buttonRT.UseVisualStyleBackColor = true;
            this.buttonRT.Click += new System.EventHandler(this.buttonRT_Click);
            // 
            // buttonWT
            // 
            this.buttonWT.Location = new System.Drawing.Point(184, 597);
            this.buttonWT.Name = "buttonWT";
            this.buttonWT.Size = new System.Drawing.Size(76, 32);
            this.buttonWT.TabIndex = 48;
            this.buttonWT.Text = "Text";
            this.buttonWT.UseVisualStyleBackColor = true;
            this.buttonWT.Click += new System.EventHandler(this.buttonWT_Click);
            // 
            // buttonWU
            // 
            this.buttonWU.Location = new System.Drawing.Point(102, 597);
            this.buttonWU.Name = "buttonWU";
            this.buttonWU.Size = new System.Drawing.Size(76, 32);
            this.buttonWU.TabIndex = 47;
            this.buttonWU.Text = "UML";
            this.buttonWU.UseVisualStyleBackColor = true;
            this.buttonWU.Click += new System.EventHandler(this.buttonWU_Click);
            // 
            // buttonWB
            // 
            this.buttonWB.Location = new System.Drawing.Point(20, 597);
            this.buttonWB.Name = "buttonWB";
            this.buttonWB.Size = new System.Drawing.Size(76, 32);
            this.buttonWB.TabIndex = 46;
            this.buttonWB.Text = "Binary";
            this.buttonWB.UseVisualStyleBackColor = true;
            this.buttonWB.Click += new System.EventHandler(this.buttonWB_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(19, 578);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(50, 20);
            this.label22.TabIndex = 49;
            this.label22.Text = "Write:";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(342, 578);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(52, 20);
            this.label23.TabIndex = 50;
            this.label23.Text = "Read:";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(597, 676);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.buttonWT);
            this.Controls.Add(this.buttonWU);
            this.Controls.Add(this.buttonWB);
            this.Controls.Add(this.buttonRT);
            this.Controls.Add(this.buttonBU);
            this.Controls.Add(this.buttonRB);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.textBoxFPS);
            this.Controls.Add(this.textBoxFF);
            this.Controls.Add(this.textBoxHBR);
            this.Controls.Add(this.textBoxHPW);
            this.Controls.Add(this.buttonEXIT);
            this.Controls.Add(this.textBoxIDSearch);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.buttonMODIFY);
            this.Controls.Add(this.buttonSEARCH);
            this.Controls.Add(this.buttonREMOVE);
            this.Controls.Add(this.buttonDISPLAY);
            this.Controls.Add(this.buttonRESET);
            this.Controls.Add(this.buttonADD);
            this.Controls.Add(this.textBoxYYYY);
            this.Controls.Add(this.textBoxMM);
            this.Controls.Add(this.textBoxDD);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBoxLN);
            this.Controls.Add(this.textBoxFN);
            this.Controls.Add(this.textBoxID);
            this.Controls.Add(this.comboBoxST);
            this.Controls.Add(this.listBoxTeacher);
            this.Controls.Add(this.listBoxStudent);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "La Salle Admission";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.ListBox listBoxStudent;
        private System.Windows.Forms.ListBox listBoxTeacher;
        private System.Windows.Forms.ComboBox comboBoxST;
        private System.Windows.Forms.TextBox textBoxID;
        private System.Windows.Forms.TextBox textBoxFN;
        private System.Windows.Forms.TextBox textBoxLN;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxDD;
        private System.Windows.Forms.TextBox textBoxMM;
        private System.Windows.Forms.TextBox textBoxYYYY;
        private System.Windows.Forms.Button buttonADD;
        private System.Windows.Forms.Button buttonRESET;
        private System.Windows.Forms.Button buttonDISPLAY;
        private System.Windows.Forms.Button buttonREMOVE;
        private System.Windows.Forms.Button buttonSEARCH;
        private System.Windows.Forms.Button buttonMODIFY;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBoxIDSearch;
        private System.Windows.Forms.Button buttonEXIT;
        private System.Windows.Forms.TextBox textBoxHPW;
        private System.Windows.Forms.TextBox textBoxHBR;
        private System.Windows.Forms.TextBox textBoxFF;
        private System.Windows.Forms.TextBox textBoxFPS;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button buttonRB;
        private System.Windows.Forms.Button buttonBU;
        private System.Windows.Forms.Button buttonRT;
        private System.Windows.Forms.Button buttonWT;
        private System.Windows.Forms.Button buttonWU;
        private System.Windows.Forms.Button buttonWB;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp8.Logic
{
    public enum EnumType { Teacher, Student }
    [Serializable]
    class Member : Object
    {
        private string FN; //first name
        private string LN; //last name
        private int ID; //id
        public string FN1 { get => FN; set => FN = value; } //get and set of FN
        public string LN1 { get => LN; set => LN = value; } //get and set of LN
        public int ID1 { get => ID; set => ID = value; } //get and set of ID
        public Member()
        {
            ID = 0;
            FN = "--";
            LN = "--";
        }
        public Member(int ID, string FN, string LN)
        {
            this.ID = ID;
            this.FN = FN;
            this.LN = LN;
         }
        public override String ToString()
        {
            String state = " ";
            state = this.ID + " - " + this.FN + " - " + this.LN; return state;
        }
    }
}

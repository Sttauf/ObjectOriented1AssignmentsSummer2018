﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1Add = new System.Windows.Forms.Button();
            this.button2Sub = new System.Windows.Forms.Button();
            this.button3Mult = new System.Windows.Forms.Button();
            this.button4Division = new System.Windows.Forms.Button();
            this.button5Mod = new System.Windows.Forms.Button();
            this.button6Reset = new System.Windows.Forms.Button();
            this.button7Exit = new System.Windows.Forms.Button();
            this.label1Number1 = new System.Windows.Forms.Label();
            this.label2Number2 = new System.Windows.Forms.Label();
            this.label3Result = new System.Windows.Forms.Label();
            this.textBox1Number1 = new System.Windows.Forms.TextBox();
            this.textBox2Number2 = new System.Windows.Forms.TextBox();
            this.textBox3Result = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1Add
            // 
            this.button1Add.Location = new System.Drawing.Point(28, 103);
            this.button1Add.Name = "button1Add";
            this.button1Add.Size = new System.Drawing.Size(34, 31);
            this.button1Add.TabIndex = 0;
            this.button1Add.Text = "+";
            this.button1Add.UseVisualStyleBackColor = true;
            this.button1Add.Click += new System.EventHandler(this.button1Add_Click);
            // 
            // button2Sub
            // 
            this.button2Sub.Location = new System.Drawing.Point(68, 103);
            this.button2Sub.Name = "button2Sub";
            this.button2Sub.Size = new System.Drawing.Size(34, 31);
            this.button2Sub.TabIndex = 1;
            this.button2Sub.Text = "-";
            this.button2Sub.UseVisualStyleBackColor = true;
            this.button2Sub.Click += new System.EventHandler(this.button2Sub_Click);
            // 
            // button3Mult
            // 
            this.button3Mult.Location = new System.Drawing.Point(108, 103);
            this.button3Mult.Name = "button3Mult";
            this.button3Mult.Size = new System.Drawing.Size(34, 31);
            this.button3Mult.TabIndex = 2;
            this.button3Mult.Text = "*";
            this.button3Mult.UseVisualStyleBackColor = true;
            this.button3Mult.Click += new System.EventHandler(this.button3Mult_Click);
            // 
            // button4Division
            // 
            this.button4Division.Location = new System.Drawing.Point(150, 103);
            this.button4Division.Name = "button4Division";
            this.button4Division.Size = new System.Drawing.Size(34, 31);
            this.button4Division.TabIndex = 3;
            this.button4Division.Text = "/";
            this.button4Division.UseVisualStyleBackColor = true;
            this.button4Division.Click += new System.EventHandler(this.button4Division_Click);
            // 
            // button5Mod
            // 
            this.button5Mod.Location = new System.Drawing.Point(189, 103);
            this.button5Mod.Name = "button5Mod";
            this.button5Mod.Size = new System.Drawing.Size(34, 31);
            this.button5Mod.TabIndex = 4;
            this.button5Mod.Text = "%";
            this.button5Mod.UseVisualStyleBackColor = true;
            this.button5Mod.Click += new System.EventHandler(this.button5Mod_Click);
            // 
            // button6Reset
            // 
            this.button6Reset.Location = new System.Drawing.Point(28, 187);
            this.button6Reset.Name = "button6Reset";
            this.button6Reset.Size = new System.Drawing.Size(75, 32);
            this.button6Reset.TabIndex = 5;
            this.button6Reset.Text = "Reset";
            this.button6Reset.UseVisualStyleBackColor = true;
            this.button6Reset.Click += new System.EventHandler(this.button6Reset_Click);
            // 
            // button7Exit
            // 
            this.button7Exit.Location = new System.Drawing.Point(109, 187);
            this.button7Exit.Name = "button7Exit";
            this.button7Exit.Size = new System.Drawing.Size(75, 32);
            this.button7Exit.TabIndex = 6;
            this.button7Exit.Text = "Exit";
            this.button7Exit.UseVisualStyleBackColor = true;
            this.button7Exit.Click += new System.EventHandler(this.button7Exit_Click);
            // 
            // label1Number1
            // 
            this.label1Number1.AutoSize = true;
            this.label1Number1.Location = new System.Drawing.Point(24, 18);
            this.label1Number1.Name = "label1Number1";
            this.label1Number1.Size = new System.Drawing.Size(78, 20);
            this.label1Number1.TabIndex = 7;
            this.label1Number1.Text = "Number1:";
            // 
            // label2Number2
            // 
            this.label2Number2.AutoSize = true;
            this.label2Number2.Location = new System.Drawing.Point(24, 61);
            this.label2Number2.Name = "label2Number2";
            this.label2Number2.Size = new System.Drawing.Size(78, 20);
            this.label2Number2.TabIndex = 8;
            this.label2Number2.Text = "Number2:";
            // 
            // label3Result
            // 
            this.label3Result.AutoSize = true;
            this.label3Result.Location = new System.Drawing.Point(24, 143);
            this.label3Result.Name = "label3Result";
            this.label3Result.Size = new System.Drawing.Size(55, 20);
            this.label3Result.TabIndex = 9;
            this.label3Result.Text = "Result";
            // 
            // textBox1Number1
            // 
            this.textBox1Number1.Location = new System.Drawing.Point(108, 15);
            this.textBox1Number1.Name = "textBox1Number1";
            this.textBox1Number1.Size = new System.Drawing.Size(100, 26);
            this.textBox1Number1.TabIndex = 10;
            // 
            // textBox2Number2
            // 
            this.textBox2Number2.Location = new System.Drawing.Point(108, 58);
            this.textBox2Number2.Name = "textBox2Number2";
            this.textBox2Number2.Size = new System.Drawing.Size(100, 26);
            this.textBox2Number2.TabIndex = 11;
            // 
            // textBox3Result
            // 
            this.textBox3Result.Location = new System.Drawing.Point(108, 140);
            this.textBox3Result.Name = "textBox3Result";
            this.textBox3Result.Size = new System.Drawing.Size(100, 26);
            this.textBox3Result.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 256);
            this.Controls.Add(this.textBox3Result);
            this.Controls.Add(this.textBox2Number2);
            this.Controls.Add(this.textBox1Number1);
            this.Controls.Add(this.label3Result);
            this.Controls.Add(this.label2Number2);
            this.Controls.Add(this.label1Number1);
            this.Controls.Add(this.button7Exit);
            this.Controls.Add(this.button6Reset);
            this.Controls.Add(this.button5Mod);
            this.Controls.Add(this.button4Division);
            this.Controls.Add(this.button3Mult);
            this.Controls.Add(this.button2Sub);
            this.Controls.Add(this.button1Add);
            this.Name = "Form1";
            this.Text = "Calculator Version 01";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1Add;
        private System.Windows.Forms.Button button2Sub;
        private System.Windows.Forms.Button button3Mult;
        private System.Windows.Forms.Button button4Division;
        private System.Windows.Forms.Button button5Mod;
        private System.Windows.Forms.Button button6Reset;
        private System.Windows.Forms.Button button7Exit;
        private System.Windows.Forms.Label label1Number1;
        private System.Windows.Forms.Label label2Number2;
        private System.Windows.Forms.Label label3Result;
        private System.Windows.Forms.TextBox textBox1Number1;
        private System.Windows.Forms.TextBox textBox2Number2;
        private System.Windows.Forms.TextBox textBox3Result;
    }
}


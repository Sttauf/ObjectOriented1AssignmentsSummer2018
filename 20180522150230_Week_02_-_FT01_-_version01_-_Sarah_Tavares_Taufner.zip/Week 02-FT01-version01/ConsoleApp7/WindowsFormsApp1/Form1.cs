﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1Add_Click(object sender, EventArgs e)
        {
            int val1, val2, result;
            string input;
            input = textBox1Number1.Text;
            val1 = Convert.ToInt32(input);

            input = textBox2Number2.Text;
            val2 = Convert.ToInt32(input);
            result = val1 + val2;
            textBox3Result.Text = Convert.ToString(result);
            //or this.textBoxResult
        }
        private void button2Sub_Click(object sender, EventArgs e)
        {
            int val1, val2, result;
            string input;
            input = textBox1Number1.Text;
            val1 = Convert.ToInt32(input);

            input = textBox2Number2.Text;
            val2 = Convert.ToInt32(input);
            result = val1 - val2;
            textBox3Result.Text = Convert.ToString(result);
        }
        private void button3Mult_Click(object sender, EventArgs e)
        {
            int val1, val2, result;
            string input;
            input = textBox1Number1.Text;
            val1 = Convert.ToInt32(input);

            input = textBox2Number2.Text;
            val2 = Convert.ToInt32(input);
            result = val1 * val2;
            textBox3Result.Text = Convert.ToString(result);
        }
        private void button4Division_Click(object sender, EventArgs e)
        {
            int val1, val2, result;
            string input;
            input = textBox1Number1.Text;
            val1 = Convert.ToInt32(input);

            input = textBox2Number2.Text;
            val2 = Convert.ToInt32(input);

            if (val2 == 0)
            {
                textBox3Result.Text = Convert.ToString("Error");
                MessageBox.Show(" Try a number2 different from 0 ", "Error");
                textBox2Number2.Text = "";
                textBox3Result.Text = "";

                this.textBox2Number2.Focus();
            }
            else
            {
                result = val1 / val2;
                textBox3Result.Text = Convert.ToString(result);
            }
        }
        private void button5Mod_Click(object sender, EventArgs e)
        {
            int val1, val2, result;
            string input;
            input = textBox1Number1.Text;
            val1 = Convert.ToInt32(input);

            input = textBox2Number2.Text;
            val2 = Convert.ToInt32(input);

            if (val2 == 0)
            {
                textBox3Result.Text = Convert.ToString("Error");
                MessageBox.Show(" Try a number2 different from 0 ", "Error");
                textBox2Number2.Text = "";
                textBox3Result.Text = "";

                this.textBox2Number2.Focus();
            }
            else
            {
                result = val1 % val2;
                textBox3Result.Text = Convert.ToString(result);
            }
        }
        private void button6Reset_Click(object sender, EventArgs e)
        {
            textBox1Number1.Text = "";
            textBox2Number2.Text = "";
            textBox3Result.Text = "";

            this.textBox1Number1.Focus();
        }
        private void button7Exit_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" Thanks for using the Calculator ", "Calculator Version 01");
            this.Close();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppV2
{
    class Program
    {
        static void Main(string[] args)
        {
            int exit;
            do
            {
                char op;
                int num1, num2, result;
                Console.Clear();
                Console.Write("Calculator: ");
                Console.Write("\n Enter the first number: ");
                num1 = System.Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter the second number: ");
                num2 = System.Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Write the operator that you want to calculate ( +, -, *, % or /) : ");
                op = System.Convert.ToChar(Console.ReadLine());
                switch (op)
                {
                    case '+':
                        {
                            result = num1 + num2;
                            Console.Write(num1 + "+" + num2 + "=" + result);
                            break;
                        }
                    case '-':
                        {
                            result = num1 - num2;
                            Console.Write("\n" + num1 + "-" + num2 + "=" + result);
                            break;
                        }
                    case '*':
                        {
                            result = num1 * num2;
                            Console.Write("\n" + num1 + "*" + num2 + "=" + result);
                            break;
                        }
                    case '/':
                        {
                            if (num2 == 0) { break; }
                            else
                            {
                                result = num1 / num2;
                                Console.Write("\n" + num1 + "/" + num2 + "=" + result);
                            }
                            break;
                        }
                    case '%':
                        {
                            if (num2 == 0) { break; }
                            else
                            {
                                result = num1 % num2;
                                Console.WriteLine(num1 + "%" + num2 + "=" + result);
                            }
                            break;
                        }
                }
                Console.ReadKey();
                Console.Clear();
                Console.WriteLine("\n Continue? \n 1.YES \n 2.NO");
                exit = System.Convert.ToInt16(Console.ReadLine());
                Console.ReadKey();
            } while (exit == 1);
        }
    }
}
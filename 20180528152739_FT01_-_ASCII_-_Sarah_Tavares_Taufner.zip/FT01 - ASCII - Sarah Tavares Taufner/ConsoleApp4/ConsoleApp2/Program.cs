﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            const int MIN_VALUE = 31, MAX_VALUE = 132, PER_LINE = 10;

            int counter = 0;
            Console.WriteLine("\n\n");
            int value = MIN_VALUE;
            while (value != MAX_VALUE)
            {
                value++;
                Console.Write("(" + value + " - " + (char)value + ")");
                counter++;
                if (counter % PER_LINE == 0)
                {
                    Console.WriteLine("\n");
                }
            } 

            System.Console.WriteLine();
            System.Console.ReadKey();
        }
    }
}

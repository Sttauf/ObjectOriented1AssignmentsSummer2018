﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wk10___Shapes_Version2._1.Classes;
//The only mistake is when I display the data, its duplicating
namespace Wk10___Shapes_Version2._1
{
    public partial class Form1 : Form
    {
        Rectangles nR;
        Elipse nE;
        Circle nC;
        public Form1()
        {
          InitializeComponent();
        }
       
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                listBox1.Items.Clear();
                this.textBoxX.Enabled = true;
                this.textBoxY.Enabled = true;
                this.textBoxRX.Enabled = false;
                this.textBoxRY.Enabled = false;
                this.textBoxR.Enabled = false;
                this.textBoxW.Enabled = true;
                this.textBoxH.Enabled = true;
                this.label14.Text = "Height";
                this.label13.Text = "(X, Y)";
                this.label15.Text = "Width";
                this.label16.Text = "Perimeter";
                this.label17.Text = "Area";

            }
            else if (comboBox1.SelectedIndex == 1)
            {
                listBox1.Items.Clear();
                this.textBoxX.Enabled = true;
                this.textBoxY.Enabled = true;
                this.textBoxRX.Enabled = true;
                this.textBoxRY.Enabled = true;
                this.textBoxR.Enabled = false;
                this.textBoxW.Enabled = false;
                this.textBoxH.Enabled = false;
                this.label14.Text = "Rx";
                this.label13.Text = "(X, Y)";
                this.label15.Text = "Ry";
                this.label16.Text = "Perimeter";
                this.label17.Text = "Area";
            }
            else if (comboBox1.SelectedIndex == 2)
            {
                listBox1.Items.Clear();
                this.textBoxX.Enabled = true;
                this.textBoxY.Enabled = true;
                this.textBoxRX.Enabled = false;
                this.textBoxRY.Enabled = false;
                this.textBoxR.Enabled = true;
                this.textBoxW.Enabled = false;
                this.textBoxH.Enabled = false;
                this.label14.Text = "Radius";
                this.label13.Text = "(X, Y)";
                this.label16.Text = "Perimeter";
                this.label17.Text = "Area";
            }
        }
        private void buttonDISPLAY_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.SelectedIndex == 0)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    int Y = Convert.ToInt32(this.textBoxY.Text);
                    nR = new Rectangles(W, H, X, Y);

                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    int Y = Convert.ToInt32(this.textBoxY.Text);
                    int RX = Convert.ToInt32(this.textBoxRX.Text);
                    int RY = Convert.ToInt32(this.textBoxRY.Text);
                    nE = new Wk10___Shapes_Version2._1.Classes.Elipse(RX, RY, X, Y);

                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    int Y = Convert.ToInt32(this.textBoxY.Text);
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);

                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch
            {
                MessageBox.Show("ERROR: You left an empty space.");
            }
        }

        private void buttonUP_Click(object sender, EventArgs e)
        {
            try
            {
                int Y = Convert.ToInt32(this.textBoxY.Text);
                Y = Y - 1;
                textBoxY.Text = Convert.ToString(Y);
                if (comboBox1.SelectedIndex == 0)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    int RX = Convert.ToInt32(this.textBoxRX.Text);
                    int RY = Convert.ToInt32(this.textBoxRY.Text);
                    nE = new Wk10___Shapes_Version2._1.Classes.Elipse(RX, RY, X, Y);
                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    int X = Convert.ToInt32(this.textBoxX.Text);

                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }
        private void buttonDOWN_Click(object sender, EventArgs e)
        {
            try
            {
                int Y = Convert.ToInt32(this.textBoxY.Text);
                Y = Y + 1;
                textBoxY.Text = Convert.ToString(Y);
                if (comboBox1.SelectedIndex == 0)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    int RX = Convert.ToInt32(this.textBoxRX.Text);
                    int RY = Convert.ToInt32(this.textBoxRY.Text);
                    nE = new Wk10___Shapes_Version2._1.Classes.Elipse(RX, RY, X, Y);
                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }

        private void buttonRIGHT_Click(object sender, EventArgs e)
        {
            try
            {
                int X = Convert.ToInt32(this.textBoxX.Text);
                X = X + 1;
                textBoxX.Text = Convert.ToString(X);
                if (comboBox1.SelectedIndex == 0)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    int Y = Convert.ToInt32(this.textBoxY.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    int Y = Convert.ToInt32(this.textBoxY.Text);
                    int RX = Convert.ToInt32(this.textBoxRX.Text);
                    int RY = Convert.ToInt32(this.textBoxRY.Text);
                    nE = new Wk10___Shapes_Version2._1.Classes.Elipse(RX, RY, X, Y);
                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    int Y = Convert.ToInt32(this.textBoxY.Text);
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }

        private void buttonLEFT_Click(object sender, EventArgs e)
        {
            try
            {
                int X = Convert.ToInt32(this.textBoxX.Text);
                X = X - 1;
                textBoxX.Text = Convert.ToString(X);
                if (comboBox1.SelectedIndex == 0)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    int Y = Convert.ToInt32(this.textBoxY.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    int Y = Convert.ToInt32(this.textBoxY.Text);
                    int RX = Convert.ToInt32(this.textBoxRX.Text);
                    int RY = Convert.ToInt32(this.textBoxRY.Text);
                    nE = new Wk10___Shapes_Version2._1.Classes.Elipse(RX, RY, X, Y);
                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    int Y = Convert.ToInt32(this.textBoxY.Text);
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }

        private void buttonUPLEFT_Click(object sender, EventArgs e)
        {
            try
            {
                int X = Convert.ToInt32(this.textBoxX.Text);
                X = X - 1;
                int Y = Convert.ToInt32(this.textBoxY.Text);
                Y = Y - 1;
                textBoxY.Text = Convert.ToString(Y);
                textBoxX.Text = Convert.ToString(X);
                if (comboBox1.SelectedIndex == 0)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    int RX = Convert.ToInt32(this.textBoxRX.Text);
                    int RY = Convert.ToInt32(this.textBoxRY.Text);
                    nE = new Wk10___Shapes_Version2._1.Classes.Elipse(RX, RY, X, Y);
                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int Y = Convert.ToInt32(this.textBoxY.Text);
                Y = Y + 1;
                int X = Convert.ToInt32(this.textBoxX.Text);
                X = X - 1;
                textBoxY.Text = Convert.ToString(Y);
                textBoxX.Text = Convert.ToString(X);
                if (comboBox1.SelectedIndex == 0)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    int RX = Convert.ToInt32(this.textBoxRX.Text);
                    int RY = Convert.ToInt32(this.textBoxRY.Text);
                    nE = new Wk10___Shapes_Version2._1.Classes.Elipse(RX, RY, X, Y);
                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }

        private void buttonDOWNRIGHT_Click(object sender, EventArgs e)
        {
            try
            {
                int Y = Convert.ToInt32(this.textBoxY.Text);
                Y = Y + 1;
                int X = Convert.ToInt32(this.textBoxX.Text);
                X = X + 1;
                textBoxY.Text = Convert.ToString(Y);
                textBoxX.Text = Convert.ToString(X);
                if (comboBox1.SelectedIndex == 0)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    int RX = Convert.ToInt32(this.textBoxRX.Text);
                    int RY = Convert.ToInt32(this.textBoxRY.Text);
                    nE = new Wk10___Shapes_Version2._1.Classes.Elipse(RX, RY, X, Y);
                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }

        private void buttonUPRIGHT_Click(object sender, EventArgs e)
        {
            try
            {
                int X = Convert.ToInt32(this.textBoxX.Text);
                X = X + 1;
                int Y = Convert.ToInt32(this.textBoxY.Text);
                Y = Y - 1;
                textBoxY.Text = Convert.ToString(Y);
                textBoxX.Text = Convert.ToString(X);
                if (comboBox1.SelectedIndex == 0)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    int RX = Convert.ToInt32(this.textBoxRX.Text);
                    int RY = Convert.ToInt32(this.textBoxRY.Text);
                    nE = new Wk10___Shapes_Version2._1.Classes.Elipse(RX, RY, X, Y);
                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            if (this.comboBox1.SelectedIndex == 0 && nR != null)
            {
                nR.Draw(e);
                this.listBox1.Items.Add(nR.ToString());
            }
            else if (this.comboBox1.SelectedIndex == 1 && nE != null)
            {
                nE.Draw(e);
                this.listBox1.Items.Add(nE.ToString());
            }
            else if (this.comboBox1.SelectedIndex == 2 && nC != null)
            {
                nC.Draw(e);
                this.listBox1.Items.Add(nC.ToString());
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.textBoxX.Enabled = false;
            this.textBoxY.Enabled = false;
            this.textBoxRX.Enabled = false;
            this.textBoxRY.Enabled = false;
            this.textBoxR.Enabled = false;
            this.textBoxW.Enabled = false;
            this.textBoxH.Enabled = false;
            listBox1.Items.Clear();
            foreach (EnumType element in Enum.GetValues(typeof(EnumType)))
                {
                    comboBox1.Items.Add(element);
                }
            
        }
    }
}

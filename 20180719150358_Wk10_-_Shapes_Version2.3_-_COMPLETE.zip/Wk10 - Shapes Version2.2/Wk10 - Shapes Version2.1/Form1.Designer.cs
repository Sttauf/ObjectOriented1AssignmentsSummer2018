﻿namespace Wk10___Shapes_Version2._1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxH = new System.Windows.Forms.TextBox();
            this.textBoxW = new System.Windows.Forms.TextBox();
            this.textBoxRX = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.textBoxY = new System.Windows.Forms.TextBox();
            this.textBoxX = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.buttonDISPLAY = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxRY = new System.Windows.Forms.TextBox();
            this.buttonDOWNRIGHT = new System.Windows.Forms.Button();
            this.buttonDOWNLEFT = new System.Windows.Forms.Button();
            this.buttonUPRIGHT = new System.Windows.Forms.Button();
            this.buttonUPLEFT = new System.Windows.Forms.Button();
            this.buttonUP = new System.Windows.Forms.Button();
            this.buttonLEFT = new System.Windows.Forms.Button();
            this.buttonRIGHT = new System.Windows.Forms.Button();
            this.buttonDOWN = new System.Windows.Forms.Button();
            this.textBoxR = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(78, 11);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 28);
            this.comboBox1.TabIndex = 15;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(12, 46);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(331, 292);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(361, 135);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Height:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(361, 167);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Width:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(361, 224);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Radius in X:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Shape:";
            // 
            // textBoxH
            // 
            this.textBoxH.Location = new System.Drawing.Point(430, 132);
            this.textBoxH.Name = "textBoxH";
            this.textBoxH.Size = new System.Drawing.Size(100, 26);
            this.textBoxH.TabIndex = 6;
            // 
            // textBoxW
            // 
            this.textBoxW.Location = new System.Drawing.Point(430, 164);
            this.textBoxW.Name = "textBoxW";
            this.textBoxW.Size = new System.Drawing.Size(100, 26);
            this.textBoxW.TabIndex = 7;
            // 
            // textBoxRX
            // 
            this.textBoxRX.Location = new System.Drawing.Point(461, 221);
            this.textBoxRX.Name = "textBoxRX";
            this.textBoxRX.Size = new System.Drawing.Size(69, 26);
            this.textBoxRX.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(402, 106);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Retangle";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(414, 195);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Elipse";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(145, 365);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(279, 104);
            this.listBox1.TabIndex = 11;
            // 
            // textBoxY
            // 
            this.textBoxY.Location = new System.Drawing.Point(492, 78);
            this.textBoxY.Name = "textBoxY";
            this.textBoxY.Size = new System.Drawing.Size(41, 26);
            this.textBoxY.TabIndex = 12;
            // 
            // textBoxX
            // 
            this.textBoxX.Location = new System.Drawing.Point(492, 46);
            this.textBoxX.Name = "textBoxX";
            this.textBoxX.Size = new System.Drawing.Size(41, 26);
            this.textBoxX.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(462, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 20);
            this.label7.TabIndex = 14;
            this.label7.Text = "X:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(462, 81);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 20);
            this.label8.TabIndex = 15;
            this.label8.Text = "Y:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(349, 46);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 20);
            this.label9.TabIndex = 16;
            this.label9.Text = "Starting point:";
            // 
            // buttonDISPLAY
            // 
            this.buttonDISPLAY.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonDISPLAY.Location = new System.Drawing.Point(458, 365);
            this.buttonDISPLAY.Name = "buttonDISPLAY";
            this.buttonDISPLAY.Size = new System.Drawing.Size(75, 34);
            this.buttonDISPLAY.TabIndex = 17;
            this.buttonDISPLAY.Text = "Display";
            this.buttonDISPLAY.UseVisualStyleBackColor = false;
            this.buttonDISPLAY.Click += new System.EventHandler(this.buttonDISPLAY_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(361, 256);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 20);
            this.label10.TabIndex = 18;
            this.label10.Text = "Radius in Y:";
            // 
            // textBoxRY
            // 
            this.textBoxRY.Location = new System.Drawing.Point(461, 253);
            this.textBoxRY.Name = "textBoxRY";
            this.textBoxRY.Size = new System.Drawing.Size(69, 26);
            this.textBoxRY.TabIndex = 19;
            // 
            // buttonDOWNRIGHT
            // 
            this.buttonDOWNRIGHT.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonDOWNRIGHT.BackgroundImage")));
            this.buttonDOWNRIGHT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonDOWNRIGHT.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonDOWNRIGHT.Location = new System.Drawing.Point(102, 435);
            this.buttonDOWNRIGHT.Name = "buttonDOWNRIGHT";
            this.buttonDOWNRIGHT.Size = new System.Drawing.Size(37, 34);
            this.buttonDOWNRIGHT.TabIndex = 27;
            this.buttonDOWNRIGHT.UseVisualStyleBackColor = true;
            this.buttonDOWNRIGHT.Click += new System.EventHandler(this.buttonDOWNRIGHT_Click);
            // 
            // buttonDOWNLEFT
            // 
            this.buttonDOWNLEFT.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonDOWNLEFT.BackgroundImage")));
            this.buttonDOWNLEFT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonDOWNLEFT.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonDOWNLEFT.Location = new System.Drawing.Point(12, 435);
            this.buttonDOWNLEFT.Name = "buttonDOWNLEFT";
            this.buttonDOWNLEFT.Size = new System.Drawing.Size(37, 34);
            this.buttonDOWNLEFT.TabIndex = 26;
            this.buttonDOWNLEFT.UseVisualStyleBackColor = true;
            this.buttonDOWNLEFT.Click += new System.EventHandler(this.button3_Click);
            // 
            // buttonUPRIGHT
            // 
            this.buttonUPRIGHT.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonUPRIGHT.BackgroundImage")));
            this.buttonUPRIGHT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonUPRIGHT.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonUPRIGHT.Location = new System.Drawing.Point(102, 349);
            this.buttonUPRIGHT.Name = "buttonUPRIGHT";
            this.buttonUPRIGHT.Size = new System.Drawing.Size(37, 34);
            this.buttonUPRIGHT.TabIndex = 25;
            this.buttonUPRIGHT.UseVisualStyleBackColor = true;
            this.buttonUPRIGHT.Click += new System.EventHandler(this.buttonUPRIGHT_Click);
            // 
            // buttonUPLEFT
            // 
            this.buttonUPLEFT.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonUPLEFT.BackgroundImage")));
            this.buttonUPLEFT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonUPLEFT.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonUPLEFT.Location = new System.Drawing.Point(12, 349);
            this.buttonUPLEFT.Name = "buttonUPLEFT";
            this.buttonUPLEFT.Size = new System.Drawing.Size(37, 34);
            this.buttonUPLEFT.TabIndex = 24;
            this.buttonUPLEFT.UseVisualStyleBackColor = true;
            this.buttonUPLEFT.Click += new System.EventHandler(this.buttonUPLEFT_Click);
            // 
            // buttonUP
            // 
            this.buttonUP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonUP.BackgroundImage")));
            this.buttonUP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonUP.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonUP.Location = new System.Drawing.Point(55, 349);
            this.buttonUP.Name = "buttonUP";
            this.buttonUP.Size = new System.Drawing.Size(41, 34);
            this.buttonUP.TabIndex = 20;
            this.buttonUP.UseVisualStyleBackColor = true;
            this.buttonUP.Click += new System.EventHandler(this.buttonUP_Click);
            // 
            // buttonLEFT
            // 
            this.buttonLEFT.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonLEFT.BackgroundImage")));
            this.buttonLEFT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonLEFT.Location = new System.Drawing.Point(12, 389);
            this.buttonLEFT.Name = "buttonLEFT";
            this.buttonLEFT.Size = new System.Drawing.Size(37, 40);
            this.buttonLEFT.TabIndex = 23;
            this.buttonLEFT.UseVisualStyleBackColor = true;
            this.buttonLEFT.Click += new System.EventHandler(this.buttonLEFT_Click);
            // 
            // buttonRIGHT
            // 
            this.buttonRIGHT.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonRIGHT.BackgroundImage")));
            this.buttonRIGHT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonRIGHT.Location = new System.Drawing.Point(102, 389);
            this.buttonRIGHT.Name = "buttonRIGHT";
            this.buttonRIGHT.Size = new System.Drawing.Size(37, 40);
            this.buttonRIGHT.TabIndex = 22;
            this.buttonRIGHT.UseVisualStyleBackColor = true;
            this.buttonRIGHT.Click += new System.EventHandler(this.buttonRIGHT_Click);
            // 
            // buttonDOWN
            // 
            this.buttonDOWN.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonDOWN.BackgroundImage")));
            this.buttonDOWN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonDOWN.Location = new System.Drawing.Point(55, 435);
            this.buttonDOWN.Name = "buttonDOWN";
            this.buttonDOWN.Size = new System.Drawing.Size(41, 34);
            this.buttonDOWN.TabIndex = 21;
            this.buttonDOWN.UseVisualStyleBackColor = true;
            this.buttonDOWN.Click += new System.EventHandler(this.buttonDOWN_Click);
            // 
            // textBoxR
            // 
            this.textBoxR.Location = new System.Drawing.Point(430, 320);
            this.textBoxR.Name = "textBoxR";
            this.textBoxR.Size = new System.Drawing.Size(100, 26);
            this.textBoxR.TabIndex = 28;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(414, 297);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 20);
            this.label11.TabIndex = 29;
            this.label11.Text = "Circle";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(361, 323);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 20);
            this.label12.TabIndex = 30;
            this.label12.Text = "Radius:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(145, 342);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 20);
            this.label13.TabIndex = 31;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(200, 342);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 20);
            this.label14.TabIndex = 32;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(251, 342);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(0, 20);
            this.label15.TabIndex = 33;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(304, 342);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(0, 20);
            this.label16.TabIndex = 34;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(380, 342);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 20);
            this.label17.TabIndex = 35;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 479);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBoxR);
            this.Controls.Add(this.buttonDOWNRIGHT);
            this.Controls.Add(this.buttonDOWNLEFT);
            this.Controls.Add(this.buttonUPRIGHT);
            this.Controls.Add(this.buttonUPLEFT);
            this.Controls.Add(this.buttonUP);
            this.Controls.Add(this.buttonLEFT);
            this.Controls.Add(this.buttonRIGHT);
            this.Controls.Add(this.buttonDOWN);
            this.Controls.Add(this.textBoxRY);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.buttonDISPLAY);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxX);
            this.Controls.Add(this.textBoxY);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxRX);
            this.Controls.Add(this.textBoxW);
            this.Controls.Add(this.textBoxH);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.comboBox1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxH;
        private System.Windows.Forms.TextBox textBoxW;
        private System.Windows.Forms.TextBox textBoxRX;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox textBoxY;
        private System.Windows.Forms.TextBox textBoxX;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button buttonDISPLAY;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxRY;
        private System.Windows.Forms.Button buttonUP;
        private System.Windows.Forms.Button buttonDOWN;
        private System.Windows.Forms.Button buttonRIGHT;
        private System.Windows.Forms.Button buttonLEFT;
        private System.Windows.Forms.Button buttonUPLEFT;
        private System.Windows.Forms.Button buttonUPRIGHT;
        private System.Windows.Forms.Button buttonDOWNLEFT;
        private System.Windows.Forms.Button buttonDOWNRIGHT;
        private System.Windows.Forms.TextBox textBoxR;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;


namespace Wk10___Shapes_Version2._1.Classes
{
    public enum EnumType { Rectangle, Elipse, Circle }
    public abstract class Shapes: IShape2D
    {
        private double x;
        private double y;
        public double X { get => x; set => x = value; }
        public double Y { get => y; set => y = value; }
        public Shapes()
        {
            this.x = 0.00;
            this.y = 0.00;
        }
        public Shapes(double x, double y)
        {
            this.x = x;
            this.y = y;
        }
        public override String ToString() { string state = " "; state = "(" + this.X + ", " + this.Y + ")"; return state; }

        public abstract double CA();
        public abstract double CP();
        public abstract void Draw(PaintEventArgs s);
    }
}

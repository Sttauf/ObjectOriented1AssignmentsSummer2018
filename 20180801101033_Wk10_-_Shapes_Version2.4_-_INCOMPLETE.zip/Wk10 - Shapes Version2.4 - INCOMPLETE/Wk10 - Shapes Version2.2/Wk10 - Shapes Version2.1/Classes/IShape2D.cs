﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wk10___Shapes_Version2._1.Classes
{
    interface IShape2D 
    {
        double CA();
        double CP();
        void Draw(System.Windows.Forms.PaintEventArgs s, string F, string U);
    }
}

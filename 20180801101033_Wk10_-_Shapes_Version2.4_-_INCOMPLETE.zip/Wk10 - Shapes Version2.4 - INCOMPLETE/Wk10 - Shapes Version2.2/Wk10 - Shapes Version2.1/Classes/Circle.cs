﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Wk10___Shapes_Version2._1.Classes
{
    public class Circle : Shapes
    {
        private double R;//R = Radius
        public double R1 { get => R; set => R = value; }

        public Circle()
    {
        this.X = 0.00;
        this.Y = 0.00;
        this.R = 0.00;
    }
    public Circle(double R, double x, double y) : base(x, y)
    {
        this.X = X;
        this.Y = Y;
        this.R1 = R;
    }
    public override double CA() //CALCULE AREA
    {
        return 3.14 * this.R * this.R;
    }
    public override double CP() //CALCULE PERIMETER
    {
       return 2 * 3.14 * this.R;

    }
    public override String ToString()
    {
        String D = "(" + this.X + ", " + this.Y + ")" + "\t" + this.R+ "  " + Math.Round(this.CP()) + "  " + Math.Round(this.CA());
            return D;
    }
    public override void Draw(PaintEventArgs s, string F, string U)
    {
            //F = Fill
            //U = Underline
       string SUC = U; //Selected Underline Color
       string SFC = F; //Selected Fill Color
            switch (SUC)
            {
                case "Blue":
                    Pen myPen = new Pen(Color.Blue, 4);
                    s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    myPen.Dispose();
                    break;
                case "Yellow":
                    myPen = new Pen(Color.Yellow, 4);
                    s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    myPen.Dispose();
                    break;
                case "Green":
                    myPen = new Pen(Color.Green, 4);
                    s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    myPen.Dispose();
                    break;
                case "Pink":
                    myPen = new Pen(Color.Pink, 4);
                    s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    myPen.Dispose();
                    break;
                case "Purple":
                    myPen = new Pen(Color.Purple, 4);
                    s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    myPen.Dispose();
                    break;
                case "Red":
                    myPen = new Pen(Color.Red, 4);
                    s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    myPen.Dispose();
                    break;
                default:
                    myPen = new Pen(Color.Black, 4);
                    MessageBox.Show("Because you didn't Selected a Color, the Default BLACK Color was applied");
                    s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    break;
            }
            switch (SFC)
            {
                case "Blue":
                    s.Graphics.FillEllipse(Brushes.Blue, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    break;
                case "Yellow":
                    s.Graphics.FillEllipse(Brushes.Yellow, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    break;
                case "Green":
                    s.Graphics.FillEllipse(Brushes.Green, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    break;
                case "Pink":
                    s.Graphics.FillEllipse(Brushes.Pink, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    break;
                case "Purple":
                    s.Graphics.FillEllipse(Brushes.Purple, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    break;
                case "Red":
                    s.Graphics.FillEllipse(Brushes.Red, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    break;
                default:
                    MessageBox.Show("Because you didn't Selected a Color, the Default BLACK Color was applied");
                    s.Graphics.FillEllipse(Brushes.Black, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    break;
            }

            s.Graphics.Dispose();
        }
}
}

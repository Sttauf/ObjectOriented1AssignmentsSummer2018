﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Wk10___Shapes_Version2._1.Classes
{
    public class Rectangles : Shapes
    {
        private double W; //W = width
        private double H; //H = heigh
        public double W1 { get => W; set => W = value; }
        public double H1 { get => H; set => H = value; }
        public Rectangles()
        {
            this.X = 0.00;
            this.Y = 0.00;
            this.W = 200;
            this.H = 100;
        }
        public Rectangles(double W, double H, double x, double y) : base(x, y)
        {
            this.X = x;
            this.Y = y;
            this.W1 = W;
            this.H1 = H;
        }
        public override double CA() //CALCULE AREA
        {
            return this.H * this.W;
        }
        public override double CP() //CALCULE PERIMETER
        {
            return 2 * (this.H + this.W);
        }
        public override String ToString()
        {
            String D = "(" + this.X + ", " + this.Y + ")" + "\t" + this.H + "    " + this.W + "\t" + Math.Round(this.CP()) + "      " + Math.Round(this.CA());
            return D;
        }
        public override void Draw(PaintEventArgs s, string F, string U)
        {
            //F = Fill
            //U = Underline
            string SUC = U; //Selected Underline Color
            string SFC = F; //Selected Fill Color
            switch (SUC)
            {
                case "Blue":
                    Pen myPen = new Pen(Color.Blue, 4);
                    s.Graphics.DrawRectangle(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.W), Convert.ToInt32(this.H)));
                    myPen.Dispose();
                    break;
                case "Yellow":
                    myPen = new Pen(Color.Yellow, 4);
                    s.Graphics.DrawRectangle(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.W), Convert.ToInt32(this.H)));
                    myPen.Dispose();
                    break;
                case "Green":
                    myPen = new Pen(Color.Green, 4);
                    s.Graphics.DrawRectangle(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.W), Convert.ToInt32(this.H)));
                    myPen.Dispose();
                    break;
                case "Pink":
                    myPen = new Pen(Color.Pink, 4);
                    s.Graphics.DrawRectangle(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.W), Convert.ToInt32(this.H)));
                    myPen.Dispose();
                    break;
                case "Purple":
                    myPen = new Pen(Color.Purple, 4);
                    s.Graphics.DrawRectangle(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.W), Convert.ToInt32(this.H)));
                    myPen.Dispose();
                    break;
                case "Red":
                    myPen = new Pen(Color.Red, 4);
                    s.Graphics.DrawRectangle(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.W), Convert.ToInt32(this.H)));
                    myPen.Dispose();
                    break;
                default:
                    myPen = new Pen(Color.Black, 4);
                    MessageBox.Show("Because you didn't Selected a Color, the Default BLACK Color was applied");
                    s.Graphics.DrawRectangle(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.W), Convert.ToInt32(this.H)));
                    break;
            }
        }
    }
}

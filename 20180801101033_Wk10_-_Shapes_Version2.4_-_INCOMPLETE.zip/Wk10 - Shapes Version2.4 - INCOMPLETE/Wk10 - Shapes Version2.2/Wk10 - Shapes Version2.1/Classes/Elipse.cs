﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;


namespace Wk10___Shapes_Version2._1.Classes
{
    public class Elipse : Shapes
    {
        private double Rx;
        private double Ry;//R = Radius
        public double Rx1 { get => Rx; set => Rx = value; }
        public double Ry1 { get => Ry; set => Ry = value; }

        public Elipse()
        {
            this.X = 0.00;
            this.Y = 0.00;
            this.Rx = 0.00;
            this.Ry = 0.00;
        }
        public Elipse(double Rx, double Ry, double X, double Y) : base(X,Y)
        {
            this.X = X;
            this.Y = Y;
            this.Rx1 = Rx;
            this.Ry1 = Ry;
        }
        public override double CA() //CALCULE AREA
        {
            return 3.14 * this.Rx * this.Ry;
        }
        public override double CP() //CALCULE PERIMETER
        {
            double t;
            t = (Rx * Rx) + (Ry * Ry);

            return 2 * 3.14 * Math.Sqrt(t) / 2;

        }
        public override String ToString()
        {
            String D = "(" + this.X + ", " + this.Y + ")" + "\t" + this.Rx + "  " + this.Ry + "  " + Math.Round(this.CP()) + "  " + Math.Round(this.CA());
            return D;
        }
        public override void Draw(PaintEventArgs s, string F, string U)
        {
            //F = Fill
            //U = Underline
            string SUC = U; //Selected Underline Color
            string SFC = F; //Selected Fill Color
            switch (SUC)
            {
                case "Blue":
                    Pen myPen = new Pen(Color.Blue, 4);
                    s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    myPen.Dispose();
                    break;
                case "Yellow":
                    myPen = new Pen(Color.Yellow, 4);
                    s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    myPen.Dispose();
                    break;
                case "Green":
                    myPen = new Pen(Color.Green, 4);
                    s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    myPen.Dispose();
                    break;
                case "Pink":
                    myPen = new Pen(Color.Pink, 4);
                    s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    myPen.Dispose();
                    break;
                case "Purple":
                    myPen = new Pen(Color.Purple, 4);
                    s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    myPen.Dispose();
                    break;
                case "Red":
                    myPen = new Pen(Color.Red, 4);
                    s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    myPen.Dispose();
                    break;
                default:
                    myPen = new Pen(Color.Black, 4);
                    MessageBox.Show("Because you didn't Selected a Color, the Default BLACK Color was applied");
                    s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    break;
            }
            switch (SFC)
            {
                case "Blue":
                    s.Graphics.FillEllipse(Brushes.Blue, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    break;
                case "Yellow":
                    s.Graphics.FillEllipse(Brushes.Yellow, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    break;
                case "Green":
                    s.Graphics.FillEllipse(Brushes.Green, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    break;
                case "Pink":
                    s.Graphics.FillEllipse(Brushes.Pink, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    break;
                case "Purple":
                    s.Graphics.FillEllipse(Brushes.Purple, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    break;
                case "Red":
                    s.Graphics.FillEllipse(Brushes.Red, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    break;
                default:
                    MessageBox.Show("Because you didn't Selected a Color, the Default BLACK Color was applied");
                    s.Graphics.FillEllipse(Brushes.Black, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    break;
            }
        }
    }
}

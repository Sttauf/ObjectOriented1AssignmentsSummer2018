﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using WindowsFormsApp8.bus;
using System.IO;
using System.Windows.Forms;

namespace WindowsFormsApp8.data
{
    class FileHandler
    {
        List<MountainBike> listOfMBike = new List<MountainBike>();
        List<RoadBike> listOfRBike = new List<RoadBike>();
        List<Bikes> listOfBike = new List<Bikes>();
        private static String xmlPath = @"../../data/studentFile.xml";

        public static void SaveXml(List<Bikes> listOfBikes, List<MountainBike> listOfMBike, List<RoadBike> listOfRBike)
        {
            try
            {
                XmlWriter writer = XmlWriter.Create(xmlPath);
                XmlSerializer serializer = new XmlSerializer(typeof(List<MountainBike>));
                serializer.Serialize(writer, listOfMBike);
                writer.Close();
                XmlWriter writer2 = XmlWriter.Create(xmlPath);
                XmlSerializer serializer2 = new XmlSerializer(typeof(List<RoadBike>));
                serializer2.Serialize(writer2, listOfRBike);
                writer2.Close();
            }
            catch { }
        }

        public static void LoadXml()
        {
            List<MountainBike> listOfMBike = new List<MountainBike>();
            List<RoadBike> listOfRBike = new List<RoadBike>();
            List<Bikes> listOfBike = new List<Bikes>();
            listOfMBike.Clear();
            listOfRBike.Clear();
            try
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<MountainBike>));
                StreamReader reader = new StreamReader(xmlPath);
                listOfMBike = (List<MountainBike>)xmlSerializer.Deserialize(reader);
                reader.Close();
                XmlSerializer xmlSerializer2 = new XmlSerializer(typeof(List<RoadBike>));
                StreamReader reader2 = new StreamReader(xmlPath);
                listOfRBike = (List<RoadBike>)xmlSerializer2.Deserialize(reader2);
                reader2.Close();
            }
            catch
            { }            

        }
    }
}

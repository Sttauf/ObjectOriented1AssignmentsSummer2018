﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp8.bus;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using WindowsFormsApp8.data;

namespace WindowsFormsApp8
{
    public partial class MyBicycle : Form
    {
        List<MountainBike> listOfMBike = new List<MountainBike>();
        List<RoadBike> listOfRBike = new List<RoadBike>();
        List<Bikes> listOfBikes = new List<Bikes>();
        private int index = 0;
        public MyBicycle()
        {
            InitializeComponent();
        }
        private void MyBicycle_Load(object sender, EventArgs e)
        {
            foreach (EnumType element in Enum.GetValues(typeof(EnumType)))
            {
                comboBox1.Items.Add(element);
            }
            foreach (Suspention element in Enum.GetValues(typeof(Suspention)))
            {
                comboBox2.Items.Add(element);
            }
            this.textBoxS.Enabled = false;
            this.textBoxMo.Enabled = false;
            this.textBoxMa.Enabled = false;
            this.textBoxMaY.Enabled = false;
            this.textBoxSp.Enabled = false;
            this.textBoxCo.Enabled = false;
            this.comboBox2.Enabled = false;
            this.textBoxMH.Enabled = false;
            this.textBoxSH.Enabled = false;
        }


        //ComboBox 
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                this.textBoxS.Enabled = true;
                this.textBoxMo.Enabled = true;
                this.textBoxMa.Enabled = true;
                this.textBoxMaY.Enabled = true;
                this.textBoxSp.Enabled = true;
                this.textBoxCo.Enabled = true;
                this.comboBox2.Enabled = true;
                this.textBoxMH.Enabled = true;
                this.textBoxSH.Enabled = false;
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                this.textBoxS.Enabled = true;
                this.textBoxMo.Enabled = true;
                this.textBoxMa.Enabled = true;
                this.textBoxMaY.Enabled = true;
                this.textBoxSp.Enabled = true;
                this.textBoxCo.Enabled = true;
                this.comboBox2.Enabled = false;
                this.textBoxMH.Enabled = false;
                this.textBoxSH.Enabled = true;
            }
            else
            {
                this.textBoxS.Enabled = false;
                this.textBoxMo.Enabled = false;
                this.textBoxMa.Enabled = false;
                this.textBoxMaY.Enabled = false;
                this.textBoxSp.Enabled = false;
                this.textBoxCo.Enabled = false;
                this.comboBox2.Enabled = false;
                this.textBoxMH.Enabled = false;
                this.textBoxSH.Enabled = false;
            }

        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0){ }
            else if (comboBox2.SelectedIndex == 1){ }
        }

        //BUTTONS  
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.SelectedIndex == 0)
                {
                    MountainBike aMB = new MountainBike();
                    aMB.S1 = Convert.ToInt32(textBoxS.Text);
                    aMB.Mo1 = textBoxMo.Text;
                    aMB.Ma1 = textBoxMa.Text;
                    aMB.MaY1 = Convert.ToInt32(textBoxMaY.Text);
                    aMB.Sp1 = Convert.ToDouble(textBoxSp.Text);
                    aMB.Co1 = textBoxCo.Text;
                    aMB.MH1 = Convert.ToDouble(textBoxMH.Text);
                    aMB.Su1 = (Suspention)comboBox2.SelectedIndex;
                    this.listOfMBike.Add(aMB);
                    this.listOfBikes.Add(aMB);
                    textBoxS.Clear();
                    textBoxMa.Clear();
                    textBoxMo.Clear();
                    textBoxMaY.Clear();
                    textBoxSp.Clear();
                    textBoxCo.Clear();
                    textBoxMH.Clear();

                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    RoadBike aRB = new RoadBike();
                    aRB.S1 = Convert.ToInt32(textBoxS.Text);
                    aRB.Mo1 = textBoxMo.Text;
                    aRB.Ma1 = textBoxMa.Text;
                    aRB.MaY1 = Convert.ToInt32(textBoxMaY.Text);
                    aRB.Mo1 = textBoxMo.Text;
                    aRB.Sp1 = Convert.ToDouble(textBoxSp.Text);
                    aRB.Co1 = textBoxCo.Text;
                    aRB.SH1 = Convert.ToInt32(textBoxSH.Text);
                    this.listOfRBike.Add(aRB);
                    this.listOfBikes.Add(aRB);
                    textBoxS.Clear();
                    textBoxMa.Clear();
                    textBoxMo.Clear();
                    textBoxMaY.Clear();
                    textBoxSp.Clear();
                    textBoxCo.Clear();
                    textBoxSH.Clear();
                }
                else { MessageBox.Show("ERROR: You didn't choose a type!"); }
            }
            catch { MessageBox.Show("ERROR: You've added incorrect info"); }
        }//Add
        private void buttonSearch_Click(object sender, EventArgs e)
        {
            try
            {
                MountainBike aMB = new MountainBike();
                bool found = false;
                foreach (MountainBike element in listOfMBike)
                {
                    if (element.S1 == Convert.ToInt32(textBox1.Text))
                    {
                        found = true; aMB = element;
                    }
                }

                if (found)
                {
                    MessageBox.Show(aMB.ToString() + comboBox2.SelectedIndex);
                }
                else
                {
                    MessageBox.Show(textBox1.Text + " There is no Mountain Bike with this info");
                }
                RoadBike aRB = new RoadBike();
                found = false;
                foreach (RoadBike element in listOfRBike)
                {
                    if (element.S1 == Convert.ToInt32(textBox1.Text))
                    {
                        found = true; aRB = element;
                    }
                }

                if (found)
                {
                    MessageBox.Show(aRB.ToString());
                }
                else
                {
                    MessageBox.Show(textBox1.Text + " There is no Road Bike with this info");
                }
            }
            catch { MessageBox.Show("Add a serial number to search"); }
        }//Search
        private void buttonEdit_Click(object sender, EventArgs e)
        {
            listBoxAll.Items.Clear();
            listBoxMountain.Items.Clear();
            listBoxRoad.Items.Clear();
            MountainBike aMB = new MountainBike();
            bool found = false;
            foreach (MountainBike element in listOfMBike)
            {
                if (element.S1 == Convert.ToInt32(textBox1.Text))
                {
                    found = true; aMB = element;
                }
            }
            if (found)
            {
                listOfMBike[index].S1 = Convert.ToInt32(textBoxS.Text);
                listOfMBike[index].Ma1 = textBoxMa.Text;
                listOfMBike[index].Mo1 = textBoxMo.Text;
                listOfMBike[index].MaY1 = Convert.ToInt32(textBoxMaY.Text);
                listOfMBike[index].Sp1 = Convert.ToDouble(textBoxSp.Text);
                listOfMBike[index].Co1 = textBoxCo.Text;
                listOfMBike[index].MH1 = Convert.ToDouble(textBoxMH.Text);
            }
            else
            {
                MessageBox.Show(textBox1.Text + " There is no Mountain Bike with this info");
            }
            RoadBike aRB = new RoadBike();
            found = false;
            foreach (RoadBike element in listOfRBike)
            {
                if (element.S1 == Convert.ToInt32(textBox1.Text))
                {
                    found = true; aRB = element;
                }
            }
            if (found)
            {
                listOfRBike[index].S1 = Convert.ToInt32(textBoxS.Text);
                listOfRBike[index].Ma1 = textBoxMa.Text;
                listOfRBike[index].Mo1 = textBoxMo.Text;
                listOfRBike[index].MaY1 = Convert.ToInt32(textBoxMaY.Text);
                listOfRBike[index].Sp1 = Convert.ToDouble(textBoxSp.Text);
                listOfRBike[index].Co1 = textBoxCo.Text;
                listOfRBike[index].SH1 = Convert.ToInt32(textBoxSH.Text);
            }
            else
            {
                MessageBox.Show(textBox1.Text + " There is no Road Bike with this info");
            }
        }//Edit
        private void buttonRemove_Click(object sender, EventArgs e)
        {
            listBoxAll.Items.Clear();
            listBoxMountain.Items.Clear();
            listBoxRoad.Items.Clear();
            try
            {
                MountainBike aMB = new MountainBike();
                bool found = false;
                foreach (MountainBike element in listOfMBike)
                {
                    if (element.S1 == Convert.ToInt32(textBox1.Text))
                    {
                        found = true; aMB = element;
                    }
                }
                if (found)
                {
                    MessageBox.Show("Info removed in mountain bike: " + aMB.ToString());
                    listOfMBike.RemoveAt(index);
                }
                else
                {
                    MessageBox.Show(textBox1.Text + "No one with this info in Mountain Bikes");
                }
                RoadBike aRB = new RoadBike();
                found = false;
                foreach (RoadBike element in listOfRBike)
                {
                    if (element.S1 == Convert.ToInt32(textBox1.Text))
                    {
                        found = true; aRB = element;
                    }
                }

                if (found)
                {
                    MessageBox.Show("Info removed in Road Bikes: " + aRB.ToString());
                    listOfRBike.RemoveAt(index);
                }
                else
                {
                    MessageBox.Show(textBox1.Text + "No one with this info in Road Bikes");
                }
            }
            catch { MessageBox.Show(textBox1.Text + "Add a Serial Number"); }

        }//Remove
        private void buttonDisplayAll_Click(object sender, EventArgs e)
        {
            listBoxAll.Items.Clear();
            listBoxMountain.Items.Clear();
            listBoxRoad.Items.Clear();
            if (this.listOfMBike.Capacity != 0 && this.listOfRBike.Capacity == 0)
            {
                foreach (MountainBike aMB in this.listOfMBike)
                {
                    this.listBoxMountain.Items.Add(aMB.ToString());
                    this.listBoxAll.Items.Add(aMB.ToString());

                }
                this.listBoxRoad.Items.Add("No data");
            }
            else if (this.listOfRBike.Capacity != 0 && this.listOfMBike.Capacity == 0)
            {
                foreach (RoadBike aRB in this.listOfRBike)
                {
                    this.listBoxRoad.Items.Add(aRB.ToString());
                    this.listBoxAll.Items.Add(aRB.ToString());
                }
                this.listBoxMountain.Items.Add("No data");
            }
            else if (this.listOfRBike.Capacity != 0 && this.listOfMBike.Capacity != 0)
            {
                foreach (MountainBike aMB in this.listOfMBike)
                {
                    this.listBoxMountain.Items.Add(aMB.ToString());
                    this.listBoxAll.Items.Add(aMB.ToString());

                }
                foreach (RoadBike aRB in this.listOfRBike)
                {
                    this.listBoxRoad.Items.Add(aRB.ToString());
                    this.listBoxAll.Items.Add(aRB.ToString());
                }

            }
            else
            {
                this.listBoxRoad.Items.Add("No data");
                this.listBoxMountain.Items.Add("No data");
                this.listBoxAll.Items.Add("No data");
            }
        }//Display All
        private void buttonDisplayM_Click(object sender, EventArgs e)
        {
            listBoxAll.Items.Clear();
            listBoxMountain.Items.Clear();
            listBoxRoad.Items.Clear();
            if (this.listOfMBike.Capacity != 0)
            {
                this.listBoxRoad.Items.Clear();
                this.listBoxAll.Items.Clear();
                foreach (MountainBike aMB in this.listOfMBike)
                {
                    this.listBoxMountain.Items.Add(aMB.ToString());
                }
            }
            else { this.listBoxMountain.Items.Add("No data");}
        }//Display Mountain
        private void buttonDisplayR_Click(object sender, EventArgs e)
        {
            listBoxAll.Items.Clear();
            listBoxMountain.Items.Clear();
            listBoxRoad.Items.Clear();
            if (this.listOfRBike.Capacity != 0)
            {
                this.listBoxMountain.Items.Clear();
                this.listBoxAll.Items.Clear();
                foreach (RoadBike aRB in this.listOfRBike)
                {
                    this.listBoxRoad.Items.Add(aRB.ToString());
                }
            }
            else { this.listBoxRoad.Items.Add("No data"); }
        }//Display Road
        
        //XML
        private void buttonSaveXML_Click(object sender, EventArgs e)
        {
            FileHandler.SaveXml(listOfBikes, listOfMBike, listOfRBike);
        }//Save
        private void buttonLoadXML_Click(object sender, EventArgs e)
        {
            listBoxAll.Items.Clear();
            listBoxMountain.Items.Clear();
            listBoxRoad.Items.Clear();
            FileHandler.LoadXml();
            try
            {
                foreach (MountainBike aMB in listOfMBike)
                {
                    this.listBoxMountain.Items.Add(aMB);
                }
                foreach (RoadBike aRB in listOfRBike)
                {
                    this.listBoxRoad.Items.Add(aRB);
                }
            }
            catch
            {
                
            }
        }//Load
    }
}

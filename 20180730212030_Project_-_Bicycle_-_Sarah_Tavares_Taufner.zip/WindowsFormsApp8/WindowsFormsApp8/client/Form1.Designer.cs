﻿namespace WindowsFormsApp8
{
    partial class MyBicycle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxAll = new System.Windows.Forms.ListBox();
            this.listBoxMountain = new System.Windows.Forms.ListBox();
            this.listBoxRoad = new System.Windows.Forms.ListBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.textBoxS = new System.Windows.Forms.TextBox();
            this.textBoxMa = new System.Windows.Forms.TextBox();
            this.textBoxMo = new System.Windows.Forms.TextBox();
            this.textBoxMaY = new System.Windows.Forms.TextBox();
            this.textBoxSp = new System.Windows.Forms.TextBox();
            this.textBoxCo = new System.Windows.Forms.TextBox();
            this.textBoxSH = new System.Windows.Forms.TextBox();
            this.textBoxMH = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.buttonEdit = new System.Windows.Forms.Button();
            this.buttonRemove = new System.Windows.Forms.Button();
            this.buttonSaveXML = new System.Windows.Forms.Button();
            this.buttonLoadXML = new System.Windows.Forms.Button();
            this.buttonDisplayAll = new System.Windows.Forms.Button();
            this.buttonDisplayM = new System.Windows.Forms.Button();
            this.buttonDisplayR = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBoxAll
            // 
            this.listBoxAll.FormattingEnabled = true;
            this.listBoxAll.ItemHeight = 20;
            this.listBoxAll.Location = new System.Drawing.Point(453, 38);
            this.listBoxAll.Name = "listBoxAll";
            this.listBoxAll.Size = new System.Drawing.Size(421, 284);
            this.listBoxAll.TabIndex = 0;
            // 
            // listBoxMountain
            // 
            this.listBoxMountain.FormattingEnabled = true;
            this.listBoxMountain.ItemHeight = 20;
            this.listBoxMountain.Location = new System.Drawing.Point(452, 356);
            this.listBoxMountain.Name = "listBoxMountain";
            this.listBoxMountain.Size = new System.Drawing.Size(208, 164);
            this.listBoxMountain.TabIndex = 1;
            // 
            // listBoxRoad
            // 
            this.listBoxRoad.FormattingEnabled = true;
            this.listBoxRoad.ItemHeight = 20;
            this.listBoxRoad.Location = new System.Drawing.Point(666, 356);
            this.listBoxRoad.Name = "listBoxRoad";
            this.listBoxRoad.Size = new System.Drawing.Size(208, 164);
            this.listBoxRoad.TabIndex = 2;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(131, 32);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 28);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(131, 290);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 28);
            this.comboBox2.TabIndex = 4;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // textBoxS
            // 
            this.textBoxS.Location = new System.Drawing.Point(131, 66);
            this.textBoxS.Name = "textBoxS";
            this.textBoxS.Size = new System.Drawing.Size(121, 26);
            this.textBoxS.TabIndex = 5;
            // 
            // textBoxMa
            // 
            this.textBoxMa.Location = new System.Drawing.Point(131, 98);
            this.textBoxMa.Name = "textBoxMa";
            this.textBoxMa.Size = new System.Drawing.Size(121, 26);
            this.textBoxMa.TabIndex = 6;
            // 
            // textBoxMo
            // 
            this.textBoxMo.Location = new System.Drawing.Point(131, 130);
            this.textBoxMo.Name = "textBoxMo";
            this.textBoxMo.Size = new System.Drawing.Size(121, 26);
            this.textBoxMo.TabIndex = 7;
            // 
            // textBoxMaY
            // 
            this.textBoxMaY.Location = new System.Drawing.Point(131, 162);
            this.textBoxMaY.Name = "textBoxMaY";
            this.textBoxMaY.Size = new System.Drawing.Size(121, 26);
            this.textBoxMaY.TabIndex = 8;
            // 
            // textBoxSp
            // 
            this.textBoxSp.Location = new System.Drawing.Point(131, 194);
            this.textBoxSp.Name = "textBoxSp";
            this.textBoxSp.Size = new System.Drawing.Size(121, 26);
            this.textBoxSp.TabIndex = 9;
            // 
            // textBoxCo
            // 
            this.textBoxCo.Location = new System.Drawing.Point(131, 226);
            this.textBoxCo.Name = "textBoxCo";
            this.textBoxCo.Size = new System.Drawing.Size(121, 26);
            this.textBoxCo.TabIndex = 10;
            // 
            // textBoxSH
            // 
            this.textBoxSH.Location = new System.Drawing.Point(131, 258);
            this.textBoxSH.Name = "textBoxSH";
            this.textBoxSH.Size = new System.Drawing.Size(121, 26);
            this.textBoxSH.TabIndex = 11;
            // 
            // textBoxMH
            // 
            this.textBoxMH.Location = new System.Drawing.Point(312, 322);
            this.textBoxMH.Name = "textBoxMH";
            this.textBoxMH.Size = new System.Drawing.Size(121, 26);
            this.textBoxMH.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "Type:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 20);
            this.label2.TabIndex = 14;
            this.label2.Text = "Serial Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 20);
            this.label3.TabIndex = 15;
            this.label3.Text = "Made:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 133);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 20);
            this.label4.TabIndex = 16;
            this.label4.Text = "Model: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 165);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 20);
            this.label5.TabIndex = 17;
            this.label5.Text = "Made Year:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 197);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 20);
            this.label6.TabIndex = 18;
            this.label6.Text = "Speed:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 229);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 20);
            this.label7.TabIndex = 19;
            this.label7.Text = "Colour:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 261);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 20);
            this.label8.TabIndex = 20;
            this.label8.Text = "Seat height:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 325);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(294, 20);
            this.label9.TabIndex = 21;
            this.label9.Text = "Measurement of the height from ground:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 293);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 20);
            this.label10.TabIndex = 22;
            this.label10.Text = "Suspension:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(449, 333);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(143, 20);
            this.label11.TabIndex = 23;
            this.label11.Text = "Mountain Bike List:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(662, 333);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(116, 20);
            this.label12.TabIndex = 24;
            this.label12.Text = "Road Bike List:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(448, 12);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(110, 20);
            this.label13.TabIndex = 25;
            this.label13.Text = "Complete List:";
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(137, 356);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(75, 32);
            this.buttonAdd.TabIndex = 26;
            this.buttonAdd.Text = "Add";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonSearch
            // 
            this.buttonSearch.Location = new System.Drawing.Point(277, 488);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(75, 32);
            this.buttonSearch.TabIndex = 27;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.UseVisualStyleBackColor = true;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // buttonEdit
            // 
            this.buttonEdit.Location = new System.Drawing.Point(218, 356);
            this.buttonEdit.Name = "buttonEdit";
            this.buttonEdit.Size = new System.Drawing.Size(75, 32);
            this.buttonEdit.TabIndex = 28;
            this.buttonEdit.Text = "Edit";
            this.buttonEdit.UseVisualStyleBackColor = true;
            this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
            // 
            // buttonRemove
            // 
            this.buttonRemove.Location = new System.Drawing.Point(358, 488);
            this.buttonRemove.Name = "buttonRemove";
            this.buttonRemove.Size = new System.Drawing.Size(80, 32);
            this.buttonRemove.TabIndex = 29;
            this.buttonRemove.Text = "Remove";
            this.buttonRemove.UseVisualStyleBackColor = true;
            this.buttonRemove.Click += new System.EventHandler(this.buttonRemove_Click);
            // 
            // buttonSaveXML
            // 
            this.buttonSaveXML.Location = new System.Drawing.Point(277, 396);
            this.buttonSaveXML.Name = "buttonSaveXML";
            this.buttonSaveXML.Size = new System.Drawing.Size(75, 32);
            this.buttonSaveXML.TabIndex = 30;
            this.buttonSaveXML.Text = "Save";
            this.buttonSaveXML.UseVisualStyleBackColor = true;
            this.buttonSaveXML.Click += new System.EventHandler(this.buttonSaveXML_Click);
            // 
            // buttonLoadXML
            // 
            this.buttonLoadXML.Location = new System.Drawing.Point(358, 396);
            this.buttonLoadXML.Name = "buttonLoadXML";
            this.buttonLoadXML.Size = new System.Drawing.Size(75, 32);
            this.buttonLoadXML.TabIndex = 31;
            this.buttonLoadXML.Text = "Load";
            this.buttonLoadXML.UseVisualStyleBackColor = true;
            this.buttonLoadXML.Click += new System.EventHandler(this.buttonLoadXML_Click);
            // 
            // buttonDisplayAll
            // 
            this.buttonDisplayAll.Location = new System.Drawing.Point(185, 434);
            this.buttonDisplayAll.Name = "buttonDisplayAll";
            this.buttonDisplayAll.Size = new System.Drawing.Size(75, 32);
            this.buttonDisplayAll.TabIndex = 32;
            this.buttonDisplayAll.Text = "All";
            this.buttonDisplayAll.UseVisualStyleBackColor = true;
            this.buttonDisplayAll.Click += new System.EventHandler(this.buttonDisplayAll_Click);
            // 
            // buttonDisplayM
            // 
            this.buttonDisplayM.Location = new System.Drawing.Point(266, 434);
            this.buttonDisplayM.Name = "buttonDisplayM";
            this.buttonDisplayM.Size = new System.Drawing.Size(86, 32);
            this.buttonDisplayM.TabIndex = 33;
            this.buttonDisplayM.Text = "Mountain";
            this.buttonDisplayM.UseVisualStyleBackColor = true;
            this.buttonDisplayM.Click += new System.EventHandler(this.buttonDisplayM_Click);
            // 
            // buttonDisplayR
            // 
            this.buttonDisplayR.Location = new System.Drawing.Point(358, 434);
            this.buttonDisplayR.Name = "buttonDisplayR";
            this.buttonDisplayR.Size = new System.Drawing.Size(75, 32);
            this.buttonDisplayR.TabIndex = 34;
            this.buttonDisplayR.Text = "Road";
            this.buttonDisplayR.UseVisualStyleBackColor = true;
            this.buttonDisplayR.Click += new System.EventHandler(this.buttonDisplayR_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(225, 402);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(46, 20);
            this.label15.TabIndex = 36;
            this.label15.Text = "XML:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(119, 440);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 20);
            this.label16.TabIndex = 37;
            this.label16.Text = "Display:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(171, 491);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 26);
            this.textBox1.TabIndex = 38;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(52, 494);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(113, 20);
            this.label14.TabIndex = 39;
            this.label14.Text = "Serial Number:";
            // 
            // MyBicycle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(882, 528);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.buttonDisplayR);
            this.Controls.Add(this.buttonDisplayM);
            this.Controls.Add(this.buttonDisplayAll);
            this.Controls.Add(this.buttonLoadXML);
            this.Controls.Add(this.buttonSaveXML);
            this.Controls.Add(this.buttonRemove);
            this.Controls.Add(this.buttonEdit);
            this.Controls.Add(this.buttonSearch);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxMH);
            this.Controls.Add(this.textBoxSH);
            this.Controls.Add(this.textBoxCo);
            this.Controls.Add(this.textBoxSp);
            this.Controls.Add(this.textBoxMaY);
            this.Controls.Add(this.textBoxMo);
            this.Controls.Add(this.textBoxMa);
            this.Controls.Add(this.textBoxS);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.listBoxRoad);
            this.Controls.Add(this.listBoxMountain);
            this.Controls.Add(this.listBoxAll);
            this.Name = "MyBicycle";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.MyBicycle_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxAll;
        private System.Windows.Forms.ListBox listBoxMountain;
        private System.Windows.Forms.ListBox listBoxRoad;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBoxS;
        private System.Windows.Forms.TextBox textBoxMa;
        private System.Windows.Forms.TextBox textBoxMo;
        private System.Windows.Forms.TextBox textBoxMaY;
        private System.Windows.Forms.TextBox textBoxSp;
        private System.Windows.Forms.TextBox textBoxCo;
        private System.Windows.Forms.TextBox textBoxSH;
        private System.Windows.Forms.TextBox textBoxMH;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.Button buttonEdit;
        private System.Windows.Forms.Button buttonRemove;
        private System.Windows.Forms.Button buttonSaveXML;
        private System.Windows.Forms.Button buttonLoadXML;
        private System.Windows.Forms.Button buttonDisplayAll;
        private System.Windows.Forms.Button buttonDisplayM;
        private System.Windows.Forms.Button buttonDisplayR;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label14;
    }
}


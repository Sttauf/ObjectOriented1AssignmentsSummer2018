﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp8.bus
{
    class DataAccess
    {
            private static List<Bikes> myListOfBike;
         public static List<Bikes> MyListOfBike { get => myListOfBike; set => myListOfBike = value; }
            public static int Count
            {
                get
                {
                    return myListOfBike.Count;
                }
            }
        public static void Clear()
            {
                myListOfBike.Clear();
            }
            public static void Add(Bikes anObject)
            {
                myListOfBike.Add(anObject);
            }
            public static void Remove(Bikes anObject)
            {
                myListOfBike.Remove(anObject);
            }
            public static void RemoveAt(int index)
            {
                myListOfBike.RemoveAt(index);
            }
        }
    }
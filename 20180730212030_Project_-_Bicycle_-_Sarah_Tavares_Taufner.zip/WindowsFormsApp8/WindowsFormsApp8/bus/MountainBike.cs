﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp8.bus
{
    public enum Suspention { Front, Rear, Both }
    [Serializable]
    public class MountainBike : Bikes
    {
        private double MH; //measurement of the height
        private Suspention Su;
        public double MH1 { get => MH; set => MH = value; }
        public Suspention Su1 { get => Su; set => Su = value; }

        public MountainBike()
        {
            this.S1 = 00;
            this.Mo1 = "";
            this.Ma1 = "";
            this.MaY1 = 0000;
            this.Sp1 = 0.00;
            this.Co1 = "";
            this.MH1 = 0.00;
        }
        public MountainBike(int S, string Mo, string Ma, int MaY, double Sp, string Co, double MH) : base(S, Mo, Ma, MaY, Sp, Co)
        {
            this.S1 = S;
            this.Mo1 = Mo;
            this.Ma1 = Ma;
            this.MaY1 = MaY;
            this.Sp1 = Sp;
            this.MH1 = MH;
        }
        public override String ToString()
        {
            string state;
            state = this.S1 + "\t" + this.Mo1 + "\t" + this.Ma1 + "\t" + this.MaY1 + "\t" + this.Sp1 + "\t" + this.Co1 + "\t" + this.MH1 + "\t" + this.Su1;
            return state;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp8.bus
{

    [Serializable]
    public class RoadBike : Bikes
    {
        private int SH; //Seat Height

        //Get and Set
        public int SH1 { get => SH; set => SH = value; }

        public RoadBike()
        {
            this.S1 = 00;
            this.Mo1 = "";
            this.Ma1 = "";
            this.MaY1 = 0000;
            this.Sp1 = 0.00;
            this.Co1 = "";
            this.SH1 = 00;
        }
        public RoadBike(int S, string Mo, string Ma, int MaY, double Sp, string Co, int SH)  : base(S,Mo,Ma,MaY, Sp,Co)
        {
            this.S1 = S;
            this.Mo1 = Mo;
            this.Ma1 = Ma;
            this.MaY1 = MaY;
            this.Sp1 = Sp;
            this.SH1 = SH;
        }
        public override String ToString()
        {
            string state;
            state = this.S1 + "\t" + this.Mo1 + "\t" + this.Ma1 + "\t" + this.MaY1 + "\t" + this.Sp1 + "\t" + this.Co1 + "\t" + this.SH1;
            return state;
        }
    }
}

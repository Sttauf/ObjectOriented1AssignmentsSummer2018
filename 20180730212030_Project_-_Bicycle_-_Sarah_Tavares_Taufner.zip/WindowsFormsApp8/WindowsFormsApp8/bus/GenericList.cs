﻿using System;
using System.Collections.Generic;

namespace WindowsFormsApp4
{
    [Serializable]
    public class GenericList<AnyType>
    {
        private List<AnyType> myList = new List<AnyType>();
        public int Count { get { return myList.Count; } }
        public AnyType this[int i] //[] = array
        { get { return myList[i]; } }
        public void Clear()
        {
            myList.Clear();
        }
        public void Add(AnyType anObject)
        {
            myList.Add(anObject);
        }
        public void Remove(AnyType anObject)
        {
            myList.Remove(anObject);
        }
        public void Remove(int index)
        {
            myList.RemoveAt(index);
        }
        public List<AnyType> MyList { get { return myList; } set { myList = value; } }
        public override String ToString()
        {
            String state = "";
            for (int i = 0; i < myList.Count; i++)
            {
                state += myList[i].ToString() + "\n";
            }
            return state;
        }

    }
}

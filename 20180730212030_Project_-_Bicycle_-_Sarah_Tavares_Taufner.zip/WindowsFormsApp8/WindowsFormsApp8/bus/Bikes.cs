﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp8.bus
{
    public enum EnumType { MountainBike, RoadBike }
    [Serializable]
    public abstract class Bikes
    { 
        //Declaring Variables
        private int S; //Serial Number
        private string Mo; //Model
        private string Ma; //Made
        private int MaY; //Made Year
        private double Sp; //Speed
        private string Co; //Colour

        //Get and Set
        public int S1 { get => S; set => S = value; }
        public string Mo1 { get => Mo; set => Mo = value; }
        public string Ma1 { get => Ma; set => Ma = value; }
        public int MaY1 { get => MaY; set => MaY = value; }
        public double Sp1 { get => Sp; set => Sp = value; }
        public string Co1 { get => Co; set => Co = value; }
        
        //Bikes()
        public Bikes()
        {
            this.S = 00;
            this.Mo = "";
            this.Ma = "";
            this.MaY = 0000;
            this.Sp = 0.00;
            this.Co = "";
        }

        //Bikes(+)
        public Bikes(int S, string Mo, string Ma, int May, double Sp, string Co)
        {
            this.S = S1;
            this.Mo = Mo1;
            this.Ma = Ma1;
            this.MaY = MaY1;
            this.Sp = Sp1;
            this.Co = Co1;
        }

        //ToString()
        public override String ToString()
        {
            string state;
            state = this.S1 + "\t" + this.Mo1 + "\t" + this.Ma1 + "\t" + this.MaY1 + "\t" + this.Sp1 + "\t" + this.Co1;
            return state;
        }
    }
}

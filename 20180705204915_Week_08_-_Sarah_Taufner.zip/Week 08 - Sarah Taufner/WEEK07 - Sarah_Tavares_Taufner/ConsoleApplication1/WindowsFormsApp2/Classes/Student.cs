﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2.Classes { 
    public enum EnumType { Undefined, PartTime, FullTime }
    public class Student : Member

    {//beginning class student
        private double firstFees;
        private double feesPerSession;
        private EnumType category;
        private Date registration;
        public double FirstFees
        {
            get
            {
                return firstFees;
            }

            set
            {
                firstFees = value;
            }
        }

        public double FeesPerSession
        {
            get
            {
                return feesPerSession;
            }

            set
            {
                feesPerSession = value;
            }
        }
        public EnumType Category
        {
            get { return category; }
            set { category = value; }
        }

        public Date Registration
        {
            get
            {
                return registration;
            }

            set
            {
                registration = value;
            }
        }
        public Student()
        {
            this.Id = 0000;
            this.FirstName = "Undefined";
            this.LastName = "Undefined";

            this.category = EnumType.Undefined;

            this.registration = new Date();
        }

        public Student(int id, String firstName, String lastName,
                                 EnumType category, Date regDate) : base(id, firstName, lastName)
        {
            this.Id = id; this.FirstName = firstName; this.LastName = LastName;

            this.category = category;
            this.registration = regDate;
        }
        public override String ToString()
        {
            String state;
            state = this.Id + "\t" + this.FirstName + "\t"
                + this.LastName + "\t"
                + this.Category + "\t"
                + this.registration;
            return state;
        }
    }
}

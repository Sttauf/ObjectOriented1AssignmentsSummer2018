﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2.Classes
{
    public class Teacher : Member
    {
        private double hoursOfWork;
        private double hoursByRate;
        private EnumType category;
        private Date registration;
        public double HoursOfWork
        {
            get
            {
                return hoursOfWork;
            }

            set
            {
                hoursOfWork = value;
            }
        }

        public double HoursByRate
        {
            get
            {
                return hoursByRate;
            }

            set
            {
                hoursByRate = value;
            }
        }

        public EnumType Category
        {
            get { return category; }
            set { category = value; }
        }

        public Date Registration
        {
            get
            {
                return registration;
            }

            set
            {
                registration = value;
            }
        }
        public Teacher()
        {
            this.Id = 0000;
            this.FirstName = "Undefined";
            this.LastName = "Undefined";

            this.category = EnumType.Undefined;

            this.registration = new Date();
        }

    public Teacher(int id, String firstName, String lastName, EnumType category, Date regDate) : base(id, firstName, lastName)
    {
            this.Id = id; this.FirstName = firstName; this.LastName = LastName;

            this.category = category;
            this.registration = regDate;
        }
        public override String ToString()
        {
            String state;
            state = this.Id + "\t" + this.FirstName + "\t"
                + this.LastName + "\t"
                + this.Category + "\t"
                + this.registration;
            return state;
        }

    }
}

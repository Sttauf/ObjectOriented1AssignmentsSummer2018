﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp2.Classes;
using System.IO;

namespace WindowsFormsApp2
{
 
    public partial class Form1: Form
    {
        List<Student> listOfStudents = new List<Student>();
        int index = 0;
        List<Teacher> listOfTeachers = new List<Teacher>();
        public Form1()
        {
            InitializeComponent();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBoxIDStudent != null)
                {
                    Student aStudent = new Student();

                    aStudent.FirstName = textBoxFNStudent.Text;
                    aStudent.LastName = textBoxLNStudent.Text;
                    aStudent.Id = Convert.ToInt32(textBoxIDStudent.Text);
                    aStudent.FirstFees = Convert.ToDouble(textBoxFirstFees.Text);
                    aStudent.FeesPerSession = Convert.ToDouble(textBoxFeesPerSection.Text);

                    aStudent.Category = (EnumType)comboBoxStudent.SelectedIndex;


                    aStudent.Registration = new Date(Convert.ToInt32(textBoxDDStudent.Text),
                                          Convert.ToInt32(textBoxMMStudent.Text), Convert.ToInt32(textBoxYYYYStudent.Text));
                    this.listOfStudents.Add(aStudent);

                }
                try
                {
                    if (textBoxIDTeacher != null)
                    {
                        Teacher aTeacher = new Teacher();

                        aTeacher.FirstName = textBoxFNTeacher.Text;
                        aTeacher.LastName = textBoxLNTeacher.Text;
                        aTeacher.Id = Convert.ToInt32(textBoxIDTeacher.Text);
                        aTeacher.HoursByRate = Convert.ToDouble(textBoxHrsByRate.Text);
                        aTeacher.HoursOfWork = Convert.ToDouble(textBoxHrsOfWork.Text);

                        aTeacher.Category = (EnumType)comboBoxTeacher.SelectedIndex;


                        aTeacher.Registration = new Date(Convert.ToInt32(textBoxDDTeacher.Text),
                                              Convert.ToInt32(textBoxMMTeacher.Text), Convert.ToInt32(textBoxYYYYTeacher.Text));
                        this.listOfTeachers.Add(aTeacher);
                    }
                }
                catch { }
            }
            catch
            {
                if (textBoxIDTeacher != null)
                {
                    Teacher aTeacher = new Teacher();

                    aTeacher.FirstName = textBoxFNTeacher.Text;
                    aTeacher.LastName = textBoxLNTeacher.Text;
                    aTeacher.Id = Convert.ToInt32(textBoxIDStudent.Text);
                    aTeacher.HoursByRate = Convert.ToDouble(textBoxHrsByRate.Text);
                    aTeacher.HoursOfWork = Convert.ToDouble(textBoxHrsOfWork.Text);

                    aTeacher.Category = (EnumType)comboBoxTeacher.SelectedIndex;


                    aTeacher.Registration = new Date(Convert.ToInt32(textBoxDDTeacher.Text),
                                          Convert.ToInt32(textBoxMMTeacher.Text), Convert.ToInt32(textBoxYYYYTeacher.Text));
                    this.listOfTeachers.Add(aTeacher);
                }
                try {
                    if (textBoxIDStudent != null)
                    {
                        Student aStudent = new Student();

                        aStudent.FirstName = textBoxFNStudent.Text;
                        aStudent.LastName = textBoxLNStudent.Text;
                        aStudent.Id = Convert.ToInt32(textBoxIDStudent.Text);
                        aStudent.FirstFees = Convert.ToDouble(textBoxFirstFees.Text);
                        aStudent.FeesPerSession = Convert.ToDouble(textBoxFeesPerSection.Text);

                        aStudent.Category = (EnumType)comboBoxStudent.SelectedIndex;


                        aStudent.Registration = new Date(Convert.ToInt32(textBoxDDStudent.Text),
                                              Convert.ToInt32(textBoxMMStudent.Text), Convert.ToInt32(textBoxYYYYStudent.Text));
                        this.listOfStudents.Add(aStudent);

                    }
                }
                catch { }
            }


            }

            private void buttonDisplay_Click(object sender, EventArgs e)
        {
            if (this.listOfStudents.Capacity != 0 && this.listOfTeachers.Capacity == 0)
            {
                foreach (Student aStudent in this.listOfStudents)
                {
                    this.listBoxStudent.Items.Add(aStudent);
                }
                this.listBoxTeacher.Items.Add("No data");
            }
            else if (this.listOfTeachers.Capacity != 0 && this.listOfStudents.Capacity == 0)
            {
                foreach (Teacher aTeacher in this.listOfTeachers)
                {
                    this.listBoxTeacher.Items.Add(aTeacher);
                }
                this.listBoxStudent.Items.Add("No data");
            } else if (this.listOfTeachers.Capacity != 0 && this.listOfStudents.Capacity != 0)
            {
                foreach (Student aStudent in this.listOfStudents)
                {
                    this.listBoxStudent.Items.Add(aStudent);
                }
                foreach (Teacher aTeacher in this.listOfTeachers)
                {
                    this.listBoxTeacher.Items.Add(aTeacher);
                }
            }
            else{
                this.listBoxTeacher.Items.Add("No data");
                this.listBoxStudent.Items.Add("No data");
            }
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            this.textBoxIDStudent.Text = "";
            this.textBoxFNStudent.Text = "";
            this.textBoxLNStudent.Text = "";
            this.textBoxDDStudent.Text = "";
            this.textBoxMMStudent.Text = "";
            this.textBoxYYYYStudent.Text = "";
            this.textBoxFeesPerSection.Text = "";
            this.textBoxFirstFees.Text = "";
            listBoxStudent.Items.Clear();
            this.textBoxIDTeacher.Text = "";
            this.textBoxFNTeacher.Text = "";
            this.textBoxLNTeacher.Text = "";
            this.textBoxDDTeacher.Text = "";
            this.textBoxMMTeacher.Text = "";
            this.textBoxYYYYTeacher.Text = "";
            this.textBoxHrsByRate.Text = "";
            this.textBoxHrsOfWork.Text = "";
            listBoxTeacher.Items.Clear();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void FormStudent_Load(object sender, EventArgs e)
        {
            foreach (EnumType element in Enum.GetValues(typeof(EnumType)))
            {
                comboBoxStudent.Items.Add(element);
            }
        }
        private void FormTeacher_Load(object sender, EventArgs e)
        {
            foreach (EnumType element in Enum.GetValues(typeof(EnumType)))
            {
                comboBoxTeacher.Items.Add(element);
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            Student aStudent = new Student();


            bool found = false;
            foreach (Student element in listOfStudents)
            {
                if (element.Id == Convert.ToInt32(textBoxSearch.Text))
                {
                    found = true; aStudent = element;
                }
            }

            if (found)
            {
                MessageBox.Show(aStudent.ToString());
            }
            else
            {
                MessageBox.Show(textBoxSearch.Text + "No one with this info in students");
            }
            Teacher aTeacher = new Teacher();
            found = false;
            foreach (Teacher element in listOfTeachers)
            {
                if (element.Id == Convert.ToInt32(textBoxSearch.Text))
                {
                    found = true; aTeacher = element;
                }
            }

            if (found)
            {
                MessageBox.Show(aTeacher.ToString());
            }
            else
            {
                MessageBox.Show(textBoxSearch.Text + "No one with this info in teachers");
            }

        }
        private void listBoxStudent_SelectedIndexChanged(object sender, EventArgs e)
        {
            index = listBoxStudent.SelectedIndex;
            MessageBox.Show(" ListBox Students index : " + index);

            textBoxIDStudent.Text = Convert.ToString(listOfStudents[index].Id);
            textBoxFNStudent.Text = listOfStudents[index].FirstName;
            textBoxLNStudent.Text = listOfStudents[index].LastName;

            comboBoxStudent.Text = Convert.ToString(this.listOfStudents[index].Category);


            textBoxMMStudent.Text = Convert.ToString(listOfStudents[index].Registration.Month);
            textBoxDDStudent.Text = Convert.ToString(listOfStudents[index].Registration.Day);
            textBoxYYYYStudent.Text = Convert.ToString(listOfStudents[index].Registration.Year);
        }
        private void listBoxTeacher_SelectedIndexChanged(object sender, EventArgs e)
        {
            index = listBoxTeacher.SelectedIndex;
            MessageBox.Show(" ListBox Teachers index : " + index);

            textBoxIDTeacher.Text = Convert.ToString(listOfTeachers[index].Id);
            textBoxFNTeacher.Text = listOfTeachers[index].FirstName;
            textBoxLNTeacher.Text = listOfTeachers[index].LastName;

            comboBoxTeacher.Text = Convert.ToString(this.listOfTeachers[index].Category);


            textBoxMMTeacher.Text = Convert.ToString(listOfTeachers[index].Registration.Month);
            textBoxDDTeacher.Text = Convert.ToString(listOfTeachers[index].Registration.Day);
            textBoxYYYYTeacher.Text = Convert.ToString(listOfTeachers[index].Registration.Year);
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            Student aStudent = new Student();


            bool found = false;
            foreach (Student element in listOfStudents)
            {
                if (element.Id == Convert.ToInt32(textBoxSearch.Text))
                {
                    found = true; aStudent = element;
                }
            }

            if (found)
            {
                MessageBox.Show("Info removed in students: " + aStudent.ToString());
                listOfStudents.RemoveAt(index); 
            }
            else
            {
                MessageBox.Show(textBoxSearch.Text + "No one with this info in students");
            }
            Teacher aTeacher = new Teacher();
            found = false;
            foreach (Teacher element in listOfTeachers)
            {
                if (element.Id == Convert.ToInt32(textBoxSearch.Text))
                {
                    found = true; aTeacher = element;
                }
            }

            if (found)
            {
                MessageBox.Show("Info removed in teachers: " + aTeacher.ToString());
                listOfTeachers.RemoveAt(index);
            }
            else
            {
                MessageBox.Show(textBoxSearch.Text + "No one with this info in teachers");
            }


            
        }

        private void buttonModify_Click(object sender, EventArgs e)
        {
            Student aStudent = new Student();


            bool found = false;
            foreach (Student element in listOfStudents)
            {
                if (element.Id == Convert.ToInt32(textBoxSearch.Text))
                {
                    found = true; aStudent = element;
                }
            }

            if (found)
            {
                        listOfStudents[index].Id = Convert.ToInt32(textBoxIDStudent.Text);
                        listOfStudents[index].FirstName = textBoxFNStudent.Text;
                        listOfStudents[index].LastName = textBoxLNStudent.Text;

                        listOfStudents[index].Category = (EnumType)comboBoxStudent.SelectedIndex;


                        listOfStudents[index].Registration.Month = Convert.ToInt32(textBoxMMStudent.Text);
                        listOfStudents[index].Registration.Day = Convert.ToInt32(textBoxDDStudent.Text);
                        listOfStudents[index].Registration.Year = Convert.ToInt32(textBoxYYYYStudent.Text);
            }
            else
            {
                MessageBox.Show(textBoxSearch.Text + "No one with this info in students");
            }
            Teacher aTeacher = new Teacher();
            found = false;
            foreach (Teacher element in listOfTeachers)
            {
                if (element.Id == Convert.ToInt32(textBoxSearch.Text))
                {
                    found = true; aTeacher = element;
                }
            }

            if (found)
            {
                listOfTeachers[index].Id = Convert.ToInt32(textBoxIDTeacher.Text);
                    listOfTeachers[index].FirstName = textBoxFNTeacher.Text;
                    listOfTeachers[index].LastName = textBoxLNTeacher.Text;

                    listOfTeachers[index].Category = (EnumType)comboBoxTeacher.SelectedIndex;


                    listOfTeachers[index].Registration.Month = Convert.ToInt32(textBoxMMTeacher.Text);
                    listOfTeachers[index].Registration.Day = Convert.ToInt32(textBoxDDTeacher.Text);
                    listOfTeachers[index].Registration.Year = Convert.ToInt32(textBoxYYYYTeacher.Text);
            }
            else
            {
                MessageBox.Show(textBoxSearch.Text + "No one with this info in teachers");
            }

        }

        }
    }

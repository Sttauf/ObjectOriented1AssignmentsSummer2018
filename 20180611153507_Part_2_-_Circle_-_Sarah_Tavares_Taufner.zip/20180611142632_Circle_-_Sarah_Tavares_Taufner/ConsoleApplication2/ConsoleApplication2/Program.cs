﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        class Circle
        {
            private double x;
            private double y;
            private double radius;
            private double perimeter;
            private double area;

            public void SetX(double x) { this.x = x; }
            public double GetX() { return this.x; }
            public void SetY(double y) { this.y = y; }
            public double GetY() { return this.y; }
            public void SetRadius(double radius) { this.radius = radius; }
            public double GetRadius() { return this.radius; }
            public double Area() { area = 3.14 * radius * radius; return Math.Round(area, 2); }
            public double Perimeter() { perimeter = 2 * 3.14 * radius; return Math.Round(perimeter, 2); }
            public void MoveRight(double m1) { this.x = x + m1; }
            public void MoveLeft(double m1) { this.x = x - m1; }
            public void MoveUp(double m2) { this.y = y + m2; }
            public void MoveDown(double m2) { this.y = y - m2; }
            public Circle() { this.x = 0; this.y = 0; this.radius = 0; }
            public Circle(double x, double y, double radius) { this.x = x; this.y = y; this.radius = radius; }
            public string GetInfos() { string info; info = "\t " + this.x + "\t " + this.y + "\t " + this.radius + "\t " + Area() + "\t\t " + Perimeter(); return info; }
        }
        static void Main(string[] args)
        {
            Circle c1 = new Circle();
            c1.SetX(12);
            c1.SetY(6);
            c1.SetRadius(9);
            Console.Write(c1.GetInfos());
            Console.Write("\n\n Moving 4 to left and 5 to up: ");
            c1.MoveLeft(4);
            c1.MoveUp(5);
            Console.Write(c1.GetInfos());
            Console.ReadKey();
        }
    }
}

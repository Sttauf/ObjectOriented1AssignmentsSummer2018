﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        class Circle
        {
            private double x;
            private double y;
            private double radius;
            private double perimeter;
            private double area;

            public void SetX(double x) { this.x = x; }
            public double GetX() { return this.x; }
            public void SetY(double y) { this.y = y; }
            public double GetY() { return this.y; }
            public void SetRadius(double radius) { this.radius = radius; }
            public double GetRadius() { return this.radius; }
            public double Area() { area = 3.14 * radius * radius; return Math.Round(area, 2); }
            public double Perimeter() { perimeter = 2 * 3.14 * radius; return Math.Round(perimeter, 2); }
            public void MoveRight(double m1) { this.x = x + m1; }
            public void MoveLeft(double m2) { this.x = x - m2; }
            public void MoveUp(double m3) { this.y = y + m3; }
            public void MoveDown(double m4) { this.y = y - m4; }
            public Circle() { this.x = 0; this.y = 0; this.radius = 0; }
            public Circle(double x, double y, double radius) { this.x = x; this.y = y; this.radius = radius; }
            public string GetInfos() { string info; info = "\n X: " + this.x + "\n Y: " + this.y + "\n Radius: " + this.radius + "\n Area: " + Area() + "\n Perimeter: " + Perimeter(); return info; }
        }
        static void Main(string[] args)
        {
            Circle c1 = new Circle();
            Console.Write("\n Add X: ");
            double x = System.Convert.ToDouble(Console.ReadLine());
            c1.SetX(x);
            Console.Write("\n Add Y: ");
            double y = System.Convert.ToDouble(Console.ReadLine());
            c1.SetY(y);
            Console.Write("\n Add Radius: ");
            double radius = System.Convert.ToDouble(Console.ReadLine());
            c1.SetRadius(radius);
            Console.Write(c1.GetInfos());

            Console.Write("\n\n Moving: " + "\n Left: ");
            double m1 = System.Convert.ToDouble(Console.ReadLine());
            c1.MoveLeft(m1);
            Console.Write("\n Right: ");
            double m2 = System.Convert.ToDouble(Console.ReadLine());
            c1.MoveRight(m2);
            Console.Write("\n Up: ");
            double m3 = System.Convert.ToDouble(Console.ReadLine());
            c1.MoveUp(m3);
            Console.Write("\n Down: ");
            double m4 = System.Convert.ToDouble(Console.ReadLine());
            c1.MoveDown(m4);
            Console.Write("\n\n Infos after change: " + c1.GetInfos());
            Console.ReadKey();
        }
    }
}

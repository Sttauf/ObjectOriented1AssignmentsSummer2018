﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        List<Circle> listofshapes = new List<Circle>();


        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            Circle aCircle = new Circle();
            String input; double x, y, radius;
            //Coordinate x
            input = textBox1.Text;
            x = Convert.ToDouble(input);
            //Coordinate y
            input = textBox2.Text;
            y = Convert.ToDouble(input);
            //Coordinate radius
            input = textBox3.Text;
            radius = Convert.ToDouble(input);
            aCircle.SetX(x);
            aCircle.SetY(y);
            aCircle.SetRadius(radius);

            this.listofshapes.Add(aCircle);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (Circle aCircle in this.listofshapes)
            {
                this.listBox1.Items.Add(aCircle.GetInfos());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
            this.textBox2.Text = "";
            this.textBox3.Text = "";
            this.listBox1.Items.Clear();
            this.textBox1.Focus();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

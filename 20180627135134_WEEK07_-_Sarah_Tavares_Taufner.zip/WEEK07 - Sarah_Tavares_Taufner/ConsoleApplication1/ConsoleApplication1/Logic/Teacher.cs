﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1.Logic
{
    public class Teacher : Member
    {
        private double hoursOfWork;
        private double hoursByRate;

        public Teacher() : base()
        {
            hoursByRate = 0.0; hoursOfWork = 0.0;
        }
        public Teacher(int id, string firstName, string lastName, double hoursByRate, double hoursOfWork) : base(id, firstName, lastName)
        {
            this.hoursOfWork = hoursOfWork; this.hoursByRate = hoursByRate;
        }
        public double HoursOfWork
        {
            get
            {
                return hoursOfWork;
            }

            set
            {
                hoursOfWork = value;
            }
        }

        public double HoursByRate
        {
            get
            {
                return hoursByRate;
            }

            set
            {
                hoursByRate = value;
            }
        }
        public override String ToString()
        {
            String state = " ";
            state = base.ToString() + " - " + this.hoursByRate + " - " + this.hoursOfWork; return state;
        }
    
}
}

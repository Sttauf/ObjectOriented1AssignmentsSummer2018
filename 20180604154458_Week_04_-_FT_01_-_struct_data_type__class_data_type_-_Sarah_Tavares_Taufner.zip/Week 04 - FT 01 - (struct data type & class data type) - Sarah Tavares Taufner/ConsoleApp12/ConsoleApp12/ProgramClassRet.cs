﻿//CLASS RETANGLE

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeometricShapesClassRet
{

    class Retangle
    {
        private int height;
        private int width;
        public Retangle()
        {
            this.height = 0;
            this.width = 0;
            
        }
        public Retangle(int height, int width)
        {
            this.height = 0;
            this.width = 0;
        }
        public int GetHeight()
        {
            return this.height;
        }
        public void SetHeight(int height)
        {
            this.height = height;
        }
        public int GetWidth()
        {
            return this.width;
        }
        public void SetWidth(int width)
        {
            this.width = width;
        }
        public double CalculArea()
        {
            double area;
            area = this.height * this.width;
            return Math.Round(area, 2);
        }
        public double CalculPerimeter()
        {
            double perimeter;
            perimeter = this.height + this.height + this.width + this.width;
            return Math.Round(perimeter, 2);
        }
        public void MoveToRight(int dh)
        {

            this.height = this.height + dh;
        }
        public void MoveToLeft(int dh)
        {

            this.height = this.height - dh;
        }
        public void MoveToUp(int dw)
        {

            this.width = this.width + dw;
        }
        public void MoveToDown(int dw)
        {

            this.width = this.width - dw;
        }
        public string GetInfos()
        {
            string state;
            state = "Height: " + this.height + " Width: " + this.width;
            return state;
        }
    }  
    class Program
    {
        static void Main(string[] args)
        {
            Retangle r1 = new Retangle(); 
            r1.SetHeight(2);
            r1.SetWidth(3);
            Console.WriteLine("Info: " + r1.GetInfos());
            Console.WriteLine("Area: " + r1.CalculArea() + " Perimeter:  " + r1.CalculPerimeter());
            Console.WriteLine("Moving 3 to right and 3 down: ");
            r1.MoveToRight(3); r1.MoveToDown(3);
            Console.WriteLine("New info: " + r1.GetInfos() + "\n\n");

            Retangle r2 = new Retangle();
            r2.SetHeight(34);
            r2.SetWidth(32);
            Console.WriteLine("Info: " + r2.GetInfos());
            Console.WriteLine("Area: " + r2.CalculArea() + " Perimeter:  " + r2.CalculPerimeter());
            Console.WriteLine("Moving 3 to left and 3 up: ");
            r2.MoveToLeft(3); r2.MoveToUp(3);
            Console.WriteLine("New info: " + r2.GetInfos());
            Console.ReadKey();
        }
    }
}

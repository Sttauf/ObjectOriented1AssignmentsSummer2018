﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Wk10___Shapes_Version2._1.Classes
{
    public class Rectangles : Shapes
    {
        private double W; //W = width
        private double H; //H = heigh
        public double W1 { get => W; set => W = value; }
        public double H1 { get => H; set => H = value; }
        public Rectangles()
        {
            this.X = 0.00;
            this.Y = 0.00;
            this.W = 200;
            this.H = 100;
        }
        public Rectangles(double W, double H, double x, double y) : base(x, y)
        {
            this.X = x;
            this.Y = y;
            this.W1 = W;
            this.H1 = H;
        }
        public double CA() //CALCULE AREA
        {
            return this.H * this.W;
        }
        public double CP() //CALCULE PERIMETER
        {
            return 2 * (this.H + this.W);
        }
        public override String ToString()
        {
            String D = "Height: " + this.H + "\r\n";
            D += "Width: " + this.W + "\r\n";
            D += "Perimeter: " + Math.Round(this.CP()) + "\r\n";
            D += "Area = " + Math.Round(this.CA()) + "\r\n";
            return D;
        }
        public void Draw(PaintEventArgs s) 
        {
            Pen myPen = new Pen(Color.MediumPurple, 2);
            //Convert.ToDouble();
            s.Graphics.DrawRectangle(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.H), Convert.ToInt32(this.W)));
       
            myPen.Dispose();
            s.Graphics.Dispose();
        }
    }
}

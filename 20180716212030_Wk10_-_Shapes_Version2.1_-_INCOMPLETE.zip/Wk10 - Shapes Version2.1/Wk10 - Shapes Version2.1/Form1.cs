﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wk10___Shapes_Version2._1.Classes;

namespace Wk10___Shapes_Version2._1
{
    public partial class Form1 : Form
    {
        Rectangles nR;
        Elipse nE;
        public Form1()
        {
          InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (EnumType element in Enum.GetValues(typeof(EnumType)))
            {
                comboBox1.Items.Add(element);
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                this.textBoxX.Enabled = true;
                this.textBoxY.Enabled = true;
                this.textBoxRX.Enabled = false;
                this.textBoxW.Enabled = true;
                this.textBoxH.Enabled = true;
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                this.textBoxX.Enabled = true;
                this.textBoxY.Enabled = true;
                this.textBoxRX.Enabled = true;
                this.textBoxW.Enabled = false;
                this.textBoxH.Enabled = false;
            }
            else
            {
                this.textBoxX.Enabled = false;
                this.textBoxY.Enabled = false;
                this.textBoxRX.Enabled = false;
                this.textBoxW.Enabled = false;
                this.textBoxH.Enabled = false;
            }
        }
        private void buttonDISPLAY_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                /* int W = Convert.ToInt32(this.textBoxW.Text);
                int H = Convert.ToInt32(this.textBoxH.Text);
                int X = Convert.ToInt32(this.textBoxX.Text);
                int Y = Convert.ToInt32(this.textBoxY.Text);
                nR = new Rectangle();
                String info = nR.ToString();
                this.listBox1.Text = info;
                this.listBox1.Visible = true; */
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                int X = Convert.ToInt32(this.textBoxX.Text);
                int Y = Convert.ToInt32(this.textBoxY.Text);
                int RX = Convert.ToInt32(this.textBoxRX.Text);
                int RY = Convert.ToInt32(this.textBoxRY.Text);
                nE = new Elipse();
                String info = nE.ToString();
                this.listBox1.Text = info;
                this.listBox1.Visible = true;
            }
        }

        private void buttonUP_Click(object sender, EventArgs e)
        {
            int Y = Convert.ToInt32(this.textBoxY.Text);
            Y = Y + 1;
        }

        private void buttonDOWN_Click(object sender, EventArgs e)
        {
            int Y = Convert.ToInt32(this.textBoxY.Text);
            Y = Y - 1;
        }

        private void buttonRIGHT_Click(object sender, EventArgs e)
        {
            int X = Convert.ToInt32(this.textBoxX.Text);
            X = X + 1;
        }

        private void buttonLEFT_Click(object sender, EventArgs e)
        {
            int X = Convert.ToInt32(this.textBoxX.Text);
            X = X - 1;
        }

        private void buttonUPLEFT_Click(object sender, EventArgs e)
        {
            int X = Convert.ToInt32(this.textBoxX.Text);
            X = X - 1;
            int Y = Convert.ToInt32(this.textBoxY.Text);
            Y = Y + 1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int Y = Convert.ToInt32(this.textBoxY.Text);
            Y = Y - 1;
            int X = Convert.ToInt32(this.textBoxX.Text);
            X = X - 1;
        }

        private void buttonDOWNRIGHT_Click(object sender, EventArgs e)
        {
            int Y = Convert.ToInt32(this.textBoxY.Text);
            Y = Y - 1;
            int X = Convert.ToInt32(this.textBoxX.Text);
            X = X + 1;
        }

        private void buttonUPRIGHT_Click(object sender, EventArgs e)
        {
            int X = Convert.ToInt32(this.textBoxX.Text);
            X = X + 1;
            int Y = Convert.ToInt32(this.textBoxY.Text);
            Y = Y + 1;
        }
    }
}

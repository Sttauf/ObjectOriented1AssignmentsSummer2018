﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp8.Logic
{
    [Serializable]
    public class Teacher : Member
    {
        private double HPW; //hours of work
        private double HBR; //hours per rate
        private Date RD; //registration date

        public double HPW1 { get => HPW; set => HPW = value; }
        public double HBR1 { get => HBR; set => HBR = value; }
        public Date RD1 { get => RD; set => RD = value; }
        public Teacher()
        {
            this.ID1 = 00;
            this.FN1 = "--";
            this.LN1 = "--";
            this.HPW1 = 00;
            this.HBR1 = 00;
            this.RD1 = new Date();
        }
        public Teacher(int ID, String FN, String LN, Date RD) : base(ID, FN, LN)
        {
            this.ID1 = ID;
            this.FN1 = FN;
            this.LN1 = LN;
            this.HPW1 = HPW;
            this.HBR1 = HBR;
            this.RD1 = RD;
        }
        public override String ToString()
        {
            String state;
            state = this.ID1 + "\t" + this.FN1 + "\t" + this.LN1 + "\t" + this.RD1;
            return state;
        }
    }
}

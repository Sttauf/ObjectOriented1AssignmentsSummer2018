﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp8.Logic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml;
using System.Xml.Serialization;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        List<Student> listOfStudents = new List<Student>();
        List<Teacher> listOfTeachers = new List<Teacher>();
        List<Member> listOfMembers = new List<Member>();
        private int index = 0;

        //Files
        private static String textPath = @"../../Data/st.txt"; 
        private static String binaryPath = @"../../Data/st.bin";
        private static String xmlPath = @"../../Data/st.xml";
        
        //APPLICATION
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (EnumType element in Enum.GetValues(typeof(EnumType)))
            {
                comboBoxST.Items.Add(element);
            }
        }
        private void buttonADD_Click(object sender, EventArgs e)//ADD BUTTON
        {
            try
            {
                if (comboBoxST.SelectedIndex == 0)
                {
                    Teacher aTeacher = new Teacher();

                    aTeacher.FN1 = textBoxFN.Text;
                    aTeacher.LN1 = textBoxLN.Text;
                    aTeacher.ID1 = Convert.ToInt32(textBoxID.Text);
                    aTeacher.HBR1 = Convert.ToDouble(textBoxHBR.Text);
                    aTeacher.HPW1 = Convert.ToDouble(textBoxHPW.Text);
                    aTeacher.RD1 = new Date(Convert.ToInt32(textBoxDD.Text), Convert.ToInt32(textBoxMM.Text), Convert.ToInt32(textBoxYYYY.Text));
                    this.listOfTeachers.Add(aTeacher);
                    this.listOfMembers.Add(aTeacher);
                }
                else if (comboBoxST.SelectedIndex == 1)
                {
                    Student aStudent = new Student();

                    aStudent.FN1 = textBoxFN.Text;
                    aStudent.LN1 = textBoxLN.Text;
                    aStudent.ID1 = Convert.ToInt32(textBoxID.Text);
                    aStudent.FF1 = Convert.ToDouble(textBoxFF.Text);
                    aStudent.FPS1 = Convert.ToDouble(textBoxFPS.Text);
                    aStudent.RD1 = new Date(Convert.ToInt32(textBoxDD.Text), Convert.ToInt32(textBoxMM.Text), Convert.ToInt32(textBoxYYYY.Text));
                    this.listOfStudents.Add(aStudent);
                    this.listOfMembers.Add(aStudent);
                }
                else { MessageBox.Show("ERROR: You didn't choose a type!"); }
            }
            catch { MessageBox.Show("ERROR: You've added incorrect info"); }
        }
        private void buttonRESET_Click(object sender, EventArgs e)//RESET BUTTON
        {
            this.textBoxID.Text = "";
            this.textBoxFN.Text = "";
            this.textBoxLN.Text = "";
            this.textBoxDD.Text = "";
            this.textBoxMM.Text = "";
            this.textBoxYYYY.Text = "";
            this.textBoxFPS.Text = "";
            this.textBoxFF.Text = "";
            this.textBoxHBR.Text = "";
            this.textBoxHPW.Text = "";
            listBoxTeacher.Items.Clear();
            listBoxStudent.Items.Clear();
            listBox.Items.Clear();
        }
        private void buttonDISPLAY_Click(object sender, EventArgs e)//DISPLAY BUTTON
        {
            if (this.listOfStudents.Capacity != 0 && this.listOfTeachers.Capacity == 0)
            {
                foreach (Student aStudent in this.listOfStudents)
                {
                    this.listBoxStudent.Items.Add(aStudent);
                    this.listBox.Items.Add(aStudent);

                }
                this.listBoxTeacher.Items.Add("No data");
            }
            else if (this.listOfTeachers.Capacity != 0 && this.listOfStudents.Capacity == 0)
            {
                foreach (Teacher aTeacher in this.listOfTeachers)
                {
                    this.listBoxTeacher.Items.Add(aTeacher);
                    this.listBox.Items.Add(aTeacher);
                }
                this.listBoxStudent.Items.Add("No data");
            }
            else if (this.listOfTeachers.Capacity != 0 && this.listOfStudents.Capacity != 0)
            {
                foreach (Student aStudent in this.listOfStudents)
                {
                    this.listBoxStudent.Items.Add(aStudent);
                    this.listBox.Items.Add(aStudent);

                }
                foreach (Teacher aTeacher in this.listOfTeachers)
                {
                    this.listBoxTeacher.Items.Add(aTeacher);
                    this.listBox.Items.Add(aTeacher);
                }

            }
            else
            {
                this.listBoxTeacher.Items.Add("No data");
                this.listBoxStudent.Items.Add("No data");
                this.listBox.Items.Add("No data");
            }
        }
        private void buttonSEARCH_Click(object sender, EventArgs e)//SEARCH BUTTON
        {
            Student aStudent = new Student();
            bool found = false;
            foreach (Student element in listOfStudents)
            {
                if (element.ID1 == Convert.ToInt32(textBoxIDSearch.Text))
                {
                    found = true; aStudent = element;
                }
            }

            if (found)
            {
                MessageBox.Show(aStudent.ToString());
            }
            else
            {
                MessageBox.Show(textBoxIDSearch.Text + "No one with this info in students");
            }
            Teacher aTeacher = new Teacher();
            found = false;
            foreach (Teacher element in listOfTeachers)
            {
                if (element.ID1 == Convert.ToInt32(textBoxIDSearch.Text))
                {
                    found = true; aTeacher = element;
                }
            }

            if (found)
            {
                MessageBox.Show(aTeacher.ToString());
            }
            else
            {
                MessageBox.Show(textBoxIDSearch.Text + "No one with this info in teachers");
            }
        }
        private void buttonMODIFY_Click(object sender, EventArgs e)//MODIFY BUTTON
        {
            Student aStudent = new Student();


            bool found = false;
            foreach (Student element in listOfStudents)
            {
                if (element.ID1 == Convert.ToInt32(textBoxIDSearch.Text))
                {
                    found = true; aStudent = element;
                }
            }

            if (found)
            {
                listOfStudents[index].ID1 = Convert.ToInt32(textBoxID.Text);
                listOfStudents[index].FN1 = textBoxFN.Text;
                listOfStudents[index].LN1 = textBoxLN.Text;
                listOfStudents[index].RD1.MM1 = Convert.ToInt32(textBoxMM.Text);
                listOfStudents[index].RD1.DD1 = Convert.ToInt32(textBoxDD.Text);
                listOfStudents[index].RD1.YYYY1 = Convert.ToInt32(textBoxYYYY.Text);
            }
            else
            {
                MessageBox.Show(textBoxIDSearch.Text + "No one with this info in students");
            }
            Teacher aTeacher = new Teacher();
            found = false;
            foreach (Teacher element in listOfTeachers)
            {
                if (element.ID1 == Convert.ToInt32(textBoxIDSearch.Text))
                {
                    found = true; aTeacher = element;
                }
            }

            if (found)
            {
                listOfTeachers[index].ID1 = Convert.ToInt32(textBoxID.Text);
                listOfTeachers[index].FN1 = textBoxFN.Text;
                listOfTeachers[index].LN1 = textBoxLN.Text;
                listOfTeachers[index].RD1.DD1 = Convert.ToInt32(textBoxDD.Text);
                listOfTeachers[index].RD1.MM1 = Convert.ToInt32(textBoxMM.Text);
                listOfTeachers[index].RD1.YYYY1 = Convert.ToInt32(textBoxYYYY.Text);
            }
            else
            {
                MessageBox.Show(textBoxIDSearch.Text + "No one with this info in teachers");
            }
        }
        private void buttonREMOVE_Click(object sender, EventArgs e)//REMOVE BUTTON
        {

            Student aStudent = new Student();


            bool found = false;
            foreach (Student element in listOfStudents)
            {
                if (element.ID1 == Convert.ToInt32(textBoxIDSearch.Text))
                {
                    found = true; aStudent = element;
                }
            }

            if (found)
            {
                MessageBox.Show("Info removed in students: " + aStudent.ToString());
                listOfStudents.RemoveAt(index);
            }
            else
            {
                MessageBox.Show(textBoxIDSearch.Text + "No one with this info in students");
            }
            Teacher aTeacher = new Teacher();
            found = false;
            foreach (Teacher element in listOfTeachers)
            {
                if (element.ID1 == Convert.ToInt32(textBoxIDSearch.Text))
                {
                    found = true; aTeacher = element;
                }
            }

            if (found)
            {
                MessageBox.Show("Info removed in teachers: " + aTeacher.ToString());
                listOfTeachers.RemoveAt(index);
            }
            else
            {
                MessageBox.Show(textBoxIDSearch.Text + "No one with this info in teachers");
            }

        }
        private void buttonEXIT_Click(object sender, EventArgs e)//EXIT BUTTON
        {
            this.Close();
        }
        private void comboBoxST_SelectedIndexChanged(object sender, EventArgs e)//COMBOBOX
        {
            if (comboBoxST.SelectedIndex == 0)
            {
                this.textBoxFF.Enabled = false;
                this.textBoxFPS.Enabled = false;
                this.textBoxHBR.Enabled = true;
                this.textBoxHPW.Enabled = true;
            }
            else if (comboBoxST.SelectedIndex == 1)
            {
                this.textBoxHPW.Enabled = false;
                this.textBoxHBR.Enabled = false;
                this.textBoxFF.Enabled = true;
                this.textBoxFPS.Enabled = true;
            }
            else
            {
                this.textBoxFF.Enabled = false;
                this.textBoxFPS.Enabled = false;
                this.textBoxHBR.Enabled = false;
                this.textBoxHPW.Enabled = false;
            }
        }

        //TEXT FILE
        private void buttonRT_Click(object sender, EventArgs e) //READ TEXT BUTTON - STUDENT AND TEACHER
        {
            try
            {
                //STUDENT
                this.listOfStudents.Clear();
                this.listBoxStudent.Items.Clear();
                this.listOfStudents = ReadTextS();
                DplyListBoxS(listOfStudents, listBoxStudent);
            }
            catch
            {

                //TEACHER
                this.listOfTeachers.Clear();
                this.listBoxTeacher.Items.Clear();
                this.listOfTeachers = ReadTextT();
                DplyListBoxT(listOfTeachers, listBoxTeacher);
            }
        }
        public static List<Student> ReadTextS() //READ TEXT FUNCTION - STUDENT
        {
            List<Student> listFile = new List<Student>();
            try
            {
                StreamReader reader = new StreamReader(textPath);
                String line = null;
                while ((line = reader.ReadLine()) != null)
                {
                    Student aStudent = new Student();
                    String[] fields = line.Split('|');
                    aStudent.ID1 = Int32.Parse(fields[0]);
                    aStudent.FN1 = fields[1];
                    aStudent.LN1 = fields[2];
                    String[] datePart = fields[4].Split('/');
                    aStudent.RD1 = new Date(Int32.Parse(datePart[0]), Int32.Parse(datePart[1]), Int32.Parse(datePart[2]));
                    //this.listBoxStudent.Items.Add(aStudent);
                    listFile.Add(aStudent);
                }
                reader.Close();
            }
            catch (IOException ex)
            {
                MessageBox.Show("File not found");
            }
            return listFile;
        }
        public static List<Teacher> ReadTextT() //READ TEXT FUNCTION - TEACHER
        {
            List<Teacher> listFile = new List<Teacher>();
            try
            {
                StreamReader reader = new StreamReader(textPath);
                String line = null;
                while ((line = reader.ReadLine()) != null)
                {
                    Teacher aTeacher = new Teacher();
                    String[] fields = line.Split('|');
                    aTeacher.ID1 = Int32.Parse(fields[0]);
                    aTeacher.FN1 = fields[1];
                    aTeacher.LN1 = fields[2];
                    String[] datePart = fields[4].Split('/');
                    aTeacher.RD1 = new Date(Int32.Parse(datePart[0]), Int32.Parse(datePart[1]), Int32.Parse(datePart[2]));
                    //this.listBoxStudent.Items.Add(aStudent);
                    listFile.Add(aTeacher);
                }
                reader.Close();
            }
            catch (IOException ex)
            {
                MessageBox.Show("File not found");
            }
            return listFile;
        }
        public static void DplyListBoxS(List<Student> listOfStudents, ListBox listBoxStudent) //DISPLAY TEXT FUNCTION - STUDENT
        {
            foreach (Student aStudent in listOfStudents)
            {

                listBoxStudent.Items.Add(aStudent);

            }
        }
        public static void DplyListBoxT(List<Teacher> listOfTeachers, ListBox listBoxTeacher) //DISPLAY TEXT FUNCTION - TEACHER
        {
            foreach (Teacher aTeacher in listOfTeachers)
            {

                listBoxTeacher.Items.Add(aTeacher);

            }
        } 
        private void buttonWT_Click(object sender, EventArgs e)//WRITE TEXT BUTTON
        {
            WriteText(listOfStudents, listOfTeachers);
        }
        public static void WriteText(List<Student> myList, List<Teacher> myList2) //WRITE TEXT FUNCTION - STUDENT AND TEACHER
        {
            //STUDENT
            using (StreamWriter writer = File.CreateText(textPath))
            {
                foreach (Student aStudent in myList)
                {
                    writer.WriteLine(aStudent.ID1 + "\t" + aStudent.FN1 + "\t" + aStudent.LN1 + "\t" + aStudent.RD1.ToString());
                }
            }
            //TEACHER
            using (StreamWriter writer = File.CreateText(textPath))
            {
                foreach (Teacher aTeacher in myList2)
                {
                    writer.WriteLine(aTeacher.ID1 + "\t" + aTeacher.FN1 + "\t" + aTeacher.LN1 + "\t" + aTeacher.RD1.ToString());
                }
            }
        }

        //BINARY
        private void buttonRB_Click(object sender, EventArgs e) //READ BINARY BUTTON - STUDENT AND TEACHER
        {
            listOfStudents.Clear();
            listOfTeachers.Clear();

            if (File.Exists(binaryPath))
            {
                FileStream fs = new FileStream(binaryPath, FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();

                listOfStudents = (List<Student>)bin.Deserialize(fs);
                listOfTeachers = (List<Teacher>)bin.Deserialize(fs);

                fs.Close();
            }
            foreach (Student aStudent in listOfStudents)
            {
                this.listBoxStudent.Items.Add(aStudent);
            }
            foreach (Teacher aTeacher in listOfTeachers)
            {
                this.listBoxTeacher.Items.Add(aTeacher);
            }
        }
        private void buttonWB_Click(object sender, EventArgs e) //WRITE BINARY BUTTON - STUDENT AND TEACHER
        {
            FileStream fs = new FileStream(binaryPath, FileMode.OpenOrCreate, FileAccess.Write);

            BinaryFormatter writer = new BinaryFormatter();

            writer.Serialize(fs, listOfStudents);
            writer.Serialize(fs, listOfTeachers);

            fs.Close();
        }

        //XML
        private void buttonRX_Click(object sender, EventArgs e) //READ XML BUTTON - STUDENT AND TEACHER 
        {
            listOfStudents.Clear();
            listOfTeachers.Clear();
            try
            {
                //STUDENT
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Student>));
                StreamReader reader = new StreamReader(xmlPath);
                listOfStudents = (List<Student>)xmlSerializer.Deserialize(reader);
                reader.Close();
                foreach (Student aStudent in listOfStudents)
                {
                    this.listBoxStudent.Items.Add(aStudent);
                }
            }
            catch
            {
                //TEACHER
                XmlSerializer xmlSerializer2 = new XmlSerializer(typeof(List<Teacher>));
                StreamReader reader2 = new StreamReader(xmlPath);
                listOfTeachers = (List<Teacher>)xmlSerializer2.Deserialize(reader2);
                reader2.Close();
                foreach (Teacher aTeacher in listOfTeachers)
                {
                    this.listBoxTeacher.Items.Add(aTeacher);
                }
            }
        }
        private void buttonWX_Click(object sender, EventArgs e) //WRITE XML BUTTON - STUDENT AND TEACHER
        {
            //STUDENT
            XmlWriter writer = XmlWriter.Create(xmlPath);
            XmlSerializer serializer = new XmlSerializer(typeof(List<Student>));
            serializer.Serialize(writer, listOfStudents);
            writer.Close();
            //TEACHER
            XmlWriter writer2 = XmlWriter.Create(xmlPath);
            XmlSerializer serializer2 = new XmlSerializer(typeof(List<Teacher>));
            serializer2.Serialize(writer2, listOfTeachers);
            writer2.Close();
        }
    }
}

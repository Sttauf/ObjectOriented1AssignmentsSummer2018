﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp8.Logic;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        List<Student> listOfStudents = new List<Student>();
        List<Teacher> listOfTeachers = new List<Teacher>();
        private int index=0;
        public Form1()
        {
            InitializeComponent();
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (EnumType element in Enum.GetValues(typeof(EnumType)))
            {
                comboBoxST.Items.Add(element);
            }
        }
        private void label8_Click(object sender, EventArgs e){}

        private void textBoxID_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBoxST.SelectedIndex == 0)
                {
                    Teacher aTeacher = new Teacher();
                    
                    aTeacher.FN1 = textBoxFN.Text;
                    aTeacher.LN1 = textBoxLN.Text;
                    aTeacher.ID1 = Convert.ToInt32(textBoxID.Text);
                    aTeacher.HBR1 = Convert.ToDouble(textBoxHBR.Text);
                    aTeacher.HPW1 = Convert.ToDouble(textBoxHPW.Text);
                    aTeacher.RD1 = new Date(Convert.ToInt32(textBoxDD.Text), Convert.ToInt32(textBoxMM.Text), Convert.ToInt32(textBoxYYYY.Text));
                    this.listOfTeachers.Add(aTeacher);
                }
                else if (comboBoxST.SelectedIndex == 1)
                {
                    Student aStudent = new Student();

                    aStudent.FN1 = textBoxFN.Text;
                    aStudent.LN1 = textBoxLN.Text;
                    aStudent.ID1 = Convert.ToInt32(textBoxID.Text);
                    aStudent.FF1 = Convert.ToDouble(textBoxFF.Text);
                    aStudent.FPS1 = Convert.ToDouble(textBoxFPS.Text);
                    aStudent.RD1 = new Date(Convert.ToInt32(textBoxDD.Text), Convert.ToInt32(textBoxMM.Text), Convert.ToInt32(textBoxYYYY.Text));
                    this.listOfStudents.Add(aStudent);
                }
                else { MessageBox.Show("ERROR: You didn't choose a type!"); }
            }
            catch { MessageBox.Show("ERROR: You've added incorrect info"); }
        }

        private void buttonRESET_Click(object sender, EventArgs e)
        {
            this.textBoxID.Text = "";
            this.textBoxFN.Text = "";
            this.textBoxLN.Text = "";
            this.textBoxDD.Text = "";
            this.textBoxMM.Text = "";
            this.textBoxYYYY.Text = "";
            this.textBoxFPS.Text = "";
            this.textBoxFF.Text = "";            
            this.textBoxHBR.Text = "";
            this.textBoxHPW.Text = "";
            listBoxTeacher.Items.Clear();
            listBoxStudent.Items.Clear();
            listBox.Items.Clear();
        }

        private void buttonDISPLAY_Click(object sender, EventArgs e)
        {
            if (this.listOfStudents.Capacity != 0 && this.listOfTeachers.Capacity == 0)
            {
                foreach (Student aStudent in this.listOfStudents)
                {
                    this.listBoxStudent.Items.Add(aStudent);
                    this.listBox.Items.Add(aStudent);

                }
                this.listBoxTeacher.Items.Add("No data");
            }
            else if (this.listOfTeachers.Capacity != 0 && this.listOfStudents.Capacity == 0)
            {
                foreach (Teacher aTeacher in this.listOfTeachers)
                {
                    this.listBoxTeacher.Items.Add(aTeacher);
                    this.listBox.Items.Add(aTeacher);
                }
                this.listBoxStudent.Items.Add("No data");
            }
            else if (this.listOfTeachers.Capacity != 0 && this.listOfStudents.Capacity != 0)
            {
                foreach (Student aStudent in this.listOfStudents)
                {
                    this.listBoxStudent.Items.Add(aStudent);
                    this.listBox.Items.Add(aStudent);

                }
                foreach (Teacher aTeacher in this.listOfTeachers)
                {
                    this.listBoxTeacher.Items.Add(aTeacher);
                    this.listBox.Items.Add(aTeacher);
                }

            }
            else
            {
                this.listBoxTeacher.Items.Add("No data");
                this.listBoxStudent.Items.Add("No data");
                this.listBox.Items.Add("No data");
            }
        }

        private void buttonSEARCH_Click(object sender, EventArgs e)
        {
            Student aStudent = new Student();
            bool found = false;
            foreach (Student element in listOfStudents)
            {
                if (element.ID1 == Convert.ToInt32(textBoxIDSearch.Text))
                {
                    found = true; aStudent = element;
                }
            }

            if (found)
            {
                MessageBox.Show(aStudent.ToString());
            }
            else
            {
                MessageBox.Show(textBoxIDSearch.Text + "No one with this info in students");
            }
            Teacher aTeacher = new Teacher();
            found = false;
            foreach (Teacher element in listOfTeachers)
            {
                if (element.ID1 == Convert.ToInt32(textBoxIDSearch.Text))
                {
                    found = true; aTeacher = element;
                }
            }

            if (found)
            {
                MessageBox.Show(aTeacher.ToString());
            }
            else
            {
                MessageBox.Show(textBoxIDSearch.Text + "No one with this info in teachers");
            }
        }

        private void buttonMODIFY_Click(object sender, EventArgs e)
        {
            Student aStudent = new Student();


            bool found = false;
            foreach (Student element in listOfStudents)
            {
                if (element.ID1 == Convert.ToInt32(textBoxIDSearch.Text))
                {
                    found = true; aStudent = element;
                }
            }

            if (found)
            {
                listOfStudents[index].ID1 = Convert.ToInt32(textBoxID.Text);
                listOfStudents[index].FN1 = textBoxFN.Text;
                listOfStudents[index].LN1 = textBoxLN.Text;
                listOfStudents[index].RD1.MM1 = Convert.ToInt32(textBoxMM.Text);
                listOfStudents[index].RD1.DD1 = Convert.ToInt32(textBoxDD.Text);
                listOfStudents[index].RD1.YYYY1 = Convert.ToInt32(textBoxYYYY.Text);
            }
            else
            {
                MessageBox.Show(textBoxIDSearch.Text + "No one with this info in students");
            }
            Teacher aTeacher = new Teacher();
            found = false;
            foreach (Teacher element in listOfTeachers)
            {
                if (element.ID1 == Convert.ToInt32(textBoxIDSearch.Text))
                {
                    found = true; aTeacher = element;
                }
            }

            if (found)
            {
                listOfTeachers[index].ID1 = Convert.ToInt32(textBoxID.Text);
                listOfTeachers[index].FN1 = textBoxFN.Text;
                listOfTeachers[index].LN1 = textBoxLN.Text;
                listOfTeachers[index].RD1.DD1 = Convert.ToInt32(textBoxDD.Text);
                listOfTeachers[index].RD1.MM1 = Convert.ToInt32(textBoxMM.Text);
                listOfTeachers[index].RD1.YYYY1 = Convert.ToInt32(textBoxYYYY.Text);
            }
            else
            {
                MessageBox.Show(textBoxIDSearch.Text + "No one with this info in teachers");
            }
        }

        private void buttonREMOVE_Click(object sender, EventArgs e)
        {

            Student aStudent = new Student();


            bool found = false;
            foreach (Student element in listOfStudents)
            {
                if (element.ID1 == Convert.ToInt32(textBoxIDSearch.Text))
                {
                    found = true; aStudent = element;
                }
            }

            if (found)
            {
                MessageBox.Show("Info removed in students: " + aStudent.ToString());
                listOfStudents.RemoveAt(index);
            }
            else
            {
                MessageBox.Show(textBoxIDSearch.Text + "No one with this info in students");
            }
            Teacher aTeacher = new Teacher();
            found = false;
            foreach (Teacher element in listOfTeachers)
            {
                if (element.ID1 == Convert.ToInt32(textBoxIDSearch.Text))
                {
                    found = true; aTeacher = element;
                }
            }

            if (found)
            {
                MessageBox.Show("Info removed in teachers: " + aTeacher.ToString());
                listOfTeachers.RemoveAt(index);
            }
            else
            {
                MessageBox.Show(textBoxIDSearch.Text + "No one with this info in teachers");
            }

        }

        private void buttonEXIT_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBoxST_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxST.SelectedIndex == 0)
            {
                this.textBoxFF.Enabled = false;
                this.textBoxFPS.Enabled = false;
                this.textBoxHBR.Enabled = true;
                this.textBoxHPW.Enabled = true;
            } else if (comboBoxST.SelectedIndex == 1)
            {
                this.textBoxHPW.Enabled = false;
                this.textBoxHBR.Enabled = false;
                this.textBoxFF.Enabled = true;
                this.textBoxFPS.Enabled = true;
            } else
            {
                this.textBoxFF.Enabled = false;
                this.textBoxFPS.Enabled = false;
                this.textBoxHBR.Enabled = false;
                this.textBoxHPW.Enabled = false;
            }
        }
    }
}

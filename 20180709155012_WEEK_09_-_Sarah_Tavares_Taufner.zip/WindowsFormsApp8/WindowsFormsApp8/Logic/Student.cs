﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp8.Logic
{
    class Student : Member
    {
        private double FF; //first fees
        private double FPS; //fees per section
        private Date RD; //registration date

        public double FF1 { get => FF; set => FF = value; }
        public double FPS1 { get => FPS; set => FPS = value; }
        public Date RD1 { get => RD; set => RD = value; }
        public Student()
        {
            this.ID1 = 00;
            this.FN1 = "--";
            this.LN1 = "--";
            this.RD1 = new Date();
        }
        public Student(int ID, String FN, String LN, Date RD) : base(ID, FN, LN)
        {
            this.ID1 = ID;
            this.FN1 = FN;
            this.LN1 = LN;
            this.RD1 = RD;
        }
        public override String ToString()
        {
            String state;
            state = this.ID1 + "\t" + this.FN1 + "\t" + this.LN1 + "\t" + this.RD1;
            return state;
        }
    }
}

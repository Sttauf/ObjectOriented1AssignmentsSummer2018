﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp8.Logic
{
    class Date
    {
        private int DD; //day
        private int MM; //month
        private int YYYY; //year
        public int DD1 { get => DD; set => DD = value; }
        public int MM1 { get => MM; set => MM = value; }
        public int YYYY1 { get => YYYY; set => YYYY = value; }
        public Date()
        {
            this.DD = 00;
            this.MM = 00;
            this.YYYY = 0000;
        }
        public Date(int DD, int MM, int YYYY)
        {
            this.DD = DD;
            this.MM = MM;
            this.YYYY = YYYY;
        }
        public override String ToString()
        {
            String state;
            state = this.MM + "/" + this.DD + "/" + this.YYYY;
            return state;
        }
    }
}

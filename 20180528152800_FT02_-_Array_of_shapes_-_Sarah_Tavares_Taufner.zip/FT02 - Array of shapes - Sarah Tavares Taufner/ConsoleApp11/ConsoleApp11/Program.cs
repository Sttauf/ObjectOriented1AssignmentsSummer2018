﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            char[,] matrix = {
                              { '*', '*', '*', '*' },
                              { '*', '*', '*', '*' },
                              { '*', '*', '*', '*' },
                              { '*', '*', '*', '*' },
            };
            Console.WriteLine("THE MATRIX: ");
            for (int row = 0; row < 4; row++)
            {
                Console.WriteLine();
                for (int col = 0; col < 4; col++)
                {
                    Console.Write(matrix[row, col]);
                }
            }
            Console.WriteLine("\n\n" + "BOTTOM LEFT RIGHT ANGLE FROM THE MATRIX:");
            for (int row = 0; row < 4; row++)
            {
                Console.WriteLine();
                for (int col = 0; col < 4; col++)
                {
                    if (row < col) { } else { Console.Write(matrix[row, col]); };
                }
            }
            Console.WriteLine("\n\n" + "BOTTOM LEFT RIGHT ANGLE FROM THE MATRIX:");
            for (int col = 0; col < 4; col++)
            {
                Console.WriteLine();
                for (int row = 0; row < 4; row++)
                {
                    if (row < col) { } else { Console.Write(matrix[col, row]); };
                }
            }

            Console.ReadKey();
        }
    }
}

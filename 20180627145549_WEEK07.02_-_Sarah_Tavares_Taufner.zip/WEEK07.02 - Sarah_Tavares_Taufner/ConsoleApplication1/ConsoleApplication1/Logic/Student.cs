﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1.Logic
{
    public class Student : Member

    {//beginning class student
        private double firstFees;
        private double feesPerSession;

        public Student() : base()
        {
            firstFees = 0.0; feesPerSession = 0.0;
        }
        public Student(int id, string firstName, string lastName, double firstFees, double feesPerSession): base(id, firstName, lastName)
        {
            this.firstFees = firstFees; this.FeesPerSession = FeesPerSession;
        }
        public double FirstFees
        {
            get
            {
                return firstFees;
            }

            set
            {
                firstFees = value;
            }
        }

        public double FeesPerSession
        {
            get
            {
                return feesPerSession;
            }

            set
            {
                feesPerSession = value;
            }
        }
        public override  double CalculPayment()
        {
            double payment;
            payment = FirstFees + FeesPerSession;
            return payment;
        }

        public override String ToString() { String state = " ";
            state = base.ToString() + " - " + this.feesPerSession + " - " + this.firstFees + " - " + CalculPayment(); return state; }
    }
}

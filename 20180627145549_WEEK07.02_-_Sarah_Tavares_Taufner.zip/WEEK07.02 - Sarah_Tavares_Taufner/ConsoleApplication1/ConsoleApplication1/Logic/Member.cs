﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1.Logic
{
  public abstract class Member : Object
    {
        private int id;
        private string fistName;
        private string lastName;

        public int Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string FistName
        {
            get
            {
                return fistName;
            }

            set
            {
                fistName = value;
            }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }

            set
            {
                lastName = value;
            }
        }

        public Member() { Id = 0; FistName = "unknow"; LastName = "unknow"; }
        public Member(int id, string firstName, string lastName) { this.Id = id; this.FistName = firstName; this.LastName = lastName; }
       
        public override String ToString()
        {
            String state = " ";
            state = this.id + " - " + this.FistName + " - " + this.LastName; return state;
        }


        public abstract double CalculPayment();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApp4
{ 
    class Program
    {
        
        static void Main(string[] args)
        {
            int exit = 0;

            do
            {
                int op = 0;
                Console.WriteLine("Geometric Shapes Computation: " + "\n" + "1) Circle (area and perimeter)" + "\n" + "2) Retangle (area and perimeter)" + "\n" + "3) Quit");
                op = System.Convert.ToInt16(Console.ReadLine());
                if (op > 3 || op <= 0) { Console.WriteLine("Please add a number included in the options"); Console.ReadKey(); Console.Clear(); }
                else
                {
                    switch (op)
                    {
                        case 1:
                            {
                                Circle();
                                break;
                            }
                        case 2:
                            {
                                Retangle();
                                break;
                            }
                        case 3:
                            {
                                exit = 1;
                                break;
                            }
                    }
                }
            } while (exit == 0);
            Console.ReadKey();
        }
        static void Circle() {
            double radius = 0.00, perCir = 0.00, arCir = 0.00;
            double PI = 3.14;
            bool valid = false;
            do
            {
                try
                {
                    Console.WriteLine("Enter the radius: ");
                    radius = System.Convert.ToDouble(Console.ReadLine());
                    valid = true;

                }
                catch (Exception ex)
                {
                    Console.WriteLine("ERROR:" + " " + ex.Message);

                }
            } while (!valid);
            arCir = PI * radius * radius;
            Console.WriteLine("Area of the Circle :" + arCir);
            perCir = 2 * PI * radius;
            Console.WriteLine("Perimeter of the Circle :" + perCir);
            Console.ReadKey();
            Console.Clear();
        }
        static void Retangle()
        {

            double width = 0.00, height = 0.00, perRet = 0.00, arRet = 0.00;
            bool valid1 = false;
            bool valid2 = false;
            do
            {
                try
                {
                    Console.WriteLine("Enter the width: ");
                    width = System.Convert.ToDouble(Console.ReadLine());
                    valid1 = true;

                }
                catch (Exception ex)
                {
                    Console.WriteLine("ERROR:" + " " + ex.Message);

                }
            } while (!valid1);
            do
            {
                try
                {
                    Console.WriteLine("Enter the height: ");
                    height = System.Convert.ToDouble(Console.ReadLine());
                    valid2 = true;

                }
                catch (Exception ex)
                {
                    Console.WriteLine("ERROR:" + " " + ex.Message);

                }
            } while (!valid2);

            arRet = width * height;
            Console.WriteLine("Area of the Retangle :" + arRet);
            width = width + width;
            height = height + height;
            perRet = width + height;
            Console.WriteLine("Perimeter of the Retangle :" + perRet);
            Console.ReadKey();
            Console.Clear();
        }
    }
}

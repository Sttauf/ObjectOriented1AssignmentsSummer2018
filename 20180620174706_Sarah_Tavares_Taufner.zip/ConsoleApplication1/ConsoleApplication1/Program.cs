﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApplication1.Logic;


namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s1 = new Student();
            s1.StudentNumber = 100;
            s1.FirstName = "jo";
            s1.LastName = "jojo";
            s1.FirstFees = 275.75;
            s1.FeesPerSession = 775.99;
            Teacher t1 = new Teacher();
            t1.TeacherNumber = 200;
            t1.FirstName = "prof";
            t1.LastName = "profprof";
            t1.HoursByRate = 375.75;
            t1.HoursOfWork = 122.99;
            Console.WriteLine(s1);
            Console.WriteLine(t1);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   


            Console.ReadKey();
        }
    }
}

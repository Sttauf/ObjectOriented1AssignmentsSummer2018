﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1.Logic
{
    public class Teacher : Object
    {
        private int teacherNumber;
        private String firstName;
        private String lastName;
        private double hoursOfWork;
        private double hoursByRate;

        public int TeacherNumber
        {
            get
            {
                return teacherNumber;
            }

            set
            {
                teacherNumber = value;
            }
        }

        public string FirstName
        {
            get
            {
                return firstName;
            }

            set
            {
                firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }

            set
            {
                lastName = value;
            }
        }

        public double HoursOfWork
        {
            get
            {
                return hoursOfWork;
            }

            set
            {
                hoursOfWork = value;
            }
        }

        public double HoursByRate
        {
            get
            {
                return hoursByRate;
            }

            set
            {
                hoursByRate = value;
            }
        }
        public override String ToString()
        {
            String state = " ";
            state = this.teacherNumber + " - " + this.firstName + " - " + this.lastName + " - " + this.hoursByRate + " - " + this.hoursOfWork; return state;
        }
    
}
}

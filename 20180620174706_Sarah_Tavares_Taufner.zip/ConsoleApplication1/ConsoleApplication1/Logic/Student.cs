﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1.Logic
{
    public class Student : Object
    {//beginning class student
            private int studentNumber;
            private String firstName;
        private String lastName;
        private double firstFees;
        private double feesPerSession;

        public int StudentNumber
        {
            get
            {
                return studentNumber;
            }

            set
            {
                studentNumber = value;
            }
        }

        public string FirstName
        {
            get
            {
                return firstName;
            }

            set
            {
                firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }

            set
            {
                lastName = value;
            }
        }

        public double FirstFees
        {
            get
            {
                return firstFees;
            }

            set
            {
                firstFees = value;
            }
        }

        public double FeesPerSession
        {
            get
            {
                return feesPerSession;
            }

            set
            {
                feesPerSession = value;
            }
        }
        public override String ToString() { String state = " ";
            state = this.studentNumber + " - " + this.firstName + " - " + this.lastName + " - " + this.feesPerSession + " - " + this.firstFees; return state; }
    }
}

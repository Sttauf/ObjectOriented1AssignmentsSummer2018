﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        //declaring variables
        float VAL, R; // VAL = value, R = result
        string op = ""; //op = operator
        public Form1()
        {
            InitializeComponent();
        } //inicialize component

        //Button 1,2,3,4,5,6,7,8,9 or 0
        private void button1_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender; 
            if (textBoxCalculation.Text == "0")// if it's written only 0 in the textBox, it will clean
            {
                textBoxCalculation.Clear();
            } 

            textBoxCalculation.Text = textBoxCalculation.Text + b.Text; //add the number written on the button clicked in the textbox
            
        }
        
        //Button CE
        private void buttonReset_Click(object sender, EventArgs e)
        {
            textBoxCalculation.Clear(); //clean the textbox
            op = "";
        }

        //Button '+'
        private void buttonPlus_Click(object sender, EventArgs e)
        {
            VAL = float.Parse(textBoxCalculation.Text); //convertion from string to float 
            textBoxCalculation.Clear();//clear the text box
            textBoxCalculation.Focus(); //keep the focus on the textbox          
            op = "+";        

        }

        //Button '-'
        private void buttonSub_Click(object sender, EventArgs e)
        {
            
            if (textBoxCalculation.Text != "")
            {
               VAL = float.Parse(textBoxCalculation.Text);//converting value
                textBoxCalculation.Clear();
                textBoxCalculation.Focus();
                op = "-";
            }
        }

        //Button '*'
        private void buttonMult_Click(object sender, EventArgs e)
        {
            
            VAL = float.Parse(textBoxCalculation.Text);
            textBoxCalculation.Clear();
            textBoxCalculation.Focus();
            op = "*";
        }

        //Button '/'
        private void buttonDiv_Click(object sender, EventArgs e)
        {
           VAL = float.Parse(textBoxCalculation.Text); 
            textBoxCalculation.Clear();
            textBoxCalculation.Focus();
            op = "/";
        }

        //Button '.'
        private void buttonDot_Click(object sender, EventArgs e)
        {
            int c = textBoxCalculation.TextLength;
            int fl = 0;
            string text = textBoxCalculation.Text;
            for (int i = 0; i < c; i++)
            {
                if (text[i].ToString() == ".")
                {
                    fl = 1; break;
                }
                else
                {
                    fl = 0;
                }
            }
            if (fl == 0)
            {
                textBoxCalculation.Text = textBoxCalculation.Text + ".";
            }
        }

        //Button '='
        private void buttonEqual_Click(object sender, EventArgs e) //if the = button is clicked
        {
            calcu(op);//calling a function
        }

        //Button 'ON/OFF'
        private void buttonOnOff_Click(object sender, EventArgs e)
        {
            this.Close(); //close the application
        }

        //Function for the operations
        public void calcu(string op) //declaration of function
        {
            switch (op) //it will switch the last op added, so the calculation will ifinish
            {
                case "+":
                    R = VAL + float.Parse(textBoxCalculation.Text); //if the last op added was +, it will add to the last value added
                    textBoxCalculation.Text = R.ToString();
                    break;
                case "-":
                    R = VAL - float.Parse(textBoxCalculation.Text);
                    textBoxCalculation.Text = R.ToString();
                    break;
                case "*":
                    R = VAL * float.Parse(textBoxCalculation.Text);
                    textBoxCalculation.Text = R.ToString();
                    break;
                case "/":
                    if (float.Parse(textBoxCalculation.Text) != 0) //if the value 2 is different to 0, so we can div.
                    {
                        R = VAL / float.Parse(textBoxCalculation.Text);
                        textBoxCalculation.Text = R.ToString();
                    } else { } //else we cant div.
                    break;
                    default:
                    break;
            }
        }

        
        private void Form1_Load(object sender, EventArgs e) {}
        private void textBoxCalculation_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

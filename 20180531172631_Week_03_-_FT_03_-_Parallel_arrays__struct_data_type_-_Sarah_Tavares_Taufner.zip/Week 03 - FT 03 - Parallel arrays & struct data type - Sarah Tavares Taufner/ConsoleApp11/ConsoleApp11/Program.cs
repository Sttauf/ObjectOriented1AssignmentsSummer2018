﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    struct Student
    {
        public int ID;
        public string firstName;
        public string lastName;
    }
    class Program
    {

        static void Main(string[] args)
        {
            Student[] arr = new Student[10];
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Please enter Student ID, FirstName and LastName: ");

                arr[i].ID = System.Convert.ToInt32(Console.ReadLine());
                arr[i].firstName = Console.ReadLine();
                arr[i].lastName = Console.ReadLine();
            }
            Console.WriteLine("Code" + "\t" + "First Name" + "\t" + "Last Name");
            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine(arr[i].ID + "\t" + arr[i].firstName + "\t" + arr[i].lastName);
            }
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    struct Student
    {
        public int ID;
        public string firstName;
        public string lastName;
    }
    class Program
    {

        static void Main(string[] args)
        {
            Student[] arrID = new Student[10];
            Student[] arrFN = new Student[10];
            Student[] arrLN = new Student[10];
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Please enter Student ID, FirstName and LastName: ");

                arrID[i].ID = System.Convert.ToInt32(Console.ReadLine());
                arrFN[i].firstName = Console.ReadLine();
                arrLN[i].lastName = Console.ReadLine();
            }
            Console.WriteLine("Code" + "\t" + "First Name" + "\t" + "Last Name");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(arrID[i].ID + "\t" + arrFN[i].firstName + "\t" + arrLN[i].lastName);
            }
            Console.ReadKey();
        }
    }
}

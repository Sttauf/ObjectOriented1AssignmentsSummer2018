﻿namespace FinalExam
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkBoxEllipse = new System.Windows.Forms.CheckBox();
            this.checkBoxRectangle = new System.Windows.Forms.CheckBox();
            this.checkBoxCircle = new System.Windows.Forms.CheckBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBoxBorder = new System.Windows.Forms.ComboBox();
            this.comboBoxShape = new System.Windows.Forms.ComboBox();
            this.textBoxX = new System.Windows.Forms.TextBox();
            this.textBoxY = new System.Windows.Forms.TextBox();
            this.textBoxW = new System.Windows.Forms.TextBox();
            this.textBoxH = new System.Windows.Forms.TextBox();
            this.textBoxRx = new System.Windows.Forms.TextBox();
            this.textBoxRy = new System.Windows.Forms.TextBox();
            this.textBoxR = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.buttonDisplay = new System.Windows.Forms.Button();
            this.buttonReset = new System.Windows.Forms.Button();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonLoad = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.labelXY = new System.Windows.Forms.Label();
            this.labelCA = new System.Windows.Forms.Label();
            this.labelCC = new System.Windows.Forms.Label();
            this.labelRxW = new System.Windows.Forms.Label();
            this.labelRyH = new System.Windows.Forms.Label();
            this.buttonDownRight = new System.Windows.Forms.Button();
            this.buttonDOWN = new System.Windows.Forms.Button();
            this.buttonDownLeft = new System.Windows.Forms.Button();
            this.buttonRIGHT = new System.Windows.Forms.Button();
            this.buttonLEFT = new System.Windows.Forms.Button();
            this.buttonUpRight = new System.Windows.Forms.Button();
            this.buttonUpLeft = new System.Windows.Forms.Button();
            this.buttonUP = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // checkBoxEllipse
            // 
            this.checkBoxEllipse.AutoSize = true;
            this.checkBoxEllipse.Location = new System.Drawing.Point(8, 32);
            this.checkBoxEllipse.Name = "checkBoxEllipse";
            this.checkBoxEllipse.Size = new System.Drawing.Size(81, 24);
            this.checkBoxEllipse.TabIndex = 0;
            this.checkBoxEllipse.Text = "Ellipse";
            this.checkBoxEllipse.UseVisualStyleBackColor = true;
            this.checkBoxEllipse.CheckedChanged += new System.EventHandler(this.checkBoxEllipse_CheckedChanged);
            // 
            // checkBoxRectangle
            // 
            this.checkBoxRectangle.AutoSize = true;
            this.checkBoxRectangle.Location = new System.Drawing.Point(145, 32);
            this.checkBoxRectangle.Name = "checkBoxRectangle";
            this.checkBoxRectangle.Size = new System.Drawing.Size(108, 24);
            this.checkBoxRectangle.TabIndex = 1;
            this.checkBoxRectangle.Text = "Rectangle";
            this.checkBoxRectangle.UseVisualStyleBackColor = true;
            this.checkBoxRectangle.CheckedChanged += new System.EventHandler(this.checkBoxRectangle_CheckedChanged);
            // 
            // checkBoxCircle
            // 
            this.checkBoxCircle.AutoSize = true;
            this.checkBoxCircle.Location = new System.Drawing.Point(280, 32);
            this.checkBoxCircle.Name = "checkBoxCircle";
            this.checkBoxCircle.Size = new System.Drawing.Size(74, 24);
            this.checkBoxCircle.TabIndex = 2;
            this.checkBoxCircle.Text = "Circle";
            this.checkBoxCircle.UseVisualStyleBackColor = true;
            this.checkBoxCircle.CheckedChanged += new System.EventHandler(this.checkBoxCircle_CheckedChanged);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(8, 408);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(483, 64);
            this.listBox1.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(8, 131);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(483, 247);
            this.panel1.TabIndex = 4;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // comboBoxBorder
            // 
            this.comboBoxBorder.FormattingEnabled = true;
            this.comboBoxBorder.Location = new System.Drawing.Point(79, 97);
            this.comboBoxBorder.Name = "comboBoxBorder";
            this.comboBoxBorder.Size = new System.Drawing.Size(121, 28);
            this.comboBoxBorder.TabIndex = 0;
            this.comboBoxBorder.SelectedIndexChanged += new System.EventHandler(this.comboBoxBorder_SelectedIndexChanged);
            // 
            // comboBoxShape
            // 
            this.comboBoxShape.FormattingEnabled = true;
            this.comboBoxShape.Location = new System.Drawing.Point(264, 97);
            this.comboBoxShape.Name = "comboBoxShape";
            this.comboBoxShape.Size = new System.Drawing.Size(121, 28);
            this.comboBoxShape.TabIndex = 1;
            this.comboBoxShape.SelectedIndexChanged += new System.EventHandler(this.comboBoxShape_SelectedIndexChanged);
            // 
            // textBoxX
            // 
            this.textBoxX.Location = new System.Drawing.Point(585, 41);
            this.textBoxX.Name = "textBoxX";
            this.textBoxX.Size = new System.Drawing.Size(55, 26);
            this.textBoxX.TabIndex = 5;
            // 
            // textBoxY
            // 
            this.textBoxY.Location = new System.Drawing.Point(585, 75);
            this.textBoxY.Name = "textBoxY";
            this.textBoxY.Size = new System.Drawing.Size(55, 26);
            this.textBoxY.TabIndex = 6;
            // 
            // textBoxW
            // 
            this.textBoxW.Location = new System.Drawing.Point(593, 136);
            this.textBoxW.Name = "textBoxW";
            this.textBoxW.Size = new System.Drawing.Size(111, 26);
            this.textBoxW.TabIndex = 7;
            // 
            // textBoxH
            // 
            this.textBoxH.Location = new System.Drawing.Point(599, 168);
            this.textBoxH.Name = "textBoxH";
            this.textBoxH.Size = new System.Drawing.Size(105, 26);
            this.textBoxH.TabIndex = 8;
            // 
            // textBoxRx
            // 
            this.textBoxRx.Location = new System.Drawing.Point(632, 230);
            this.textBoxRx.Name = "textBoxRx";
            this.textBoxRx.Size = new System.Drawing.Size(72, 26);
            this.textBoxRx.TabIndex = 9;
            // 
            // textBoxRy
            // 
            this.textBoxRy.Location = new System.Drawing.Point(632, 262);
            this.textBoxRy.Name = "textBoxRy";
            this.textBoxRy.Size = new System.Drawing.Size(72, 26);
            this.textBoxRy.TabIndex = 10;
            // 
            // textBoxR
            // 
            this.textBoxR.Location = new System.Drawing.Point(604, 318);
            this.textBoxR.Name = "textBoxR";
            this.textBoxR.Size = new System.Drawing.Size(100, 26);
            this.textBoxR.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "Choose Shape:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "Choose Color:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 20);
            this.label3.TabIndex = 14;
            this.label3.Text = "Border:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(207, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 20);
            this.label4.TabIndex = 15;
            this.label4.Text = "Shape";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(510, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 20);
            this.label5.TabIndex = 16;
            this.label5.Text = "Coordinates:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(555, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 20);
            this.label6.TabIndex = 17;
            this.label6.Text = "X:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(555, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 20);
            this.label7.TabIndex = 18;
            this.label7.Text = "Y:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(510, 111);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 20);
            this.label8.TabIndex = 19;
            this.label8.Text = "Rectangle:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(533, 139);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 20);
            this.label9.TabIndex = 20;
            this.label9.Text = "Width:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(533, 174);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 20);
            this.label10.TabIndex = 21;
            this.label10.Text = "Height:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(510, 208);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 20);
            this.label11.TabIndex = 22;
            this.label11.Text = "Ellipse:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(532, 233);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(94, 20);
            this.label12.TabIndex = 23;
            this.label12.Text = "Radius in X:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(532, 265);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 20);
            this.label13.TabIndex = 24;
            this.label13.Text = "Radius in Y:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(510, 301);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 20);
            this.label14.TabIndex = 25;
            this.label14.Text = "Circle:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(533, 321);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 20);
            this.label15.TabIndex = 26;
            this.label15.Text = "Radius:";
            // 
            // buttonDisplay
            // 
            this.buttonDisplay.Location = new System.Drawing.Point(504, 355);
            this.buttonDisplay.Name = "buttonDisplay";
            this.buttonDisplay.Size = new System.Drawing.Size(75, 32);
            this.buttonDisplay.TabIndex = 27;
            this.buttonDisplay.Text = "Display";
            this.buttonDisplay.UseVisualStyleBackColor = true;
            this.buttonDisplay.Click += new System.EventHandler(this.buttonDisplay_Click);
            // 
            // buttonReset
            // 
            this.buttonReset.Location = new System.Drawing.Point(585, 355);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(75, 32);
            this.buttonReset.TabIndex = 28;
            this.buttonReset.Text = "Reset";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // buttonSave
            // 
            this.buttonSave.Location = new System.Drawing.Point(666, 355);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(75, 32);
            this.buttonSave.TabIndex = 29;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click_1);
            // 
            // buttonLoad
            // 
            this.buttonLoad.Location = new System.Drawing.Point(537, 393);
            this.buttonLoad.Name = "buttonLoad";
            this.buttonLoad.Size = new System.Drawing.Size(75, 32);
            this.buttonLoad.TabIndex = 30;
            this.buttonLoad.Text = "Load";
            this.buttonLoad.UseVisualStyleBackColor = true;
            this.buttonLoad.Click += new System.EventHandler(this.buttonLoad_Click_1);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(618, 393);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 32);
            this.buttonExit.TabIndex = 31;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click_1);
            // 
            // labelXY
            // 
            this.labelXY.AutoSize = true;
            this.labelXY.Location = new System.Drawing.Point(12, 385);
            this.labelXY.Name = "labelXY";
            this.labelXY.Size = new System.Drawing.Size(0, 20);
            this.labelXY.TabIndex = 40;
            // 
            // labelCA
            // 
            this.labelCA.AutoSize = true;
            this.labelCA.Location = new System.Drawing.Point(99, 385);
            this.labelCA.Name = "labelCA";
            this.labelCA.Size = new System.Drawing.Size(0, 20);
            this.labelCA.TabIndex = 41;
            // 
            // labelCC
            // 
            this.labelCC.AutoSize = true;
            this.labelCC.Location = new System.Drawing.Point(165, 385);
            this.labelCC.Name = "labelCC";
            this.labelCC.Size = new System.Drawing.Size(0, 20);
            this.labelCC.TabIndex = 42;
            // 
            // labelRxW
            // 
            this.labelRxW.AutoSize = true;
            this.labelRxW.Location = new System.Drawing.Point(260, 385);
            this.labelRxW.Name = "labelRxW";
            this.labelRxW.Size = new System.Drawing.Size(0, 20);
            this.labelRxW.TabIndex = 43;
            // 
            // labelRyH
            // 
            this.labelRyH.AutoSize = true;
            this.labelRyH.Location = new System.Drawing.Point(326, 385);
            this.labelRyH.Name = "labelRyH";
            this.labelRyH.Size = new System.Drawing.Size(0, 20);
            this.labelRyH.TabIndex = 44;
            // 
            // buttonDownRight
            // 
            this.buttonDownRight.BackgroundImage = global::FinalExam.Properties.Resources.down_right_arrow;
            this.buttonDownRight.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonDownRight.Location = new System.Drawing.Point(843, 112);
            this.buttonDownRight.Name = "buttonDownRight";
            this.buttonDownRight.Size = new System.Drawing.Size(38, 34);
            this.buttonDownRight.TabIndex = 39;
            this.buttonDownRight.UseVisualStyleBackColor = true;
            this.buttonDownRight.Click += new System.EventHandler(this.buttonDownRight_Click);
            // 
            // buttonDOWN
            // 
            this.buttonDOWN.BackgroundImage = global::FinalExam.Properties.Resources.arrow_602147_960_720_left;
            this.buttonDOWN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonDOWN.Location = new System.Drawing.Point(799, 113);
            this.buttonDOWN.Name = "buttonDOWN";
            this.buttonDOWN.Size = new System.Drawing.Size(38, 34);
            this.buttonDOWN.TabIndex = 38;
            this.buttonDOWN.UseVisualStyleBackColor = true;
            this.buttonDOWN.Click += new System.EventHandler(this.buttonDOWN_Click);
            // 
            // buttonDownLeft
            // 
            this.buttonDownLeft.BackgroundImage = global::FinalExam.Properties.Resources.down_left_arrow;
            this.buttonDownLeft.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonDownLeft.Location = new System.Drawing.Point(755, 113);
            this.buttonDownLeft.Name = "buttonDownLeft";
            this.buttonDownLeft.Size = new System.Drawing.Size(38, 34);
            this.buttonDownLeft.TabIndex = 37;
            this.buttonDownLeft.UseVisualStyleBackColor = true;
            this.buttonDownLeft.Click += new System.EventHandler(this.buttonDownLeft_Click);
            // 
            // buttonRIGHT
            // 
            this.buttonRIGHT.BackgroundImage = global::FinalExam.Properties.Resources.arrow_602147_960_720;
            this.buttonRIGHT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonRIGHT.Location = new System.Drawing.Point(843, 72);
            this.buttonRIGHT.Name = "buttonRIGHT";
            this.buttonRIGHT.Size = new System.Drawing.Size(38, 34);
            this.buttonRIGHT.TabIndex = 36;
            this.buttonRIGHT.UseVisualStyleBackColor = true;
            this.buttonRIGHT.Click += new System.EventHandler(this.buttonRIGHT_Click);
            // 
            // buttonLEFT
            // 
            this.buttonLEFT.BackgroundImage = global::FinalExam.Properties.Resources.arrow_602147_960_720down;
            this.buttonLEFT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonLEFT.Location = new System.Drawing.Point(755, 73);
            this.buttonLEFT.Name = "buttonLEFT";
            this.buttonLEFT.Size = new System.Drawing.Size(38, 34);
            this.buttonLEFT.TabIndex = 35;
            this.buttonLEFT.UseVisualStyleBackColor = true;
            this.buttonLEFT.Click += new System.EventHandler(this.buttonLEFT_Click);
            // 
            // buttonUpRight
            // 
            this.buttonUpRight.BackgroundImage = global::FinalExam.Properties.Resources.down_right_arrow___Copy__2_;
            this.buttonUpRight.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonUpRight.Location = new System.Drawing.Point(843, 32);
            this.buttonUpRight.Name = "buttonUpRight";
            this.buttonUpRight.Size = new System.Drawing.Size(38, 34);
            this.buttonUpRight.TabIndex = 34;
            this.buttonUpRight.UseVisualStyleBackColor = true;
            this.buttonUpRight.Click += new System.EventHandler(this.buttonUpRight_Click);
            // 
            // buttonUpLeft
            // 
            this.buttonUpLeft.BackgroundImage = global::FinalExam.Properties.Resources.down_right_arrow___Copy;
            this.buttonUpLeft.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonUpLeft.Location = new System.Drawing.Point(755, 33);
            this.buttonUpLeft.Name = "buttonUpLeft";
            this.buttonUpLeft.Size = new System.Drawing.Size(38, 34);
            this.buttonUpLeft.TabIndex = 33;
            this.buttonUpLeft.UseVisualStyleBackColor = true;
            this.buttonUpLeft.Click += new System.EventHandler(this.buttonUpLeft_Click);
            // 
            // buttonUP
            // 
            this.buttonUP.BackgroundImage = global::FinalExam.Properties.Resources.arrow_602147_960_720_up;
            this.buttonUP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonUP.Location = new System.Drawing.Point(799, 32);
            this.buttonUP.Name = "buttonUP";
            this.buttonUP.Size = new System.Drawing.Size(38, 34);
            this.buttonUP.TabIndex = 32;
            this.buttonUP.UseVisualStyleBackColor = true;
            this.buttonUP.Click += new System.EventHandler(this.buttonUP_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(905, 484);
            this.Controls.Add(this.labelRyH);
            this.Controls.Add(this.labelRxW);
            this.Controls.Add(this.labelCC);
            this.Controls.Add(this.labelCA);
            this.Controls.Add(this.labelXY);
            this.Controls.Add(this.buttonDownRight);
            this.Controls.Add(this.buttonDOWN);
            this.Controls.Add(this.buttonDownLeft);
            this.Controls.Add(this.buttonRIGHT);
            this.Controls.Add(this.buttonLEFT);
            this.Controls.Add(this.buttonUpRight);
            this.Controls.Add(this.buttonUpLeft);
            this.Controls.Add(this.buttonUP);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonLoad);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.buttonReset);
            this.Controls.Add(this.buttonDisplay);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxR);
            this.Controls.Add(this.textBoxRy);
            this.Controls.Add(this.textBoxRx);
            this.Controls.Add(this.textBoxH);
            this.Controls.Add(this.textBoxW);
            this.Controls.Add(this.textBoxY);
            this.Controls.Add(this.textBoxX);
            this.Controls.Add(this.comboBoxBorder);
            this.Controls.Add(this.comboBoxShape);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.checkBoxCircle);
            this.Controls.Add(this.checkBoxRectangle);
            this.Controls.Add(this.checkBoxEllipse);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBoxEllipse;
        private System.Windows.Forms.CheckBox checkBoxRectangle;
        private System.Windows.Forms.CheckBox checkBoxCircle;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboBoxBorder;
        private System.Windows.Forms.ComboBox comboBoxShape;
        private System.Windows.Forms.TextBox textBoxX;
        private System.Windows.Forms.TextBox textBoxY;
        private System.Windows.Forms.TextBox textBoxW;
        private System.Windows.Forms.TextBox textBoxH;
        private System.Windows.Forms.TextBox textBoxRx;
        private System.Windows.Forms.TextBox textBoxRy;
        private System.Windows.Forms.TextBox textBoxR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button buttonDisplay;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonLoad;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonUP;
        private System.Windows.Forms.Button buttonUpLeft;
        private System.Windows.Forms.Button buttonUpRight;
        private System.Windows.Forms.Button buttonLEFT;
        private System.Windows.Forms.Button buttonRIGHT;
        private System.Windows.Forms.Button buttonDownLeft;
        private System.Windows.Forms.Button buttonDOWN;
        private System.Windows.Forms.Button buttonDownRight;
        private System.Windows.Forms.Label labelXY;
        private System.Windows.Forms.Label labelCA;
        private System.Windows.Forms.Label labelCC;
        private System.Windows.Forms.Label labelRxW;
        private System.Windows.Forms.Label labelRyH;
    }
}


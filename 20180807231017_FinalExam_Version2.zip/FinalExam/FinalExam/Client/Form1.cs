﻿//III
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FinalExam.Bus;
using FinalExam.Data;
//I didn't have time to finish, but I'm sending all that I did.

namespace FinalExam
{
    public partial class Form1 : Form
    {
        List<Ellipse> ListOfEllipse = new List<Ellipse>();
        List<Circle> ListOfCircle = new List<Circle>();
        List<Rectangles> ListOfRectangles = new List<Rectangles>();
        List<BaseShapes> ListOfShapes = new List<BaseShapes>();
        Rectangles nR;
        Ellipse nE;
        Circle nC;
        EnumBorderColor BC;
        EnumBrushing SC;
        int j = 0;
        int j1 = 0;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            this.textBoxX.Enabled = false;
            this.textBoxY.Enabled = false;
            this.textBoxRx.Enabled = false;
            this.textBoxRy.Enabled = false;
            this.textBoxR.Enabled = false;
            this.textBoxW.Enabled = false;
            this.textBoxH.Enabled = false;
            listBox1.Items.Clear();
            foreach (EnumBrushing element in Enum.GetValues(typeof(EnumBrushing)))
            {
                comboBoxShape.Items.Add(element);
            }
            foreach (EnumBorderColor element in Enum.GetValues(typeof(EnumBorderColor)))
            {
                comboBoxBorder.Items.Add(element);
            }
        }

        //CheckBox
        private void checkBoxRectangle_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            this.textBoxX.Enabled = true;
            this.textBoxY.Enabled = true;
            this.textBoxRx.Enabled = false;
            this.textBoxRy.Enabled = false;
            this.textBoxR.Enabled = false;
            this.textBoxW.Enabled = true;
            this.textBoxH.Enabled = true;
            this.labelRyH.Text = "Height";
            this.labelXY.Text = "(X, Y)";
            this.labelRxW.Text = "Width";
            this.labelCC.Text = "Cir";
            this.labelCA.Text = "Area";
        }
        private void checkBoxEllipse_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            this.textBoxX.Enabled = true;
            this.textBoxY.Enabled = true;
            this.textBoxRx.Enabled = true;
            this.textBoxRy.Enabled = true;
            this.textBoxR.Enabled = false;
            this.textBoxW.Enabled = false;
            this.textBoxH.Enabled = false;
            this.labelRxW.Text = "Rx";
            this.labelXY.Text = "(X, Y)";
            this.labelRyH.Text = "Ry";
            this.labelCC.Text = "Cir";
            this.labelCA.Text = "Area";
        }
        private void checkBoxCircle_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            this.textBoxX.Enabled = true;
            this.textBoxY.Enabled = true;
            this.textBoxRx.Enabled = false;
            this.textBoxRy.Enabled = false;
            this.textBoxR.Enabled = true;
            this.textBoxW.Enabled = false;
            this.textBoxH.Enabled = false;
            this.labelRxW.Text = "Radius";
            this.labelXY.Text = "(X, Y)";
            this.labelCC.Text = "Cir";
            this.labelCA.Text = "Area";
        }

        //ComboBox
        private void comboBoxBorder_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxBorder.SelectedIndex == 0)
            {
                BC = EnumBorderColor.Red;
                int bc = (int)BC;
                bc = 0;
                j = 1;
            }
            else if (comboBoxBorder.SelectedIndex == 1)
            {
                BC = EnumBorderColor.Blue;
                int bc = (int) BC;
                bc = 1;
                j = 1;
            }
            else if (comboBoxBorder.SelectedIndex == 2)
            {
                BC = EnumBorderColor.Yellow;
                int bc = (int)BC;
                bc = 2;
                j = 1;
            }
            else if (comboBoxBorder.SelectedIndex == 3)
            {
                BC = EnumBorderColor.Black;
                int bc = (int)BC;
                bc = 3;
                j = 1;
            }
            else if (comboBoxBorder.SelectedIndex == 4)
            {
                BC = EnumBorderColor.Green;
                int bc = (int)BC;
                bc = 4;
                j = 1;
            }
            else if (comboBoxBorder.SelectedIndex == 5)
            {
                BC = EnumBorderColor.Purple;
                int bc = (int)BC;
                bc = 5;
                j = 1;
            }

        }
        private void comboBoxShape_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxShape.SelectedIndex == 0)
            {
                SC = EnumBrushing.Red;
                int sc = (int)SC;
                sc = 0;
                j1 = 2;
            }
            else if (comboBoxBorder.SelectedIndex == 1)
            {
                SC = EnumBrushing.Blue;
                int sc = (int)SC;
                sc = 1;
                j1 = 2;
            }
            else if (comboBoxBorder.SelectedIndex == 2)
            {
                SC = EnumBrushing.Yellow;
                int sc = (int)SC;
                sc = 2;
                j1 = 2;
            }
            else if (comboBoxBorder.SelectedIndex == 3)
            {
                SC = EnumBrushing.Black;
                int sc = (int)SC;
                sc = 3;
                j1 = 2;
            }
            else if (comboBoxBorder.SelectedIndex == 4)
            {
                SC = EnumBrushing.Green;
                int sc = (int)SC;
                sc = 4;
                j1 = 2;
            }
            else if (comboBoxBorder.SelectedIndex == 5)
            {
                SC = EnumBrushing.Purple;
                int sc = (int)SC;
                sc = 5;
                j1 = 2;
            }

        }

        //Panel
        private void panel1_Paint(object sender, PaintEventArgs s)
        {
           if(j == 1 && j1 == 2) { 
                if (this.checkBoxRectangle.Checked && nR != null)
                {
                    nR.Draw(s, SC, BC);
                    this.listBox1.Items.Add(nR.ToString());

                }
                else if (this.checkBoxEllipse.Checked && nE != null)
                {
                    nE.Draw(s, SC, BC);
                    this.listBox1.Items.Add(nE.ToString());

                }
                else if (this.checkBoxCircle.Checked && nC != null)
                {
                    nC.Draw(s, SC, BC);
                    this.listBox1.Items.Add(nC.ToString());
                }

            }
            else {  }

        }


        //Buttons
        private void buttonExit_Click_1(object sender, EventArgs e)
        {
            Close();
        }
        private void buttonDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                if (checkBoxRectangle.Checked)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    int Y = Convert.ToInt32(this.textBoxY.Text);
                    nR = new Rectangles(X, Y, W, H);
                    listBox1.Items.Add(nR.ToString());

                }
                else if (checkBoxEllipse.Checked)
                {
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    int Y = Convert.ToInt32(this.textBoxY.Text);
                    int Rx = Convert.ToInt32(this.textBoxRx.Text);
                    int Ry = Convert.ToInt32(this.textBoxRy.Text);
                    nE = new Ellipse(X, Y, Rx, Ry);
                    listBox1.Items.Add(nE.ToString());

                }
                else if (checkBoxCircle.Checked)
                {
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    int Y = Convert.ToInt32(this.textBoxY.Text);
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(X, Y, R);
                    listBox1.Items.Add(nC.ToString());
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch
            {
                MessageBox.Show("ERROR: You left an empty space.");
            }

        }
        private void buttonReset_Click(object sender, EventArgs e)
        {
            this.textBoxH.Clear();
            this.textBoxW.Clear();

            this.textBoxX.Clear();
            this.textBoxY.Clear();

            this.textBoxR.Clear();

            this.textBoxRy.Clear();
            this.textBoxRx.Clear();

            this.listBox1.Items.Clear();
            this.panel1.Invalidate();
            this.panel1.Update();
            this.Refresh();
        }   

        //XML
        private void buttonSave_Click_1(object sender, EventArgs e)
        {
            FileHandler.SaveXml(ListOfShapes, ListOfEllipse, ListOfCircle, ListOfRectangles);
        }
        private void buttonLoad_Click_1(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            FileHandler.LoadXml();
            try
            {
                foreach (Circle nC in ListOfCircle)
                {
                    this.listBox1.Items.Add(nC);
                }
                foreach (Ellipse nE in ListOfEllipse)
                {
                    this.listBox1.Items.Add(nE);
                }
                foreach (Rectangles nR in ListOfRectangles)
                {
                    this.listBox1.Items.Add(nR);
                }
            }
            catch
            {

            }
        }

        //Moving
        private void buttonUP_Click(object sender, EventArgs e)
        {
            try
            {
                int Y = Convert.ToInt32(this.textBoxY.Text);
                Y = Y - 1;
                textBoxY.Text = Convert.ToString(Y);
                if (checkBoxRectangle.Checked)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (checkBoxEllipse.Checked)
                {
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    int RX = Convert.ToInt32(this.textBoxRx.Text);
                    int RY = Convert.ToInt32(this.textBoxRy.Text);
                    nE = new Ellipse(RX, RY, X, Y);
                }
                else if (checkBoxCircle.Checked)
                {
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }
        private void buttonRIGHT_Click(object sender, EventArgs e)
        {
            try
            {
                int X = Convert.ToInt32(this.textBoxY.Text);
                X = X + 1;
                textBoxY.Text = Convert.ToString(X);
                if (checkBoxRectangle.Checked)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    int Y = Convert.ToInt32(this.textBoxX.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (checkBoxEllipse.Checked)
                {
                    int Y = Convert.ToInt32(this.textBoxX.Text);
                    int RX = Convert.ToInt32(this.textBoxRx.Text);
                    int RY = Convert.ToInt32(this.textBoxRy.Text);
                    nE = new Ellipse(RX, RY, X, Y);
                }
                else if (checkBoxCircle.Checked)
                {
                    int Y = Convert.ToInt32(this.textBoxX.Text);
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }
        private void buttonDOWN_Click(object sender, EventArgs e)
        {
            try
            {
                int Y = Convert.ToInt32(this.textBoxY.Text);
                Y = Y + 1;
                textBoxY.Text = Convert.ToString(Y);
                if (checkBoxRectangle.Checked)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (checkBoxEllipse.Checked)
                {
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    int RX = Convert.ToInt32(this.textBoxRx.Text);
                    int RY = Convert.ToInt32(this.textBoxRy.Text);
                    nE = new Ellipse(RX, RY, X, Y);
                }
                else if (checkBoxCircle.Checked)
                {
                    int X = Convert.ToInt32(this.textBoxX.Text);
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }
        private void buttonLEFT_Click(object sender, EventArgs e)
        {
            try
            {
                int X = Convert.ToInt32(this.textBoxY.Text);
                X = X - 1;
                textBoxY.Text = Convert.ToString(X);
                if (checkBoxRectangle.Checked)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    int Y = Convert.ToInt32(this.textBoxX.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (checkBoxEllipse.Checked)
                {
                    int Y = Convert.ToInt32(this.textBoxX.Text);
                    int RX = Convert.ToInt32(this.textBoxRx.Text);
                    int RY = Convert.ToInt32(this.textBoxRy.Text);
                    nE = new Ellipse(RX, RY, X, Y);
                }
                else if (checkBoxCircle.Checked)
                {
                    int Y = Convert.ToInt32(this.textBoxX.Text);
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }

        private void buttonUpRight_Click(object sender, EventArgs e)
        {
            try
            {
                int X = Convert.ToInt32(this.textBoxY.Text);
                X = X + 1;
                int Y = Convert.ToInt32(this.textBoxY.Text);
                Y = Y - 1;
                textBoxY.Text = Convert.ToString(X);
                if (checkBoxRectangle.Checked)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (checkBoxEllipse.Checked)
                {
                    int RX = Convert.ToInt32(this.textBoxRx.Text);
                    int RY = Convert.ToInt32(this.textBoxRy.Text);
                    nE = new Ellipse(RX, RY, X, Y);
                }
                else if (checkBoxCircle.Checked)
                {
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }
        private void buttonDownRight_Click(object sender, EventArgs e)
        {
            try
            {
                int X = Convert.ToInt32(this.textBoxY.Text);
                X = X + 1;
                int Y = Convert.ToInt32(this.textBoxY.Text);
                Y = Y + 1;
                textBoxY.Text = Convert.ToString(X);
                if (checkBoxRectangle.Checked)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (checkBoxEllipse.Checked)
                {
                    int RX = Convert.ToInt32(this.textBoxRx.Text);
                    int RY = Convert.ToInt32(this.textBoxRy.Text);
                    nE = new Ellipse(RX, RY, X, Y);
                }
                else if (checkBoxCircle.Checked)
                {
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }
        private void buttonDownLeft_Click(object sender, EventArgs e)
        {
            try
            {
                int X = Convert.ToInt32(this.textBoxY.Text);
                X = X - 1;
                int Y = Convert.ToInt32(this.textBoxY.Text);
                Y = Y + 1;
                textBoxY.Text = Convert.ToString(X);
                if (checkBoxRectangle.Checked)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (checkBoxEllipse.Checked)
                {
                    int RX = Convert.ToInt32(this.textBoxRx.Text);
                    int RY = Convert.ToInt32(this.textBoxRy.Text);
                    nE = new Ellipse(RX, RY, X, Y);
                }
                else if (checkBoxCircle.Checked)
                {
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }
        private void buttonUpLeft_Click(object sender, EventArgs e)
        {
            try
            {
                int X = Convert.ToInt32(this.textBoxY.Text);
                X = X - 1;
                int Y = Convert.ToInt32(this.textBoxY.Text);
                Y = Y - 1;
                textBoxY.Text = Convert.ToString(X);
                if (checkBoxRectangle.Checked)
                {
                    int W = Convert.ToInt32(this.textBoxW.Text);
                    int H = Convert.ToInt32(this.textBoxH.Text);
                    nR = new Rectangles(W, H, X, Y);
                }
                else if (checkBoxEllipse.Checked)
                {
                    int RX = Convert.ToInt32(this.textBoxRx.Text);
                    int RY = Convert.ToInt32(this.textBoxRy.Text);
                    nE = new Ellipse(RX, RY, X, Y);
                }
                else if (checkBoxCircle.Checked)
                {
                    int R = Convert.ToInt32(this.textBoxR.Text);
                    nC = new Circle(R, X, Y);
                }
                this.panel1.Invalidate();
                this.panel1.Update();
                this.Refresh();
            }
            catch { MessageBox.Show("ERROR: Add the info."); }
        }


        //..
        private void buttonSave_Click(object sender, EventArgs e)
        {

        }
        private void buttonLoad_Click(object sender, EventArgs e)
        {

        }

    }
}

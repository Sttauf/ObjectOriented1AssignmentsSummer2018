﻿//I) Question 2
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace FinalExam.Bus
{
    //2.2
    [Serializable]
    public class Circle : BaseShapes
    {
        private double R; //radius
        public double R1 { get => R; set => R = value; }
        public Circle()
        {
            this.X = 0.00;
            this.Y = 0.00;
            this.R1 = 0.00;
        }
        public Circle(double x, double y, double R) : base(x, y)
        {
            this.X = x;
            this.Y = y;
            this.R = R;
        }
        public override double computeArea()
        {
            return 3.14 * R * R;
        }
        public override double computeCircumference()
        {
            return 2 * 3.14 * R;
        }
        public override string ToString()
        {
            string st;
            st = "(" + this.X + ", " + this.Y + ")" + "\t" + computeArea() + "\t" + computeCircumference() +"\t" + this.R;
            return st;
        }
        public override void Draw(PaintEventArgs s, EnumBrushing SC, EnumBorderColor BC)
        {
            int bc = (int) BC;
            int sc = (int) SC;

            //Board
            switch (bc) 
            {
                case 0: //Red
                    {
                        Pen myPen = new Pen(Color.Red, 4);
                        s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                        myPen.Dispose();
                    } break;
                case 1: //Blue
                    {
                        Pen myPen = new Pen(Color.Blue, 4);
                        s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                        myPen.Dispose();
                    } break;
                case 2: //Yellow
                    {
                        Pen myPen = new Pen(Color.Yellow, 4);
                        s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                        myPen.Dispose();
                    } break;
                case 3: //Black
                    {
                        Pen myPen = new Pen(Color.Black, 4);
                        s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                        myPen.Dispose();
                    } break;
                case 4: //Green
                    {
                        Pen myPen = new Pen(Color.Green, 4);
                        s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                        myPen.Dispose();
                    } break;
                case 5: //Purple
                    {
                        Pen myPen = new Pen(Color.Purple, 4);
                        s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                        myPen.Dispose();
                    } break;
            }

            //Shape
            switch (sc)
            {
                case 0: //Red
                    {
                        s.Graphics.FillEllipse(Brushes.Red, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    }
                    break;
                case 1: //Blue
                    {
                        s.Graphics.FillEllipse(Brushes.Blue, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    }
                    break;
                case 2: //Yellow
                    {
                        s.Graphics.FillEllipse(Brushes.Yellow, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    }
                    break;
                case 3: //Black
                    {
                        s.Graphics.FillEllipse(Brushes.Black, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    }
                    break;
                case 4: //Green
                    {
                        s.Graphics.FillEllipse(Brushes.Green, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    }
                    break;
                case 5: //Purple
                    {
                        s.Graphics.FillEllipse(Brushes.Purple, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
                    }
                    break;
            }
        }

        public override void MoveDown(int y) { }
        public override void MoveUp(int y) { }
        public override void MoveLeft(int x) { }
        public override void MoveRight(int x) { }

        public override void MoveUpLeft(int x, int y) { }
        public override void MoveUpRight(int x, int y) { }
        public override void MoveDownLeft(int x, int y) { }
        public override void MoveDownRight(int x, int y) { }

    }
}

﻿
//I) Question 1
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace FinalExam.Bus
{
    [Serializable]
    //2
    //EnumType
    public enum EnumType { Rectangle, Circle, Ellipse } //2.1
    public enum EnumBrushing { Red, Blue, Yellow, Black, Green, Purple } //2.2
    public enum EnumBorderColor { Red, Blue, Yellow, Black, Green, Purple } //2.3
    interface IShape2D
    {   
        //1
        //Calculation
        double computeArea(); //1.1
        double computeCircumference(); //1.2

        //Drawing
        void Draw(System.Windows.Forms.PaintEventArgs s, EnumBrushing SC, EnumBorderColor BC); //1.3

        //Moving
        //1.4
        void MoveUp(int y);
        void MoveDown(int y);
        void MoveLeft(int x);
        void MoveRight(int x);
        //1.5
        void MoveUpLeft(int x, int y);
        void MoveUpRight(int x, int y);
        void MoveDownLeft(int x, int y);
        void MoveDownRight(int x, int y);
    }
}

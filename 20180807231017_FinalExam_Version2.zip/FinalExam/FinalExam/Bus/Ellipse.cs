﻿//I) Question 2

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace FinalExam.Bus
{
    //2.2
    [Serializable]
    class Ellipse : BaseShapes
    {
        private double Rx; //radius in x
        private double Ry; //radius in y
        public double Rx1 { get => Rx; set => Rx = value; }
        public double Ry1 { get => Ry; set => Ry = value; }

        public Ellipse()
        {
            this.X = 0.00;
            this.Y = 0.00;
            this.Rx1 = 0.00;
            this.Ry1 = 0.00;
        }
        public Ellipse(double x, double y, double Rx, double Ry) : base(x, y)
        {
            this.X = x;
            this.Y = y;
            this.Rx1 = Rx;
            this.Ry1 = Ry;
        }
        public override double computeArea()
        {
            return 3.14 * Rx * Ry;
        }
        public override double computeCircumference()
        {
            return Math.PI*(3*(Rx + Ry) - Math.Sqrt(((3*Rx) + Ry) * (Rx + (3*Ry))));
        }
        public override string ToString()
        {
            string st;
            st = "(" + this.X + ", " + this.Y + ")" + "\t" + computeArea() + "\t" + computeCircumference() + "\t" + this.Rx + "\t" + this.Ry;
            return st;
        }
        public override void Draw(PaintEventArgs s, EnumBrushing SC, EnumBorderColor BC)
        {
            int bc = (int)BC;
            int sc = (int)SC;

            //Board
            switch (bc)
            {
                case 0: //Red
                    {
                        Pen myPen = new Pen(Color.Red, 4);
                        s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                        myPen.Dispose();
                    }
                    break;
                case 1: //Blue
                    {
                        Pen myPen = new Pen(Color.Blue, 4);
                        s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                        myPen.Dispose();
                    }
                    break;
                case 2: //Yellow
                    {
                        Pen myPen = new Pen(Color.Yellow, 4);
                        s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                        myPen.Dispose();
                    }
                    break;
                case 3: //Black
                    {
                        Pen myPen = new Pen(Color.Black, 4);
                        s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                        myPen.Dispose();
                    }
                    break;
                case 4: //Green
                    {
                        Pen myPen = new Pen(Color.Green, 4);
                        s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                        myPen.Dispose();
                    }
                    break;
                case 5: //Purple
                    {
                        Pen myPen = new Pen(Color.Purple, 4);
                        s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                        myPen.Dispose();
                    }
                    break;
            }

            //Shape
            switch (sc)
            {
                case 0: //Red
                    {
                        s.Graphics.FillEllipse(Brushes.Red, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    }
                    break;
                case 1: //Blue
                    {
                        s.Graphics.FillEllipse(Brushes.Blue, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    }
                    break;
                case 2: //Yellow
                    {
                        s.Graphics.FillEllipse(Brushes.Yellow, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    }
                    break;
                case 3: //Black
                    {
                        s.Graphics.FillEllipse(Brushes.Black, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    }
                    break;
                case 4: //Green
                    {
                        s.Graphics.FillEllipse(Brushes.Green, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    }
                    break;
                case 5: //Purple
                    {
                        s.Graphics.FillEllipse(Brushes.Purple, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
                    }
                    break;
            }
        }

        public override void MoveDown(int y) { }
        public override void MoveUp(int y) { }
        public override void MoveLeft(int x) { }
        public override void MoveRight(int x) { }

        public override void MoveUpLeft(int x, int y) { }
        public override void MoveUpRight(int x, int y) { }
        public override void MoveDownLeft(int x, int y) { }
        public override void MoveDownRight(int x, int y) { }
    }
}

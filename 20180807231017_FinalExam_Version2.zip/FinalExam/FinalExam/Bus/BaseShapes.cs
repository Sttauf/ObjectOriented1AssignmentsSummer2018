﻿//I) Question 2
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace FinalExam.Bus
{
    //2.1
    [Serializable]
    public abstract class BaseShapes : IShape2D
    {
        private double x;
        private double y;

        public double X { get => x; set => x = value; }
        public double Y { get => y; set => y = value; }
        public BaseShapes()
        {
            this.x = 0.00;
            this.y = 0.00;
        }
        public BaseShapes(double x, double y)
        {
            this.x = X;
            this.y = Y;
        }
        public override String ToString()
        {
            string st;
            st = "(" + this.x + ", " + this.y + ")";
            return st;
        }
        public abstract double computeArea();
        public abstract double computeCircumference();
        public abstract void Draw(PaintEventArgs s, EnumBrushing SC, EnumBorderColor BC);
        public abstract void MoveUp(int y);
        public abstract void MoveDown(int y);
        public abstract void MoveLeft(int x);
        public abstract void MoveRight(int x);
        public abstract void MoveUpLeft(int x, int y);
        public abstract void MoveUpRight(int x, int y);
        public abstract void MoveDownLeft(int x, int y);
        public abstract void MoveDownRight(int x, int y);

    }
}

﻿//II
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;
using System.Windows.Forms;
using FinalExam.Bus;
using System.IO;

namespace FinalExam.Data
{
    class FileHandler
    {
        List<BaseShapes> ListOfShapes = new List<BaseShapes>();
        List<Ellipse> ListOfEllipse = new List<Ellipse>();
        List<Circle> ListOfCircle = new List<Circle>();
        List<Rectangles> ListOfRectangles = new List<Rectangles>();
        private static String xmlPath = @"../../data/Shapes.xml";

        public static void SaveXml(List<BaseShapes> ListOfShapes, List<Ellipse> ListOfEllipse, List<Circle> ListOfCircle, List<Rectangles> ListOfRectangles)
        {
            try
            {
                XmlWriter writer = XmlWriter.Create(xmlPath);
                XmlSerializer serializer = new XmlSerializer(typeof(List<Ellipse>));
                serializer.Serialize(writer, ListOfEllipse);
                writer.Close();
                XmlWriter writer2 = XmlWriter.Create(xmlPath);
                XmlSerializer serializer2 = new XmlSerializer(typeof(List<Circle>));
                serializer2.Serialize(writer2, ListOfCircle);
                writer2.Close();
                XmlWriter writer3 = XmlWriter.Create(xmlPath);
                XmlSerializer serializer3 = new XmlSerializer(typeof(List<Rectangles>));
                serializer3.Serialize(writer3, ListOfRectangles);
                writer3.Close();
            }
            catch { }
        }

        public static void LoadXml()
        {
            List<BaseShapes> ListOfShapes = new List<BaseShapes>();
            List<Ellipse> ListOfEllipse = new List<Ellipse>();
            List<Circle> ListOfCircle = new List<Circle>();
            List<Rectangles> ListOfRectangles = new List<Rectangles>();
            ListOfEllipse.Clear();
            ListOfCircle.Clear();
            ListOfRectangles.Clear();
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(List<Ellipse>));
                StreamReader reader = new StreamReader(xmlPath);
                ListOfEllipse = (List<Ellipse>)serializer.Deserialize(reader);
                reader.Close();
                XmlSerializer serializer2 = new XmlSerializer(typeof(List<Ellipse>));
                StreamReader reader2 = new StreamReader(xmlPath);
                ListOfCircle = (List<Circle>)serializer2.Deserialize(reader2);
                reader2.Close();
                XmlSerializer serializer3 = new XmlSerializer(typeof(List<Ellipse>));
                StreamReader reader3 = new StreamReader(xmlPath);
                ListOfRectangles = (List<Rectangles>)serializer3.Deserialize(reader3);
                reader3.Close();
            }
            catch { }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;


namespace Wk10___Shapes_Version2._1.Classes
{
    public class Elipse : Shapes
    {
        private double Rx;
        private double Ry;//R = Radius
        public double Rx1 { get => Rx; set => Rx = value; }
        public double Ry1 { get => Ry; set => Ry = value; }

        public Elipse()
        {
            this.X = 0.00;
            this.Y = 0.00;
            this.Rx = 0.00;
            this.Ry = 0.00;
        }
        public Elipse(double Rx, double Ry, double X, double Y) : base(X,Y)
        {
            this.X = X;
            this.Y = Y;
            this.Rx1 = Rx;
            this.Ry1 = Ry;
        }
        public override double CA() //CALCULE AREA
        {
            return 3.14 * this.Rx * this.Ry;
        }
        public override double CP() //CALCULE PERIMETER
        {
            double t;
            t = (Rx * Rx) + (Ry * Ry);

            return 2 * 3.14 * Math.Sqrt(t) / 2;

        }
        public override String ToString()
        {
            String D = "Radius in X: " + this.Rx + "\r\n";
            D += "Radius in Y: " + this.Ry + "\r\n";
            D += "Perimeter: " + Math.Round(this.CP()) + "\r\n";
            D += "Area = " + Math.Round(this.CA()) + "\r\n";
            return D;
        }
        public override void Draw(PaintEventArgs s)
        {
            Pen myPen = new Pen(Color.CadetBlue, 2);
            //Convert.ToDouble();
            s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.Rx), Convert.ToInt32(this.Ry)));
            myPen.Dispose();
            s.Graphics.Dispose();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Wk10___Shapes_Version2._1.Classes
{
    public class Circle : Shapes
    {
        private double R;//R = Radius
        public double R1 { get => R; set => R = value; }

        public Circle()
    {
        this.X = 0.00;
        this.Y = 0.00;
        this.R = 0.00;
    }
    public Circle(double R, double x, double y) : base(x, y)
    {
        this.X = X;
        this.Y = Y;
        this.R1 = R;
    }
    public override double CA() //CALCULE AREA
    {
        return 3.14 * this.R * this.R;
    }
    public override double CP() //CALCULE PERIMETER
    {
       return 2 * 3.14 * this.R;

    }
    public override String ToString()
    {
        String D = "Radius in X: " + this.R + "\r\n";
        D += "Radius in Y: " + this.R + "\r\n";
        D += "Perimeter: " + Math.Round(this.CP()) + "\r\n";
        D += "Area = " + Math.Round(this.CA()) + "\r\n";
        return D;
    }
    public override void Draw(PaintEventArgs s)
    {
        Pen myPen = new Pen(Color.CadetBlue, 2);
        //Convert.ToDouble();
        s.Graphics.DrawEllipse(myPen, new System.Drawing.Rectangle(Convert.ToInt32(X), Convert.ToInt32(Y), Convert.ToInt32(this.R), Convert.ToInt32(this.R)));
        myPen.Dispose();
        s.Graphics.Dispose();
    }
}
}

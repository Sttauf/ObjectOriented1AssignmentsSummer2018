﻿//STRUCT CIRCLE

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeometricShapesStructCir
{
    class Program
    {
        struct Circle
        {
            private int e1;
            private int e2;
            private int rad;


            public Circle(int e1, int e2, int rad)
            {
                this.e1 = e1;
                this.e2 = e2;
                this.rad = rad;
            }
            public int GetE1()
            {
                return this.e1;
            }
            public void SetE1(int e1)
            {
                this.e1 = e1;
            }
            public int GetE2()
            {
                return this.e2;
            }
            public void SetE2(int e2)
            {
                this.e2 = e2;
            }
            public int GetRadius()
            {
                return this.rad;
            }
            public void SetRadius(int rad)
            {
                this.rad = rad;
            }
            public double CalculArea()
            {
                double area;
                area = Math.PI * this.rad * this.rad;
                return Math.Round(area, 2);
            }
            public double CalculPerimeter()
            {
                double perimeter;
                perimeter = 2 * Math.PI * this.rad;
                return Math.Round(perimeter, 2);
            }
            public void MoveToRight(int d1)
            {

                this.e1 = this.e1 + d1;
            }
            public void MoveToLeft(int d1)
            {

                this.e1 = this.e1 - d1;
            }
            public void MoveToUp(int d2)
            {

                this.e2 = this.e2 + d2;
            }
            public void MoveToDown(int d2)
            {

                this.e2 = this.e2 - d2;
            }
            public string GetInfos()
            {
                string state;
                state = "X: " + this.e1 + " Y: " + this.e2 + " Radius: " + this.rad;
                return state;
            }
        }


        static void Main(string[] args)
        {

            Circle c1 = new Circle();

            c1.SetE1(4);
            c1.SetE2(6);
            c1.SetRadius(4);

            Console.WriteLine("Info: " + c1.GetInfos());
            Console.WriteLine("Area: " + c1.CalculArea() + " Perimeter:  " + c1.CalculPerimeter());
            Console.WriteLine("Moving 3 to right and 3 down: ");
            c1.MoveToRight(3); c1.MoveToDown(3);
            Console.WriteLine("New info: " + c1.GetInfos() + "\n\n");

            Circle c2 = new Circle();
            c2.SetE1(32);
            c2.SetE2(33);
            c2.SetRadius(43);
            Console.WriteLine("Info: " + c2.GetInfos());
            Console.WriteLine("Area: " + c2.CalculArea() + " Perimeter:  " + c2.CalculPerimeter());
            Console.WriteLine("Moving 3 to left and 3 up: ");
            c2.MoveToLeft(3); c2.MoveToUp(3);
            Console.WriteLine("New info: " + c2.GetInfos());
            Console.ReadKey();
        }
    }
}